var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var option = { promiseLib: promise };


var multer = require('multer');
// var upload = multer({ dest: 'uploads/' })


var pgr = require('pg-promise')(option)
var property = express();
var config = require('./apiconfig')
var conntstr = config.connectionString




property.all('*', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", '*');
    res.header("Access-Control-Allow-Headers", "Cache-Control,Pragma,Origin,Authorization,Content-Type,X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});

property.use(bodyparser.json({ limit: '30mb' }));
property.use(bodyparser.urlencoded({ limit: '30mb', extended: true }));




// ********GET ROUTES*******

//** property_facility_mapping **/
property.get("/getPropertyFacilitiesByPropertyTypeId/:propertyTypeId", (req, res, next) => {        //get property_facility_mapping by joining on facility based on property_type_id
    var propertyTypeId = req.params.propertyTypeId;
    var db = pgr(conntstr);
    db.any("select * from fn_property_facility_mapping_select($1)", propertyTypeId).then((data) => {
        res.send(data);
    })
    pgr.end();
});
//** property_types **/
property.get("/getPropertyTypes", (req, res, next) => {     //get all property types
    var db = pgr(conntstr);
    db.any("select * from fn_property_types_select()").then((data) => {
        res.send(data);
    })
    pgr.end();
});
//** propertytype_amenity_mapping **/
property.get("/getPropertyAmenitiesByPropertyTypeId/:propertyTypeId", (req, res, next) => {     //get propertytype_amenity_mapping by joining property_amenities based on property_type_id
    var propertyTypeId = req.params.propertyTypeId;
    var db = pgr(conntstr);
    db.any("SELECT * FROM fn_property_amenities_mapping_select($1)", propertyTypeId).then((data) => {
        res.send(data);
    })
    pgr.end();
});


property.get("/getcommunity", (req, res, next) => {

    var db = pgr(conntstr);
    db.any("select  from  fn_gated_community_select()").then((data) => {
        res.send(data);
    })
    pgr.end();
});



//**getMoredetails **rakesh**//
property.get("/getMoredetails/:property_id", (req, res, next) => {  //get all More details
    property_id = req.params.property_id;

    var db = pgr(conntstr);
    db.any("select t1.*,t3.*,t2.*,c.city_name ,s.state_name, co.country_name, a.area_name from(select oap.username, oap.property_id, oap.property_name,oap.facing,oap.price,oap.description,oap.nearluk_verified,oap.status,oap.posted_date,oap.units_id,oap.currency,oap.priority,oap.propertyarea,oap.construction_status,pt.property_type,array_to_json(array_agg(f.facility_name)) as facilities from property_details oap join Property_Types pt on oap.property_type_id = pt.property_type_id join post_property_facilities ppf on ppf.property_id=oap.property_id join facility f on f.facility_id=ppf.facility_id group by oap.property_id,pt.property_type)as t1 join(select oap.property_id,array_to_json(array_agg(pam.property_amenity)) as amenities from property_details oap join Post_Property_Amenities ppm on ppm.property_id=oap.property_id join property_amenities pam on pam.property_amenity_id=ppm.property_amenity_id group by oap.property_id)as t2 on t1.property_id=t2.property_id join (select * from property_address) as t3   on t3.property_id=t1.property_id left join city c on t3.city = c.city_id left join state s on t3.state = s.state_id left join country co on t3.country = co.country_id left join area a on t3.area = a.area_id where t1.property_id=$1", [property_id]).then((data) => {
        res.send(data);
    })
    pgr.end();
});
//** fourm **rakesh**//

property.get('/forum/:property_id', (req, res, next) => {
    property_id = req.params.property_id;

    var db = pgr(conntstr);
    db.any("select * from fn_getcomments($1)", property_id).then((data) => {
        res.send(data)
    })
    pgr.end();
})



property.get('/forum/count/:property_id', (req, res, next) => {
    property_id = req.params.property_id;
    console.log(property_id + "PID")
    var db = pgr(conntstr);

    db.any("select * from  fn_fourm_count_select($1)", property_id).then((data) => {

        res.send(data)
    })
    pgr.end();
})
//** Reply **rakesh**//

property.get('/getCommentReply/:comment_id', (req, res, next) => {
    comment_id = req.params.comment_id;
    var db = pgr(conntstr);
    db.any("select * from fn_getreply($1)", comment_id).then((data) => {
        res.send(data)
    })
    pgr.end();
})
property.get("/getPropertyDetailsforUpdate/:property_id", (req, res, next) => {


    //get property_facility_mapping by joining on facility based on property_type_id
    var property_id = req.params.property_id;
    var db = pgr(conntstr);

    db.any("select t1.*,t2.*,t3.*,t4.* from(select oap.username, oap.property_id, oap.property_name,oap.facing,oap.price,oap.property_type_id,oap.monthly_maintainance,oap.rental_period,oap.security_deposit,oap.description,oap.nearluk_verified,oap.status,oap.posted_date,oap.units_id,oap.currency,oap.priority,oap.propertyarea,oap.construction_status,oap.bidding,oap.rental_period,pt.property_type,array_to_json(array_agg(f.facility_name)) as facilities,array_to_json(array_agg(f.facility_id)) as facilities_id,u.units,c.currency_symbol from property_details oap left outer join Property_Types pt on oap.property_type_id = pt.property_type_id left outer join post_property_facilities ppf on ppf.property_id=oap.property_id  left outer join facility f on f.facility_id=ppf.facility_id left outer join units u on u.units_id=oap.units_id left outer join currency c on c.id=oap.currency group by oap.property_id,pt.property_type,u.units,c.currency_symbol)as t1 left outer join(select oap.property_id,array_to_json(array_agg(pam.property_amenity)) as amenities,(array_agg(pam.property_amenity_id)) as amenities_id,(array_agg(ppm.amenityvalue)) as amenities_value from property_details oap left outer join Post_Property_Amenities ppm on ppm.property_id=oap.property_id join property_amenities pam on pam.property_amenity_id=ppm.property_amenity_id group by oap.property_id) as t2 on t1.property_id=t2.property_id left outer join (select distinct pa.*,c.city_name,co.country_name,s.state_name,a.area_name from property_address pa left outer join city c on c.city_id=pa.city left outer join country co on co.country_id=pa.country left outer join state s on s.state_id=pa.state left outer join area a on a.area_id=pa.area)as t3 on t3.property_id=t1.property_id left outer join (select * from property_location_map)as t4 on t1.property_id=t4.property_id where t1.property_id=$1", property_id).then((data) => {
        res.send(data);
    })
    pgr.end();
});
property.get("/getPropertyFacilitiesByPropertyIdUsernotselected/:propertyId", (req, res, next) => {        //get property_facility_mapping by joining on facility based on property_type_id
    var propertyId = req.params.propertyId;
    var db = pgr(conntstr);
    db.any(" select * from fn_getFacilitiesnotselectbyowner($1)", propertyId).then((data) => {
        res.send(data);
    })
    pgr.end();
});
property.get("/getPropertyAmenitiesByPropertyIdUsernotselected/:propertyTypeId", (req, res, next) => {        //get property_facility_mapping by joining on facility based on property_type_id
    var propertyTypeId = req.params.propertyTypeId;
    var db = pgr(conntstr);
    db.any(" select * from fn_getAminitiesnotselectbyowner($1)", propertyTypeId).then((data) => {
        res.send(data);
    })
    pgr.end();
});

// ******POST ROUTES******

property.post('/postProperty', function (req, res) {        //insert into property_details

    var property_type_id = req.body.property_type_id;
    var property_name = req.body.property_name;
    var description = req.body.description;
    var currency = req.body.currency;
    var units_id = req.body.units_id;
    var facing = req.body.facing;
    var price = req.body.price;
    var propertyarea = req.body.propertyArea;
    var username = req.body.username;
    var construction_status = req.body.construction_status;
    var nearluk_verified = "N";
    var status = 'Incomplete';
    var priority = "0";
    var security_deposit = req.body.security_deposit;
    var monthly_maintainance = req.body.monthly_maintainance;
    var bidding = req.body.enable_bidding;
    var rental_period = req.body.rental_period;

    var cm_id = req.body.cm_id;


    console.log(cm_id)
    var dt = new Date();

    let month = dt.getMonth() + 1;
    if (month.length === 1) { month = "0" + month; }
    let property_id = 'NL' + dt.getFullYear().toString().substr(-2) + month + dt.getDate() + dt.getHours() + dt.getMinutes() + dt.getSeconds() + dt.getMilliseconds();
    let posted_date = dt.getFullYear().toString().substr() + '/' + month + '/' + dt.getDate() + '   ' + dt.getHours() + ':' + dt.getMinutes();

    var db = pgr(conntstr);
    db.any("select fn_property_details_insert_bid_community($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20)", [username, property_id, property_type_id, property_name, facing, price, description, nearluk_verified, status, posted_date, units_id, currency, priority, propertyarea, construction_status, security_deposit, monthly_maintainance, bidding, rental_period, cm_id]).then((data) => {


        res.send({ "id": property_id });
    });
    pgr.end();
});
property.post('/postImages', (req, res, next) => {// post Images..
    var property_id = req.body.property_id;
    var img = req.body.image
    var db = pgr(conntstr)

    var dir = "./Gallery/" + property_id + "/"
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir)
        var imgPath = "./Gallery/" + property_id + "/Images";
        fs.mkdirSync(imgPath);

    }

    var dt = new Date();
    fName = dt.getFullYear() + '_' + dt.getMonth() + '_' + dt.getDate() + '_' + dt.getHours() + '_' + dt.getMinutes() + '_' + dt.getMilliseconds() + 0 + ".png";
    fNameW = path.join(__dirname, 'Gallery/' + property_id + '/Images/' + fName);
    fs.writeFile(fNameW, img, 'base64', (err) => {
        if (err)
            console.log('Unable to write ..');
        else
            console.log('Saved the image');

    })

    res.send();
    pgr.end();
})
//** gated community **//
property.post('/gatedpost/community', function (req, res) {

    var community_name = req.body.community_name;
    var community_description = req.body.community_description;
    var city = req.body.city;
    var db = pgr(conntstr);
    db.any("select * from fn_add_community($1,$2,$3)", [community_name, community_description, city]).then((data) => {
        console.log(data)
        res.send(data)
    });

    pgr.end();
});
property.post('/forum/', (req, res, next) => {
    var property_id = req.body.property_id;
    var username = req.body.username;
    var comments = req.body.comments;
    var date = req.body.date;
    var db = pgr(conntstr);
    db.any("select fn_forum_comments_insert($1,$2,$3,$4)", [property_id, username, comments, date]).then((data) => {
        res.send({
            message: " inserted...."
        })
    })
    pgr.end();
})
property.post('/reply', (req, res, next) => {
    var comment_id = req.body.comment_id;
    var username = req.body.username;
    var reply = req.body.reply;

    var db = pgr(conntstr);
    db.any("select fn_reply_insert($1,$2,$3)", [comment_id, username, reply]).then((data) => {
        res.send({
            message: " inserted...."
        })
    })
    pgr.end();
})



property.post('/propertyLocationMapPost', function (req, res) {

    var property_id = req.body.property_id;
    var latitude = req.body.latitude;
    var longitude = req.body.longitude;
    var city = req.body.city;
    var db = pgr(conntstr);

    db.any("select fn_property_location_map_insert($1,$2,$3,$4)", [property_id, latitude, longitude, city]).then((data) => {

        res.send(data)
    });

    pgr.end();
});



//** post_property_amenities **//
property.post('/amenitiesPost/:propertyId/:amenityId/:amenityvalue', function (req, res) {       //insert into post_property_amenities
    var property_id = req.params.propertyId;
    var amenityId = req.params.amenityId;
    var amenityvalue = req.params.amenityvalue;



    var db = pgr(conntstr);


    db.any("select fn_post_property_amenities_insert($1,$2,$3)", [property_id, amenityId, amenityvalue]).then((data) => {

    });


    res.send();


    pgr.end();
});

property.post('/video/:id', function (req, res) {

    var a = req.params.id;
    console.log(a);
    console.log('----')

    var storage = multer.diskStorage({ //multers disk storage settings
        destination: function (req, file, cb) {

            cb(null, 'videos/');
        },
        filename: function (req, file, cb) {
            var datetimestamp = Date.now();
            cb(null, a + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1])
        }
    });

    var upload = multer({ //multer settings
        storage: storage
    }).single('file');
    upload(req, res, function (err) {
        console.log(req.file);
        if (err) {
            res.json({ error_code: 1, err_desc: err });
            return;
        }
        res.json({ error_code: 0, err_desc: null });
    });
});


property.post('/propertyviews/:propertyid/:username', function (req, res) {     //insert into property_address
    var property_id = req.params.propertyid;
    var username = req.params.username;
    var dt = new Date();

    let month = dt.getMonth() + 1;
    if (month.length === 1) { month = "0" + month; }
    let viewed_date = dt.getFullYear().toString().substr() + '/' + month + '/' + dt.getDate() + '   ' + dt.getHours() + ':' + dt.getMinutes();

    var db = pgr(conntstr);
    db.any("select * from fn_property_views_insert($1,$2,$3)", [property_id, username, viewed_date]).then((data) => {


        res.send(data);

    });
    pgr.end();
});
// ** post_property_facilities **//
property.post('/facilitiesPost/:property_id/:facilitiesPost', function (req, res) {

    var property_id = req.params.property_id;

    var facilities = req.params.facilitiesPost;



    var db = pgr(conntstr);

    db.any("select fn_post_property_facilities_insert($1,$2)", [property_id, facilities]).then((data) => {

    });

    res.send()
    pgr.end();
});
property.post('/postPropertyAddress', function (req, res) {     //insert into property_address
    var property_id = req.body.property_id;
    var address_proof_type = req.body.address_proof_type;
    var address_proof_id = req.body.address_proof_id;
    var address = req.body.address;
    console.log(address)
    var pincode = req.body.pincode;
    var landmarks = req.body.landmarks;
    var city = req.body.city;
    var state = req.body.state;
    var country = req.body.country;
    var area = req.body.area;
    console.log(pincode + '' + state + '' + country + '' + area);

    var db = pgr(conntstr);

    db.any("select fn_property_address_insert ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)", [property_id, address_proof_type, address_proof_id, address, pincode, landmarks, country, state, city, area]).then(() => {
        res.send({ message: "inserted" })
    })
    pgr.end();
});



// *** PUT ROUTES****

property.put('/propertystatus/:property_id/:status', (req, res, next) => {       //update tenant_notifications
    var property_id = req.params.property_id;
    var status = req.params.status;
    console.log(property_id + status)


    var dt = new Date();

    let month = dt.getMonth() + 1;
    if (month.length === 1) { month = "0" + month; }
    let update_date = dt.getFullYear().toString().substr() + '/' + month + '/' + dt.getDate() + '   ' + dt.getHours() + ':' + dt.getMinutes();

    var db = pgr(conntstr);

    db.any("select  from fn_update_property_status($1,$2,$3)    ", [property_id, status, update_date]).then((data) => {


        res.send(data);
    });


    pgr.end();
})
property.put('/updatepostProperty/:property_id', function (req, res) {        //insert into property_details

    var propertyId = req.params.property_id;

    var property_type_id = req.body.property_type_id;
    var property_name = req.body.property_name;
    var description = req.body.description;
    var currency = req.body.currency;
    var units_id = req.body.units_id;
    var facing = req.body.facing;
    var price = req.body.price;
    var propertyarea = req.body.propertyArea;
    var construction_status = req.body.construction_status;
    var security_deposit = req.body.security_deposit;
    var monthly_maintainance = req.body.monthly_maintainance;
    var bidding = req.body.enable_bidding;
    var rental_period = req.body.rental_period;
    var dt = new Date();

    let month = dt.getMonth() + 1;
    if (month.length === 1) { month = "0" + month; }

    let posted_date = dt.getFullYear().toString().substr() + '/' + month + '/' + dt.getDate() + '   ' + dt.getHours() + ':' + dt.getMinutes();

    var db = pgr(conntstr);
    db.any("update property_details set property_type_id=$1,property_name=$2,description=$3,currency=$4,units_id=$5,facing=$6,price=$7,propertyArea=$8,construction_status=$9,security_deposit=$10,monthly_maintainance=$11,bidding=$12,rental_period=$13,posted_date=$14 where property_id=$15", [property_type_id, property_name, description, currency, units_id, facing, price, propertyarea, construction_status, security_deposit, monthly_maintainance, bidding, rental_period, posted_date, propertyId]).then((data) => {

        res.send();
    });
    pgr.end();
});
property.put('/updateProperty/:property_id', (req, res, next) => {
    var property_id = req.params.property_id;
    var price = req.body.price;
    var security_deposit = req.body.security_deposit;
    var maintenance = req.body.monthly_maintainance;
    var description = req.body.description;
    var rental_period = req.body.rental_period;

    console.log(property_id + price + security_deposit + maintenance + description + rental_period)

    var db = pgr(conntstr);

    db.any('select fn_property_details_update($1,$2,$3,$4,$5,$6)', [price, security_deposit, maintenance, description, rental_period, property_id]).then((data) => {
        res.send(data)
    })
    pgr.end();
});

// *****DELETE ROUTES********

property.delete('/deleteImage/:image/:property_id', (req, res, next) => {
    var image = req.params.image;
    var property_id = req.params.property_id;
    console.log(image)
    console.log(property_id)
    var imgPath = "./Gallery/" + property_id + "/Images/" + image;
    console.log(imgPath);
    fs.unlinkSync(imgPath);
})
property.delete('/deleteFacilitiesAndAmnities/:property_id', (req, res, next) => {
    var property_id = req.params.property_id;
    var db = pgr(conntstr);

    db.any('select fn_post_property_amenities_delete($1)', [property_id]).then((data) => {
    })


    db.any('select fn_post_property_facilities_delete($1)', [property_id]).then((data) => {
        res.send(data);
    })

    pgr.end()
});


module.exports = property
var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var option = {
    promiseLib: promise
};

var pgr = require('pg-promise')(option)
var owner = express();
var config = require('./apiconfig')
var conntstr = config.connectionString




owner.use(function (req, res, next) { //allow cross origin requests
    res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
    res.header("Access-Control-Allow-Origin", "http://localhost:4200");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Credentials", true);
    next();
});

owner.use(bodyparser.json({ limit: '50mb' }));
owner.use(bodyparser.urlencoded({ limit: '50mb', extended: true }));


//** owner_add_agent **/

// owner.post('/OwnerAddAgentInsert/:property_id/:agent_username', (req, res, next) => {       //insert into owner_add_agent

//     var property_id = req.params.property_id;
//     var agent_username = req.params.agent_username;
//     console.log(property_id + '|' + agent_username)
//     var status = 'P';
//     var db = pgr(conntstr);
//     db.any("select fn_owner_add_agent_insert($1,$2,$3)", [property_id, agent_username, status]).then((data) => {
//         res.send({
//             "message": "inserted"
//         })
//     })
//     pgr.end();
// })

owner.post('/videoUpload', (req, res) => {  //video upload
    var property_id = req.body.property_id;
    console.log(req.body)
    console.log('here')
    fn = property_id + '.webm';
    cfn = path.join(__dirname, 'videos/' + fn)
    fs.writeFile(cfn, req.body.videos, 'base64', err => {
        if (err) {
            console.log(err)
        }
        else {
            console.log('addedd');
        }
    })
})

owner.put('/setPropertyAsActive/:property_id', (req, res, next) => {

    var property_id = req.params.property_id
    console.log(property_id + 'UPDATED')
    var db = pgr(conntstr);
    db.any("select fn_setPropertyAsActive_update($1)", property_id).then(() => {

    })
    pgr.end();
})


//** near by **/
owner.post('/nearby', (req, res, next) => {       //insert into nearby
    var property_id = req.body.property_id;
    var name = req.body.nearby_propertyname;
    var db = pgr(conntstr);
    console.log('entered')
    db.any("select fn_nearby_insert($1,$2)", [property_id, name]).then((data) => {
        res.send({
            "message": "inserted"
        })
    })
    pgr.end();
})

owner.put('/updateStatusInOwner_add_agent', (req, res, next) => {        //update status in owner_add_agent
    var property_id = req.body.property_id;
    var agent_username = req.body.agent_username;
    var status = req.body.status

    var db = pgr(cs);
    db.any("select fn_owner_add_agent_update($1,$2,$3)", [property_id, agent_username, status]).then((data) => {
        res.send({
            "message": "updated"
        })
    })
    pgr.end();
})
owner.get('/notification/:username', (req, res) => {
    var username = req.params.username;
    var db = pgr(conntstr);
    db.any(`
    select * from fn_tenant_notifications_select($1)`, username).then(data => {
        res.send(data)
    })
})

owner.put('/notificationstatus/:notificationid/:status', (req, res) => {

    var notification_id = req.params.notificationid;
    var status = req.params.status;
    console.log(notification_id + status)
    var db = pgr(conntstr);
    db.any("select fn_tenant_notification_status_update($1,$2)", [status, notification_id]).then(data => {
        res.send({ 'message': 'updated' })
    })
})

owner.post('/agentnotify', (req, res, next) => {
    console.log('notification')
    var property_id = req.body.property_id;
    var from_username = req.body.from_username;
    var to_username = req.body.to_username;
    console.log(to_username)
    var message = req.body.message;
    var notifydate = req.body.notifydate;
    var status = req.body.status;
    var notification_type = req.body.notification_type;
    var db = pgr(conntstr);
    db.any('select fn_tenant_notifications_insert($1,$2,$3,$4,$5,$6,$7)', [property_id, from_username, to_username, message, notifydate, notification_type, status]).then(data => {
        res.send({ 'message': 'inserted sucessfully' })
    })
})

owner.post('/biddingnotify', (req, res, next) => {
    console.log('notification')
    var property_id = req.body.property_id;
    var from_username = req.body.from_username;
    var to_username = req.body.to_username;
    console.log(req.body.to_username)
    console.log(to_username.length);
    console.log('count');
    var message = req.body.message;
    var notifydate = req.body.notifydate;
    var status = req.body.status;
    var notification_type = req.body.notification_type;
    var db = pgr(conntstr);
    for (let index = 0; index < to_username.length; index++) {
        db.any('select fn_tenant_notifications_insert1($1,$2,$3,$4,$5,$6,$7)', [property_id, from_username, to_username[index].agent_username, message, notifydate, notification_type, status]).then(data => {

        })

    }
    res.send({ 'message': 'inserted sucessfully' })
    pgr.end();
})

owner.get('/propertyViewsForOwner/:propertyId', (req, res) => {
    var propertyId = req.params.propertyId;
    var db = pgr(conntstr);
    db.any(`select * from fn_property_view_for_owner($1)`, propertyId).then(data => { res.send(data) })
})


module.exports = owner
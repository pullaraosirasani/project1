module.exports = {
    "connectionString": "postgres://postgres:nearluk@192.168.0.172:5432/nearluk"
}
var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var option = {
    promiseLib: promise
};

var pgr = require('pg-promise')(option)
var agent = express();
var config = require('./apiconfig')
var conntstr = config.connectionString




agent.all('*', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", '*');
    res.header("Access-Control-Allow-Headers", "Cache-Control,Pragma,Origin,Authorization,Content-Type,X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});
agent.use(bodyparser.json({ limit: '30mb' }));
agent.use(bodyparser.urlencoded({ limit: '30mb', extended: true }));


// ** owner_add_agent  ** //

agent.post('/insertOwnerAddAgent', (req, res, next) => {       //insert into owner_add_agent

    var property_id = req.body.property_id;
    var agent_username = req.body.agent_username;
    var status = 'P'
    console.log(property_id + '|' + agent_username)
    var db = pgr(conntstr);
    db.any('select fn_owner_add_agent_insert($1,$2,$3)', [property_id, agent_username, status]).then((data) => {
        res.send({ message: 'inserted' });
    })
    pgr.end();
})

agent.get("/getDataForNotification/:property_id/:agent_username", (req, res, next) => {
    var propertyid = req.params.property_id;
    var a_username = req.params.agent_username;

    var db = pgr(conntstr)
    db.any('select * from fn_owner_add_agent_select($1,$2)', [propertyid, a_username]).then((data) => {
        res.send(data)
    })
    pgr.end()
})

agent.post('/sendNotification/:property_id/:from/:to', (req, res, next) => {       //insert into owner_add_agent

    var pid = req.params.property_id;
    var from = req.params.from;
    var to = req.params.to;
    var dt = new Date();
    let month = dt.getMonth() + 1;
    date = dt.getFullYear() + '_' + month + '_' + dt.getDate();
    var status = 'Pending'

    var db = pgr(conntstr);
    db.any('select * from fn_sendnotifications_insert($1,$2,$3,$4,$5,$6)', [pid, from, to, date, 'unseen', 'request']).then((data) => {
        res.send({ message: 'inserted' });
    })
    pgr.end();
})

agent.delete('/deleteMyAgent/:property_id/:agent', (req, res, next) => {
    var propertyid = req.params.property_id;
    var agent_user_name = req.params.agent;
    var db = pgr(conntstr)
    db.any('select * from fn_owner_prop_agent_delete($1,$2)', [propertyid, agent_user_name]).then((data) => {
        res.send(data)
    })
    pgr.end();
})

agent.get("/getMyOwners/:agent_username", (req, res, next) => {
    var propertyArray = []
    var agent = req.params.agent_username;
    var db = pgr(conntstr)
    db.any("select * from fn_get_myowners($1)", agent).then((data) => {

        data.forEach(prop => {
            console.log(prop.property_id + "PROP")
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    prop['img'] = "http://localhost:4500/no_image.gif";
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    //  console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    // console.log(array[0])
                    res.send(propertyArray)
                }
            })

        })
    })

    pgr.end()
})

agent.get('/ListOfAgents/:city/:page', (req, res, next) => {//*****get agents details */
    var city = req.params.city;
    page = (req.params.page) * 10
    console.log(city)
    var propertyArray = []
    var db = pgr(conntstr);

    db.any("select * from fn_get_listofagents($1,$2)", [city, page]).then((data) =>
        data.forEach(prop => {
            myPath = path.join(__dirname, 'Profile/' + prop.username + '/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.username + "/" + files[0]
                    propertyArray.push(prop)
                    // console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    // console.log(propertyArray)
                    res.send(propertyArray)

                }
            })

        })
    )
    pgr.end();
})

agent.get('/MyAgents/:username/', (req, res, next) => {//*****get my agents details */
    var propertyArray = []

    
    var username = req.params.username;
    var db = pgr(conntstr);

    db.any("select * from fn_getActiveuser($1)", username).then((data) =>

        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    // console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    res.send(propertyArray)
                }
            })
            pgr.end();
            var db = pgr(conntstr);

            var profileArray = [];

            myPath = path.join(__dirname, 'Profile/' + prop.agent_username + '/');

            prop['pimg'] = "http://localhost:4500/" + prop.agent_username + '/' + prop.agent_username + '.png'
            profileArray.push(prop)


        })



    )
    pgr.end();

})

agent.get('/getDataForAgentNotification/:property_id/:from_username/:notification_type', (req, res, next) => {
    var property_id = req.params.property_id;
    var from = req.params.from_username;
    var type = req.params.notification_type;
    var db = pgr(conntstr);
    db.any('select * from fn_tenant_notifications_select($1,$2,$3)', [property_id, from, type]).then((data) => {
        res.send(data);
    })
    pgr.end();
})

agent.get('/dataToSendNotification/:property_id/:username', (req, res, next) => {
    var property_id = req.params.property_id;
    var username = req.params.username;
    var db = pgr(conntstr);
    db.any(" select * from fn_get_notifications($1,$2)", [property_id, username]).then((data) => {
        res.send(data);
    })
    pgr.end();
})


agent.get('/MyAgent/:property_id/:username', (req, res, next) => {//*****get my agents details */
    var propertyid = req.params.property_id;
    var a_username = req.params.username;
    var db = pgr(conntstr);

    db.any('select * from fn_owner_add_agent_Get($1,$2)', [propertyid, a_username]).then((data) =>
        res.send(data))
    pgr.end();
})

agent.get('/Agentsbasedonpid/:property_id', (req, res, next) => {//*****get my agents details based on pid */
    var id = req.params.property_id;
console.log(id)
    var db = pgr(conntstr);

    db.any('select * from fn_get_agentusername($1)', [id]).then((data) =>
        res.send(data))
    pgr.end();
})

module.exports = agent;
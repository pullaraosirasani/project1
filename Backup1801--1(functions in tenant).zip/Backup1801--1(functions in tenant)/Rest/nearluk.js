var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var option = {
    promiseLib: promise
};

var pgr = require('pg-promise')(option)
var nearluk = express();
var config = require('./apiconfig')
var conntstr = config.connectionString
var md5 = require('md5');


nearluk.all('*', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", '*');
    res.header("Access-Control-Allow-Headers", "Cache-Control,Pragma,Origin,Authorization,Content-Type,X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});

nearluk.use(bodyparser.json({ limit: '30mb' }));
nearluk.use(bodyparser.urlencoded({ limit: '30mb', extended: true }));


//** country **/

nearluk.get("/getAllCountries", (req, res, next) => {      //get all countries
    var db = pgr(conntstr);
    console.log('1')
    db.any("select * from fn_country_isd_all()").then((data) => {
        res.send(data);
    })
    pgr.end();
})

//** state **/

nearluk.get("/getAllStates", (req, res, next) => {      //get all states

    var db = pgr(conntstr);
    db.any("SELECT * from fn_state_all_select()").then((data) => {
        res.send(data);
    })
    pgr.end();
})

nearluk.get("/state/:country_id", (req, res, next) => {     //get states based on country_id
    var country_id = req.params.country_id;
    var db = pgr(conntstr);
    db.any("select * from fn_state_select($1)", country_id).then((data) => {
        res.send(data);
    })
    pgr.end();
})

//** city **/

nearluk.get("/getAllCities", (req, res, next) => {       //get all cities
    var db = pgr(conntstr);
    db.any("select * from fn_city_all_select()").then((data) => {
        res.send(data);
    })
    pgr.end();
})

nearluk.get("/city/:state_id", (req, res, next) => {        //get cities based on state_id
    var state_id = req.params.state_id;
    var db = pgr(conntstr);
    db.any("select * from fn_city_select($1)", state_id).then((data) => {
        res.send(data);
    })
    pgr.end();
})

//** area **/

// nearluk.get("/area/:id", (req, res, next) => {      //get areas based on city_id
//     var id = req.params.id
//     var db = pgr(conntstr)
//     db.any("select * from getArea($1)", id).then((data) => {
//         res.send(data)
//     })
//     pgr.end()
// })


nearluk.get("/areaByName/:cityName/:districtName/:state", (req, res, next) => {      //get areas based on city_id
    var cityName = req.params.cityName
    var districtName = req.params.districtName

    var state = req.params.state


    console.log(cityName)
    console.log(districtName)
    console.log(state)
    var db = pgr(conntstr)
    db.any("select * from fn_getareabycitydist($1,$2,$3)", [cityName, districtName, state]).then((data) => {
        res.send(data)

        console.log(data);
    })
    pgr.end()
})

nearluk.get("/areaByCityId/:id", (req, res, next) => {      //get areas based on city_id
    var id = req.params.id
    var db = pgr(conntstr)
    db.any("select * from fn_area_cityid_select($1)", id).then((data) => {
        res.send(data)
    })
    pgr.end()
})

//** currency **/

nearluk.get("/getAllCurrency/", (req, res, next) => {     //get all currency data
    var db = pgr(conntstr)
    db.any('select *from fn_country_isd_all()').then((data) => {
        res.send(data)
    })
    pgr.end()
})

nearluk.get("/currencyBasedOnCountry/:country", (req, res, next) => {     //get all currency based on country name
    var country = req.params.country;
    console.log(country)
    var db = pgr(conntstr)
    db.any('select *from fn_country_isd_select($1)', country).then((data) => {
        res.send(data)
    })
    pgr.end()
})

//** units **/

nearluk.get("/getAllUnits/", (req, res, next) => {        //get all units
    var db = pgr(conntstr)
    db.any("SELECT * from fn_units_select()").then((data) => {

        res.send(data)
    })
    pgr.end()
})

//** isd **/

nearluk.get("/getAllIsdNumbers/:country", (req, res, next) => {      //get all isd numbers
    var db = pgr(conntstr)
    var country = req.params.country;
    console.log(country)
    db.any("select * from fn_country_isd_select($1)", country).then((data) => {
        res.send(data)
    })
    pgr.end()
})

//** signup **/

nearluk.get('/getByUsername/:username', (req, res, next) => {     //get all data from signup based on username
    var username = req.params.username;
    var db = pgr(conntstr);
    console.log(username + 'PROFILE')
    db.any('select * from  fn_signup_select($1)', username).then((data) => {
        res.send(data)
    })
    pgr.end();

})




nearluk.put('/putProfileImages', (req, res, next) => { // put Images..
    var username = req.body.username;
    console.log(username)
    var img = req.body.image;
    // console.log(img)
    var db = pgr(conntstr)

    var dir = "./Profile/" + username + '/';
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir)
    }
    fName = username + ".png";
    fNameW = path.join(__dirname, 'Profile/' + username + '/' + fName);

    fs.writeFile(fNameW, img, 'base64', (err) => {
        if (err)
            console.log('Unable to write ..');
        else
            console.log('Saved the image');
    })
    res.send({ message: "updated" });
    pgr.end();
})

nearluk.get('/getByUsernameWithImage/:username', (req, res, next) => {
    var username = req.params.username;
    console.log(username)
    var propertyArray = []
    var db = pgr(conntstr);
    db.any('select *from fn_signup_uname_select($1)', username).then((data) => {
        data.forEach(prop => {
            myPath = path.join(__dirname, 'Profile/' + username + '/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + username + "/" + files[0]
                    propertyArray.push(prop)
                    // console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    // console.log(propertyArray)
                    res.send(propertyArray)

                }
            })

        })
    })
    pgr.end();

})


nearluk.get('/getByMobile/:mobile', (req, res, next) => {     //get all data from signup based on mobile
    var mobile = req.params.mobile;
    var db = pgr(conntstr);
    db.any('select * from fn_signup_select_mobile($1)', mobile).then((data) => {
        res.send(data)
    })
    pgr.end();

})

nearluk.get('/loginenc/:username/:password', (req, res) => {
    var password = req.params.password;
    var user = req.params.username;

    var encpassword = md5(password);
    var db = pgr(conntstr);
    db.any('select * from fn_signup_select_username($1)', user).then(data => {
        if (data.length == 1) {
            var dbpassword = data[0].pasword;
            var decrept1 = dbpassword.substr(3, 3);

            console.log(decrept1 + 'decrept1')


            var decrept2 = dbpassword.substr(9 + 0);
            var dbfpassword = decrept1 + decrept2;
            console.log('userpassword: ' + encpassword);
            console.log('database password:' + dbfpassword);
            if (encpassword === dbfpassword) {
                // db.any('select * from signup where username=$1', user).then(data => {
                //     res.send(data);
                // })
                res.send(data);
                console.log('data 1')
            }
            else {
                res.send([]);
                console.log('data 2')
            }

            console.log(dbfpassword);
        }
        else {
            res.send(data);
            console.log('data 3')
        }
    })
    pgr.end();
})

nearluk.post('/signup', (req, res, next) => {       //insert into signup
    var name = req.body.name;
    var username = req.body.username
    var password = req.body.password
    var mobile = req.body.mobile
    var isd = req.body.isd
    var user_type = req.body.user_type;
    var status = 'Active'
    var database = pgr(conntstr);

    var encp = md5(password);

    var randomnumber = Math.random().toString(36).substring(2, 5) + Math.random().toString(36).substring(2, 5);
    var firstrandomen = randomnumber.substr(0, 3); // Gets the first part
    var secondrandomen = randomnumber.substr(3, 3);
    console.log(firstrandomen)
    console.log(secondrandomen)
    console.log(randomnumber)

    var firsthalfpass = encp.substr(0, 3); // Gets the first part
    var secondhalfpass = encp.substr(3 + 0);

    console.log(encp + "     shiva")
    console.log(firsthalfpass)
    console.log(secondhalfpass)


    password = firstrandomen + firsthalfpass + secondrandomen + secondhalfpass


    console.log(password)
    var decrept1 = password.substr(3, 3);

    console.log(decrept1 + 'decrept1')

    // Gets the first part
    var decrept2 = password.substr(9 + 0);
    console.log(decrept1 + decrept2 + 'shiva')


    //    var decrept1 = password.replace(firstrandomen,'');
    //    var decrept2 = decrept1.replace(secondrandomen,'');

    //    console.log(decrept2+'     shiva')

    // database.any('select fn_signup_insert($1,$2,$3,$4,$5,$6,$7)', [name, username, password, mobile, status, isd, user_type]).then((data) => {
    //     res.send({ message: " inserted...." })
    // })
    database.any('select fn_signup_insert($1,$2,$3,$4,$5,$6,$7,$8)', [name, username, password, mobile, status, isd, user_type, username]).then((data) => {
        res.send({ message: " inserted...." })
    })
    pgr.end();
})

// nearluk.post('/signup', (req, res, next) => {       //insert into signup
//     var name = req.body.name;
//     var username = req.body.username
//     var password = req.body.password
//     var mobile = req.body.mobile
//     var isd = req.body.isd
//     var user_type = req.body.user_type;
//     var status = 'Active'
//     var database = pgr(conntstr);
//     database.any('select fn_signup_insert($1,$2,$3,$4,$5,$6,$7)', [name, username, password, mobile, status, isd, user_type]).then((data) => {
//         res.send({ message: " inserted...." })
//     })
//     pgr.end();
// })

nearluk.put('/updateProfile/:username', (req, res, next) => {      //update signup based on username
    console.log(req.body)
    var name = req.body.name;
    var username = req.params.username
    var address = req.body.address
    console.log(address)
    var gender = req.body.gender
    var occupation = req.body.occupation
    var dob = req.body.dob
    var country = req.body.country
    var state = req.body.state
    var city = req.body.city
    var database = pgr(conntstr);
    database.any('select fn_signup_update($1,$2,$3,$4,$5,$6,$7,$8,$9)', [name, address, gender, occupation, dob, country, state, city, username]).then((data) => {
        res.send({ message: " updated...." })
    })
    // console.log(req.body)
    pgr.end();
})

nearluk.put('/updatePassword/:username', (req, res, next) => {      //update password based on username
    var username = req.params.username;
    var password = req.body.password;
    var db = pgr(conntstr);
    var encp = md5(password);

    var randomnumber = Math.random().toString(36).substring(2, 5) + Math.random().toString(36).substring(2, 5);
    var firstrandomen = randomnumber.substr(0, 3); // Gets the first part
    var secondrandomen = randomnumber.substr(3, 3);
    console.log(firstrandomen)
    console.log(secondrandomen)
    console.log(randomnumber)

    var firsthalfpass = encp.substr(0, 3); // Gets the first part
    var secondhalfpass = encp.substr(3 + 0);

    console.log(encp + "     shiva")
    console.log(firsthalfpass)
    console.log(secondhalfpass)


    password = firstrandomen + firsthalfpass + secondrandomen + secondhalfpass


    console.log(password)
    var decrept1 = password.substr(3, 3);

    console.log(decrept1 + 'decrept1')

    // Gets the first part
    var decrept2 = password.substr(9 + 0);
    console.log(decrept1 + decrept2 + 'shiva')

    db.any("select  fn_signup_update($1,$2)", [password, username]).then((data) => {
        res.send({ message: " updated password...." })
    })
    pgr.end();
})

module.exports = nearluk
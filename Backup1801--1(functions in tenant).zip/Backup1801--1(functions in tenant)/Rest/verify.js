var express = require('express');
var bodyparser = require('body-parser');
var qs = require("querystring");
var http = require("http");
const bodyParser = require("body-parser");
var path = require('path')
var verify = express.Router();

verify.use(bodyParser.urlencoded({
    extended: true
}));
verify.use(bodyparser.json())




verify.get('/:key/:otp', (req, res, next) => {
    var id = req.params.key
    var otp = req.params.otp

    var collect
    var options = {
        "method": "GET",
        "hostname": "2factor.in",
        "port": null,
        "path": null,
        "headers": {
            "content-type": "application/x-www-form-urlencoded"
        }
    };
    //"/API/V1/2130a4c4-d110-11e8-a895-0200cd936042/SMS/VERIFY/ef7fe825-d115-11e8-a895-0200cd936042/436401"

    options.path = "/API/V1/96ab36da-f79d-11e8-a895-0200cd936042/SMS/VERIFY/" + id + "/" + otp
    var req = http.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);
        });

        res.on("end", function () {
            var body = Buffer.concat(chunks);

            collect = body
            vinod()
        });

    });
    function vinod() {

        var a = collect.toString()
        var b = JSON.parse(a)
        console.log(b)
        res.send(a)
    }


    req.write(qs.stringify({}));
    req.end();

})


module.exports = verify;









// var qs = require("querystring");
// var http = require("http");

// var options = {
//     "method": "GET",
//     "hostname": "2factor.in",
//     "port": null,
//     "path": "/API/V1/2130a4c4-d110-11e8-a895-0200cd936041/SMS/VERIFY/ef7fe825-d115-11e8-a895-0200cd936042/436401",
//     "headers": {
//         "content-type": "application/x-www-form-urlencoded"
//     }
// };

// var req = http.request(options, function (res) {
//     var chunks = [];

//     res.on("data", function (chunk) {
//         chunks.push(chunk);
//     });

//     res.on("end", function () {
//         var body = Buffer.concat(chunks);
//         console.log(body.toString());
//     });

// });



// req.write(qs.stringify({}));
// req.end();
var express = require("express");
var path = require('path')
var admin = require('./admin')
var agent = require('./agent')
var nearluk = require('./nearluk')
var owner = require('./owner')
var property = require('./property')
var tenant = require('./tenant')
var otp = require('./otp')
var verify = require('./verify')


var app = express();

app.set("port", process.env.PORT || 4500)
app.all('*', function (req, res, next) {

    res.header("Access-Control-Allow-Origin", '*');

    res.header("Access-Control-Allow-Headers", "Cache-Control,Pragma, Origin, Authorization, Content-Type, X-Requested-With");

    res.header("Access-Control-Allow-Methods", "*");

    return next();
});


app.use('/admin', admin)
app.use('/agent', agent)
app.use('/nearluk', nearluk)
app.use('/owner', owner)
app.use('/property', property)
app.use('/tenant', tenant)
app.use('/otp', otp)
app.use('/verify', verify)



app.use(express.static(path.resolve(__dirname, 'Gallery')));

app.use(express.static(path.resolve(__dirname, 'Flag')));

app.use(express.static(path.resolve(__dirname, 'Facilities')));

app.use(express.static(path.resolve(__dirname, 'Profile')));

app.use(express.static(path.resolve(__dirname, 'videos')));

app.use(express.static(path.resolve(__dirname, 'propertyimages')));

app.use(express.static(path.resolve(__dirname, '')));

app.post('/img', (req, res) => {
    console.log('im');
    console.log(req.body);
    res.send('upload');
})

app.listen(app.get('port'), (err) => {
    if (err) {
        console.log("server not started")
    } else {
        console.log("server  started http://localhost:" + app.get('port'))
    }
})
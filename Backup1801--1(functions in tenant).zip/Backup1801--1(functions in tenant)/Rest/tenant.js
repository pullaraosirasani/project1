var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var option = {
    promiseLib: promise
};

var pgr = require('pg-promise')(option)
var tenant = express();
var config = require('./apiconfig')
var conntstr = config.connectionString




// tenant.use(function (req, res, next) { //allow cross origin requests
//     res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
//     res.header("Access-Control-Allow-Origin", "http://localhost:4200");
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//     res.header("Access-Control-Allow-Credentials", true);
//     next();
// });

tenant.all('*', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", '*');
    res.header("Access-Control-Allow-Headers", "Cache-Control,Pragma,Origin,Authorization,Content-Type,X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});

tenant.use(bodyparser.json({ limit: '30mb' }));
tenant.use(bodyparser.urlencoded({ limit: '30mb', extended: true }));


//** Home Page */

// tenant.get('/homeget',(req,res,next)=>{//*****homeGet */
//     var db = pgr(conntstr);
//     db.any('select * from property_details oap join Property_Types pt on oap.property_type_id = pt.property_type_id  join property_address pa on pa.property_id = oap.property_id left join city c on pa.city = c.city_id ').then((data) =>
//     res.send(data))

// pgr.end();
// })

tenant.get('/getCompare/:property_id1/', (req, res, next) => {
    var property_id1 = req.params.property_id1;
    var array = []
    array = property_id1.split(",")
    var propertyArray = []
    var db = pgr(conntstr);

    db.any('select t1.*,t3.*,t2.*,t4.* from(select oap.username, oap.property_id, oap.property_name,oap.facing,oap.price,oap.property_type_id,oap.description,oap.nearluk_verified,oap.status,oap.posted_date,oap.units_id,oap.currency,oap.priority,oap.propertyarea,oap.construction_status,pt.property_type,array_to_json(array_agg(f.facility_name)) as facilities,array_to_json(array_agg(f.facility_id)) as facilities_id,u.units,c.currency_symbol from property_details oap left outer join Property_Types pt on oap.property_type_id = pt.property_type_id left outer join post_property_facilities ppf on ppf.property_id=oap.property_id  left outer join facility f on f.facility_id=ppf.facility_id left outer join units u on u.units_id=oap.units_id left outer join currency c on c.id=oap.currency group by oap.property_id,pt.property_type,u.units,c.currency_symbol)as t1 left outer join(select oap.property_id,array_to_json(array_agg(pam.property_amenity)) as amenities,(array_agg(pam.property_amenity_id)) as amenities_id,(array_agg(ppm.amenityvalue)) as amenities_value from property_details oap left outer join Post_Property_Amenities ppm on ppm.property_id=oap.property_id join property_amenities pam on pam.property_amenity_id=ppm.property_amenity_id group by oap.property_id) as t2 on t1.property_id=t2.property_id left outer join (select distinct pa.*,c.city_name,co.country_name,s.state_name,a.area_name from property_address pa left outer join city c on c.city_id=pa.city left outer join country co on co.country_id=pa.country left outer join state s on s.state_id=pa.state left outer join area a on a.area_id=pa.area)as t3 on t3.property_id=t1.property_id left outer join (select * from property_location_map) as  t4 on t1.property_id=t4.property_id where t1.property_id in ($1,$2,$3)', array).then((data) => {

        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    prop['img'] = "http://localhost:4500/no_image.gif"
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    //  console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    // console.log(array[0])
                    res.send(propertyArray)
                }
            })

        })
    })
    pgr.end();
})


// tenant.get('/homeget', (req, res, next) => {
//     var propertyArray = []

//     var db = pgr(conntstr);
//     db.any(`select p.*,c.*,ar.area_id,ar.area_name,ar.city_id,pt.*,td.count,AVG(a.rating) as rating,
//     gc.community_name,plm.latitude,plm.longitude from property_details p left join
//     rating a on p.property_id=a.property_id join Property_Types pt on p.property_type_id = pt.property_type_id 
//     join property_address pa on pa.property_id = p.property_id 
//     left join city c on pa.city = c.city_id left join area ar on pa.area=ar.area_id left join trending td on p.property_id = td.property_id left join property_location_map plm on p.property_id=plm.property_id left join property_community_mapping pcm on pcm.property_id = p.property_id left join gated_community gc on pcm.cm_id = gc.cm_id GROUP BY p.property_id,c.city_id,c.city_name,c.state_id,ar.area_id,ar.area_name,ar.city_id,pt.property_type_id,pt.property_type,plm.latitude,plm.longitude,td.property_id,td.count,gc.community_name
//     having p.status='Active' order by posted_date desc`).then((data) => {
//         data.forEach(prop => {
//             myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');
//             //{ lat: 24.799524, lng: 120.975017 }
//             fs.readdir(myPath, (err, files) => {

//                 if (files == undefined) {
//                     // var latLng = {}
//                     // latLng['lat'] = parseFloat(prop.latitude)
//                     // latLng['lng'] = parseFloat(prop.longitude)
//                     // prop['destination'] = latLng

//                     prop['img'] = "http://localhost:4500/Gallery/logo.png"

//                     propertyArray.push(prop)

//                 }
//                 else {

//                     var latLng = {}
//                     latLng['lat'] = parseFloat(prop.latitude)
//                     latLng['lng'] = parseFloat(prop.longitude)
//                     prop['destination'] = latLng

//                     prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
//                     propertyArray.push(prop)

//                 }
//                 if (data.length == propertyArray.length) {
//                     res.send(propertyArray)
//                 }
//             })

//         })
//     })
//     pgr.end();
// })

tenant.get('/homeget/:page', (req, res, next) => {
    var propertyArray = []
    k = (req.params.page) * 10
    console.log(req.params.page)
    var db = pgr(conntstr);
    db.any(`select p.*,c.*,ar.area_id,ar.area_name,ar.city_id,pt.*,td.count,cu.country_currency_symbol,AVG(a.rating) as rating,
    gc.community_name,plm.latitude,plm.longitude from property_details p left join
    rating a on p.property_id=a.property_id join Property_Types pt on p.property_type_id = pt.property_type_id 
    join property_address pa on pa.property_id = p.property_id 
    left join city c on pa.city = c.city_id  left join country_isd cu on p.currency = cu.country_id left join area ar on pa.area=ar.area_id left join trending td on p.property_id = td.property_id left join property_location_map plm on p.property_id=plm.property_id left join property_community_mapping pcm on pcm.property_id = p.property_id left join gated_community gc on pcm.cm_id = gc.cm_id GROUP BY p.property_id,c.city_id,c.city_name,c.state_id,ar.area_id,ar.area_name,ar.city_id,pt.property_type_id,pt.property_type,plm.latitude,plm.longitude,td.property_id,td.count,gc.community_name,cu.country_currency_symbol
    having p.status='Active' order by posted_date desc limit $1`, k).then((data) => {
        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');
            //{ lat: 24.799524, lng: 120.975017 }
            fs.readdir(myPath, (err, files) => {

                if (files == undefined) {
                    // var latLng = {}
                    // latLng['lat'] = parseFloat(prop.latitude)
                    // latLng['lng'] = parseFloat(prop.longitude)
                    // prop['destination'] = latLng

                    prop['img'] = "http://localhost:4500/no_image.gif"

                    propertyArray.push(prop)

                }
                else {

                    var latLng = {}
                    latLng['lat'] = parseFloat(prop.latitude)
                    latLng['lng'] = parseFloat(prop.longitude)
                    prop['destination'] = latLng

                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)

                }
                if (data.length == propertyArray.length) {
                    res.send(propertyArray)
                }
            })

        })
    })
    pgr.end();
})


tenant.get('/averagebyarea/:propertytype/:area', (req, res) => {
    var propertytype = req.params.propertytype;
    var area = req.params.area;
    var db = pgr(conntstr);
    db.any(`
    select pd.property_type_id,pd.units_id,count(pd.property_id) as propertycount,c.country_currency_symbol,(avg(pd.price)/avg(pd.propertyarea)) as average,a.area_name,u.units
    from property_details pd left join country_isd c on c.country_id=pd.currency left join  property_address pa on pd.property_id=pa.property_id
    left join area a on a.area_id=pa.area
    left join units u on pd.units_id=u.units_id
    group by pd.units_id,pa.area,a.area_name,c.country_currency_symbol,pd.property_type_id,u.units
    having pa.area=$1 and pd.property_type_id=$2`, [area, propertytype]).then(data => {
        res.send(data);
    })
    pgr.end();
})

tenant.get('/map/:property_id', (req, res, next) => {//*****homeMap */
    var property_id = req.params.property_id;
    var db = pgr(conntstr);
    db.any('select * from  fn_maps_by_propertyid($1)', [property_id]).then((data) => {
console.log(data);
        var latLng = {}
        latLng['lat'] = parseFloat(data[0].lat)
        latLng['lng'] = parseFloat(data[0].lng)
        data[0]['destination'] = latLng

        console.log(latLng)
        res.send(data)
    })
    pgr.end();
})
// tenant.get('/homeget', (req, res, next) => {
//     var propertyArray = []
//     var db = pgr(conntstr);
//     db.any("select p.*,c.*,pt.*,td.count,AVG(a.rating) as rating,gc.community_name  from property_details p left join rating a on p.property_id=a.property_id join Property_Types pt on p.property_type_id = pt.property_type_id join property_address pa on pa.property_id = p.property_id left join city c on pa.city = c.city_id left join trending td on p.property_id = td.property_id left join property_community_mapping pcm on pcm.property_id = p.property_id left join gated_community gc on pcm.cm_id = gc.cm_id GROUP BY p.property_id,c.city_id,c.city_name,c.state_id,pt.property_type_id,pt.property_type,td.property_id,td.count,gc.community_name having p.status='Active'").then((data) => {
//         data.forEach(prop => {
//             myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

//             fs.readdir(myPath, (err, files) => {
//                 if (files == undefined) {
//                     prop['img'] = "http://localhost:4500/logo.png"
//                     propertyArray.push(prop)
//                 }
//                 else {
//                     prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
//                     propertyArray.push(prop)
//                     // console.log(prop)
//                 }
//                 if (data.length == propertyArray.length) {
//                     res.send(propertyArray)
//                 }
//             })

//         })
//     })
//     pgr.end();
// })

// tenant.get('/images/:id', (req, res, next) => {
//     var pid=req.params.id
//     //NL18111616116146
//     myPath = path.join(__dirname, 'Gallery/' + pid + '/Images/');
//     var arr = [];
//     fs.readdir(myPath, (err, files) => {
//         files.forEach(file => {
//             let a = 'http://localhost:4500/'+pid+'/Images/' + file
//             arr.push(a)
//         });
//         res.send(arr)
//     })
// })

tenant.get('/images/:id', (req, res, next) => {
    var pid = req.params.id
    //NL18111616116146
    myPath = path.join(__dirname, 'Gallery/' + pid + '/Images/');
    var arr = [];
    fs.readdir(myPath, (err, files) => {
        if (files) {
            files.forEach(file => {
                let a = 'http://localhost:4500/' + pid + '/Images/' + file
                arr.push(a)
            });
            res.send(arr)
        }

    })
})

tenant.put('/UpdateMyProperty/:property_id', (req, res, next) => {
    var pid = req.params.property_id;
    var db = pgr(conntstr);
    db.any("select fn_property_status_update($1)", pid).then(() => {
        res.send({ 'message': 'updated' });
    })
    pgr.end();
})

tenant.get('/getLikes/:property_id/:likes_status', (req, res, next) => {//*****homeGet */
    var property_id = req.params.property_id;
    var likes_status = req.params.likes_status;
    console.log(likes_status)
    var db = pgr(conntstr);
    db.any('select * from fn_property_likes_select($1,$2)', [property_id, likes_status]).then((data) => {
        res.send(data)
    })

    pgr.end();
})

tenant.get('/getLikeStatus/:property_id/:username', (req, res, next) => {//*****homeGet */
    var property_id = req.params.property_id;
    var username = req.params.username;

    var db = pgr(conntstr);
    db.any('select * from fn_property_likes_select($1,$2)', [property_id, username]).then((data) => {

        res.send(data)

    })

    pgr.end();
})

tenant.get('/cityAutoComplete/:value', (req, res, next) => {//***** */
    var ctyArray = [];
    var value = req.params.value;
    var db = pgr(conntstr);

    db.any("select * from fn_cityautofill_select($1)", value).then((data) => {
        data.forEach(element => {
            ctyArray.push(element.usercityname)
        });
        // console.log(ctyArray)
        res.send(ctyArray)
    }
    )
    pgr.end();
})

// tenant.get('/cityid/:country', (req, res) => {
//     var country = req.params.country;
//     var db = pgr(conntstr);
//     db.any("select city_id from city where city_name=$1", country).then((data) => {
//         res.send(data);
//     })
//     pgr.end();
// })


tenant.get('/cityid/:cityname', (req, res) => {
    var cityname = JSON.parse(req.params.cityname);
    console.log(JSON.parse(req.params.cityname))

    console.log(cityname.city
    )
    cityname.city = cityname.city.replace('*', '/')
    cityname.city = cityname.city.replace('*', '/')
    console.log(cityname.city
    )
    var str = cityname.city;
    var result = str.split(",");

    cityName = result[0]
    stateName = result[1]


    console.log(result[0])
    console.log(result[1])
    var db = pgr(conntstr);
    db.any("select * from fn_cityid_bycitystate_select($1,$2)", [cityName, stateName]).then((data) => {
        res.send(data);

        console.log(data)
    })
    pgr.end();
})
// tenant.get('/filterssearch/:propertyType/:facing/:city/:minprice/:maxprice/:verify/:rating', (req, res, next) => {//***** */
//     var propertyType = req.params.propertyType;
//     var facing = (req.params.facing);
//     var minprice = req.params.minprice;
//     var maxprice = req.params.maxprice;
//     var verify = req.params.verify;
//     var rating = req.params.rating;

//     console.log(verify)

//     console.log(propertyType + 'hello')
//     if (propertyType != 'undefined') {
//         propertyType = parseInt(propertyType)

//     }


//     if (propertyType == 'undefined') {
//         propertyType = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
//     }
//     if (facing == 'undefined') {
//         facing = ['East', 'North', 'South', 'West', 'southeast', 'southwest', 'northeast', 'northwest']
//     }

//     if (minprice == 'undefined') {
//         minprice = 0
//     }
//     if (maxprice == 'undefined') {
//         maxprice = 1000000000
//     }
//     console.log(verify + '11')
//     if (verify == 'undefined') {

//         console.log(verify + '22')
//         verify = ['N', 'V']
//     }


//     var city = req.params.city;
//     console.log('shivaaaa' + city);



//     var city1;

//     facingarray = facing

//     propertyarray = propertyType


//     // console.log(propertyType + ' ' + facing + ' ' + city)
//     var db = pgr(conntstr);
//     console.log("__________")
//     console.log(city)


//     // db.any("select city_id from city where city_name=$1", city).then((data) => {
//     //     console.log(data);
//     //     city1 = data[0].city_id;

//     city1 = city;
//     console.log('----');
//     console.log(city1);
//     console.log(city1 + "vvvv")
//     var pt = `{` + (propertyType) + `}`;
//     var fc = `{` + (facing) + `}`;
//     var p1 = [propertyType];

//     var verf1 = `{` + (verify) + `}`;
//     var f1 = [facing];



//     console.log(city1)
//     console.log(pt)
//     console.log(fc)
//     console.log(minprice)
//     console.log(maxprice)
//     console.log(verf1)
//     console.log(rating)


//     if (rating != 0) {

//         db.any("select * from filterswithrating($1,$2,$3,$4,$5,$6,$7)", [city1, pt, fc, minprice, maxprice, verf1, rating]).then((data) => {
//             console.log(data);
//             var propertyArray = []
//             data.forEach(prop => {
//                 myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

//                 fs.readdir(myPath, (err, files) => {
//                     if (files == undefined) {
//                         propertyArray.push(prop)
//                     }
//                     else {
//                         prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
//                         propertyArray.push(prop)
//                         //  console.log(prop)
//                     }
//                     if (data.length == propertyArray.length) {
//                         // console.log(array[0])
//                         res.send(propertyArray)
//                     }
//                 })

//             })
//             // res.send(data);
//             pgr.end();
//         })
//     }
//     else {
//         db.any("select * from filterswithoutrating($1,$2,$3,$4,$5,$6)", [city1, p1, fc, minprice, maxprice, verf1]).then((data) => {
//             console.log(data);
//             var propertyArray = []
//             data.forEach(prop => {
//                 myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

//                 fs.readdir(myPath, (err, files) => {
//                     if (files == undefined) {
//                         propertyArray.push(prop)
//                     }
//                     else {
//                         prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
//                         propertyArray.push(prop)
//                         //  console.log(prop)
//                     }
//                     if (data.length == propertyArray.length) {
//                         // console.log(array[0])
//                         res.send(propertyArray)
//                     }
//                 })

//             })
//             // res.send(data);
//             pgr.end();
//         })
//     }





//     // }
//     // )
// })

tenant.get('/filterssearch/:propertyType/:facing/:city/:minprice/:maxprice/:verify/:rating/:page', (req, res, next) => {//***** */

    var k = (req.params.page) * 10

    var propertyType = req.params.propertyType;
    var facing = (req.params.facing);
    var minprice = req.params.minprice;
    var maxprice = req.params.maxprice;
    var verify = req.params.verify;
    var rating = req.params.rating;

    console.log(verify)

    console.log(propertyType + 'hello')
    if (propertyType != 'undefined') {
        propertyType = parseInt(propertyType)

    }


    if (propertyType == 'undefined') {
        propertyType = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    }
    if (facing == 'undefined') {
        facing = ['East', 'North', 'South', 'West', 'southeast', 'southwest', 'northeast', 'northwest']
    }

    if (minprice == 'undefined') {
        minprice = 0
    }
    if (maxprice == 'undefined') {
        maxprice = 1000000000
    }
    console.log(verify + '11')
    if (verify == 'undefined') {

        console.log(verify + '22')
        verify = ['N', 'V']
    }


    var city = req.params.city;
    console.log('shivaaaa' + city);



    var city1;

    facingarray = facing

    propertyarray = propertyType


    // console.log(propertyType + ' ' + facing + ' ' + city)
    var db = pgr(conntstr);
    console.log("__________")
    console.log(city)


    // db.any("select city_id from city where city_name=$1", city).then((data) => {
    //     console.log(data);
    //     city1 = data[0].city_id;

    city1 = city;
    console.log('----');
    console.log(city1);
    console.log(city1 + "vvvv")
    var pt = `{` + (propertyType) + `}`;
    var fc = `{` + (facing) + `}`;
    var p1 = [propertyType];

    var verf1 = `{` + (verify) + `}`;
    var f1 = [facing];



    console.log(city1)
    console.log(pt)
    console.log(fc)
    console.log(minprice)
    console.log(maxprice)
    console.log(verf1)
    console.log(rating)


    if (rating != 0) {

        db.any("select * from fn_filterswithratingpagination($1,$2,$3,$4,$5,$6,$7,$8)", [city1, pt, fc, minprice, maxprice, verf1, rating, k]).then((data) => {
            console.log(data);
            var propertyArray = []
            data.forEach(prop => {
                myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

                fs.readdir(myPath, (err, files) => {
                    if (files == undefined) {
                        prop['img'] = "http://localhost:4500/no_image.gif";
                        propertyArray.push(prop)
                    }
                    else {
                        prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                        propertyArray.push(prop)
                        //  console.log(prop)
                    }
                    if (data.length == propertyArray.length) {
                        // console.log(array[0])
                        res.send(propertyArray)
                    }
                })

            })
            // res.send(data);
            pgr.end();
        })
    }
    else {
        db.any("select * from fn_filterswithoutratingpagination($1,$2,$3,$4,$5,$6,$7)", [city1, p1, fc, minprice, maxprice, verf1, k]).then((data) => {
            console.log(data);
            var propertyArray = []
            data.forEach(prop => {
                myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

                fs.readdir(myPath, (err, files) => {
                    prop['img'] = "http://localhost:4500/no_image.gif"
                    if (files == undefined) {
                        propertyArray.push(prop)
                    }
                    else {
                        prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                        propertyArray.push(prop)
                        //  console.log(prop)
                    }
                    if (data.length == propertyArray.length) {
                        // console.log(array[0])
                        res.send(propertyArray)
                    }
                })

            })
            // res.send(data);
            pgr.end();
        })
    }





    // }
    // )
})


tenant.get('/getpropertydetails/:username/:page', (req, res, next) => {//*****getpropertydetails */
    var propertyArray = []
    page = (req.params.page) * 10
    var username = req.params.username;
    var db = pgr(conntstr);

    db.any("select * from fn_getmypropertys($1,$2)", [username, page]).then((data) => {
        // db.any("select pd.*,pt.*,tn.property_id,array_to_json(array_agg(tn.from_username))as from_username,array_to_json(array_agg(tn.to_username))as to_username,array_to_json(array_agg(tn.notification_type)) from property_details pd left join property_types pt on pd.property_type_id=pt.property_type_id left join tenant_notifications tn on tn.property_id=pd.property_id group by pd.property_id,pt.property_type_id,tn.property_id,tn.status having pd.username='naidu@gmail.com' and pd.status='Active' order by posted_date desc", username).then((data) => {
        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    prop['img'] = "http://localhost:4500/no_image.gif";
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0];
                    propertyArray.push(prop)
                    // console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    res.send(propertyArray)
                }
            })

        })
    })
    pgr.end();
})



tenant.post('/LikePost/like/post/:property_id/:username/:likes_status', (req, res, next) => {         // post bidding data
    var property_id = req.params.property_id;
    var username = req.params.username;

    var likes_status = req.params.likes_status;


    // console.log(property_id + username + likes_status)
    var db = pgr(conntstr);
    db.any('select fn_property_likes_insert($1,$2,$3)', [property_id, username, likes_status]).then((data) => {
        res.send({
            message: " Inserted Sucessfully"
        });
    });
    pgr.end();
})


tenant.put('/updateLike/:property_id/:username/:likes_status', (req, res, next) => {       //update tenant_notifications
    var property_id = req.params.property_id;
    var username = req.params.username;
    var likes_status = req.params.likes_status;
    console.log(property_id + username + likes_status)

    var db = pgr(conntstr);
    db.any("select fn_property_likes_update($3,$1,$2)", [property_id, username, likes_status]).then((data) => {
        res.send(data);
    })
    pgr.end();
})

tenant.put('/enableBidding/:property_id/:status', (req, res, next) => { //update tenant_notifications
    var property_id = req.params.property_id;
    var bidding = req.params.status;
    console.log(property_id + bidding)

    var db = pgr(conntstr);
    db.any("select fn_property_bidding_details_update($1,$2)", [property_id, bidding]).then(() => {
        res.send({ message: 'updated' });
    })
    pgr.end();
})


//** enquiry_form **/

tenant.get("/getDataInEnquiryForm/:username", (req, res, next) => { //get enquiry from data by username
    var username = req.params.username

    var db = pgr(conntstr)
    db.any("select * from fn_view_enquiryform($1)", username).then((data) => {
        res.send(data)
    })
    pgr.end();
})


// tenant.get("/getRecommendationsData/:enqObj", (req, res, next) => {     //get enquiry from data by username
//     var propertyArray = []
//     var property_type_id = JSON.parse(req.params.enqObj).property_type_id;
//     var country = JSON.parse(req.params.enqObj).country;
//     var state = JSON.parse(req.params.enqObj).state;
//     var city = JSON.parse(req.params.enqObj).city;
//     var min_price = JSON.parse(req.params.enqObj).min_price;
//     var max_price = JSON.parse(req.params.enqObj).max_price;
//     var db = pgr(conntstr)
//     db.any("select *from property_details p join property_types pt on p.property_type_id=pt.property_type_id join property_address pa on p.property_id=pa.property_id join country c on c.country_id=pa.country join state s on s.state_id=pa.state join city ci on ci.city_id=pa.city join area a on a.area_id=pa.area where p.property_type_id=$1 and c.country_id=$2 and s.state_id=$3 and ci.city_id=$4 and p.price>=$5 and p.price<=$6", [property_type_id, country, state, city, min_price, max_price]).then((data) => {

//         data.forEach(prop => {
//             myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

//             fs.readdir(myPath, (err, files) => {
//                 if (files == undefined) {
//                     prop['img'] = "http://localhost:4500/no_image.gif";
//                     propertyArray.push(prop)
//                 }
//                 else {
//                     prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
//                     propertyArray.push(prop)
//                     // console.log(prop)
//                 }
//                 if (data.length == propertyArray.length) {
//                     res.send(propertyArray)
//                 }
//             })

//         })
//     })
//     pgr.end();
// })

tenant.get("/getRecommendationsData1/:enqObj", (req, res, next) => { //get enquiry from data by username
    var propertyArray = []

    var country = JSON.parse(req.params.enqObj).country;

    var db = pgr(conntstr)
    db.any("select * from fn_view_getrecommendation($1)", [country]).then((data) => {

        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    prop['img'] = "http://localhost:4500/no_image.gif";
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    // console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    res.send(propertyArray)
                }
            })

        })
        // res.send(data);
    })
    pgr.end();
})

tenant.post('/', (req, res, next) => {          //insert data into enquiry_form
    var username = req.body.username;
    var property_type_id = req.body.property_type_id;
    var min_price = req.body.min_price;
    var max_price = req.body.max_price;
    var facing = req.body.facing;
    var country = req.body.country;
    var state = req.body.state;
    var city = req.body.city;
    var area = req.body.area;

    var db = pgr(conntstr);
    db.any("select fn_enquiry_form_insert($1,$2,$3,$4,$5,$6,$7,$8,$9)", [username, property_type_id, min_price, max_price, facing, country, state, city, area]).then((data) => {
        res.send(data);
    })
    pgr.end();
})

tenant.put('/username/:username', (req, res, next) => {     //update enquiry_form based on username
    var property_type_id = req.body.property_type_id;
    var username = req.params.username;
    var min_price = req.body.min_price;
    var max_price = req.body.max_price;
    var facing = req.body.facing;
    // var landmarks = req.body.landmarks;
    var country = req.body.country;
    var state = req.body.state;
    var city = req.body.city;
    var area = req.body.area;
    // var currency = req.body.currency;

    var db = pgr(conntstr);

    db.any('select fn_enquiry_form_update($1,$2,$3,$4,$5,$6,$7,$8,$9)', [property_type_id, min_price, max_price, facing, country, state, city, area, username]).then((data) => {
        res.send(data)

    })
    pgr.end();
})

//** tenant_notifications **/

tenant.post('/tenant_notification', (req, res, next) => {          //insert into tenant_notifications

    var property_id = req.body.property_id;
    var from_username = req.body.from_username;
    var to_username = req.body.to_username;
    var message = req.body.message;
    var notifydate = req.body.notifydate;
    var status = "u";

    var db = pgr(conntstr);
    db.any("select fn_tenant_notifications_insert($1,$2,$3,$4,$5,$6);", [property_id, from_username, to_username, message, notifydate, status]).then((data) => {
        res.send({
            "message": "inserted"
        })
    })
    pgr.end();

})

tenant.put('/update/:to_username', (req, res, next) => {       //update tenant_notifications
    var to_username = req.params.to_username;
    var status = "s";
    var db = pgr(conntstr);
    db.any("select fn_tenant_notifications_update($1,$2)", [status, to_username]).then((data) => {
        res.send(data);

    })
    pgr.end();
})

//**rating **/

tenant.post('/insertRating/:property_id/:uname', (req, res, next) => {        //insert rating
    property_id = req.params.property_id;
    uname = req.params.uname;
    rating = req.body.rating;
    var dt = new Date();
    let month = dt.getMonth() + 1;
    let date = dt.getFullYear() + '-' + month + '-' + dt.getDate();
    var db = pgr(conntstr);

    db.any("select fn_rating_insert($1,$2,$3,$4)", [property_id, rating, uname, date]).then((data) => {
        res.send(data)
    })
    pgr.end();
})

tenant.put('/updateRating/:property_id/:username', (req, res, next) => {         //update rating using property_id

    rating = req.body.rating
    property_id = req.params.property_id
    username = req.params.username
    var dt = new Date();
    let month = dt.getMonth() + 1;
    let date = dt.getFullYear() + '-' + month + '-' + dt.getDate();

    var db = pgr(conntstr);
    db.any("select fn_rating_update($1,$2,$3,$4)", [rating, date, property_id, username]).then((data) => {
        res.send(data)
    })
    pgr.end();
})

tenant.get("/rating/:property_id", (req, res, next) => {           //get rating by property_id
    property_id = req.params.property_id

    var db = pgr(conntstr)
    db.any("select * from  fn_rating_select($1,$2)", [a]).then((data) => {
        res.send(data)
    })
    pgr.end()
})

//** comment_like_dislike **/

tenant.post('/like/:comment_id/:property_id/:username', (req, res, next) => {       //insert into comment_like_dislike
    var comment_id = req.params.comment_id;
    var property_id = req.params.property_id;
    var username = req.params.username;
    var likestatus = parseInt(1);

    var db = pgr(conntstr);

    db.any("select fn_Comment_like_dislike_insert($1,$2,$3,$4)", [comment_id, property_id, username, likestatus]).then((data) => {
        res.send({
            message: " inserted...."
        })
    })
    pgr.end();
});

tenant.put('/like/:comment_id/:property_id/:username', (req, res, next) => {        //update comment_like_dislike based on cmnt_id,pid,uname
    var comment_id = req.params.comment_id;
    var property_id = req.params.property_id;
    var username = req.params.username;
    var likestatus = parseInt(2);

    var db = pgr(conntstr);
    db.any("select  fn_Comment_like_dislike_update($1,$2,$3,$4)", [likestatus, property_id, username, comment_id]).then((data) => {
        res.send(data);
    })
    pgr.end();

});

//** add_favourites **/

tenant.get('/getFavourites/:username/:page', (req, res, next) => {       //get data from add_favourites
    var propertyArray = [];
    page = (req.params.page) * 10
    var username = req.params.username;
    var db = pgr(conntstr);
    db.any("select * from property_details oap join add_favourites af on oap.property_id=af.property_id join property_types pt on oap.property_type_id=pt.property_type_id join property_address pa on oap.property_id=pa.property_id left join city c on pa.city=c.city_id where af.username=$1 limit $2", [username, page]).then((data) => {

        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    prop['img'] = "http://localhost:4500/no_image.gif";
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    // console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    res.send(propertyArray)
                }
            })

        })
    })
    pgr.end();
})



tenant.get('/getFavourites/moredetails/:property_id', (req, res, next) => {       //get data from add_favourites
    var property_id = req.params.property_id;
    var db = pgr(conntstr);
    // db.any("select * from  add_favourites where username=$1", username).then((data) => {
    db.any("select * from property_details oap join property_address pa on oap.property_id=pa.property_id where oap.property_id=$1", property_id).then((data) => {

        res.send(data);
    })
    pgr.end();
})
tenant.get('/favouriteDetails/:username/:property_id', (req, res, next) => { //get data from add_favourites
    var username = req.params.username;
    var property_id = req.params.property_id;
    var db = pgr(conntstr);
    db.any("select * from fn_add_favourites($1,$2)", [username, property_id]).then((data) => {

        res.send(data);
    })
    pgr.end();
})

tenant.delete('/deleteFavourites/del/:property_id/:username', (req, res, next) => {        //delete from add_favourites based on pid

    var property_id = req.params.property_id;
    var username = req.params.username;
    var db = pgr(conntstr);
    db.any("select fn_add_favourites_delete1($1,$2)", [property_id, username]).then((data) => {
        res.send({ message: "deleted successfully" })
    })
    pgr.end()

})


tenant.post('/addFavouritePost/:property_id/:username', (req, res, next) => {      //insert into add_favourites

    var Property_Id = req.params.property_id;
    var username = req.params.username;
    console.log(Property_Id)
    var db = pgr(conntstr);
    db.any("select fn_add_favourites_insert($1,$2)", [username, Property_Id]).then((data) => {
        res.send(data)

    })
    pgr.end();
})

tenant.delete('/deleteFromFav/:property_id/:username', (req, res, next) => {      //insert into add_favourites

    var Property_Id = req.params.property_id;
    var username = req.params.username;
    var db = pgr(conntstr);
    db.any("delete from add_favourites where property_id=$1 and username=$2", [Property_Id, username]).then((data) => {
        res.send(data)

    })
    pgr.end();
})

tenant.get('/search/all/:property_name', (req, res, next) => {
    var i = req.params.property_name


    var db = pgr(conntstr);
    db.any(" select  t1.*, t2.*,t3.*,t4.*,t5.*,t6.* from (select * from property_details) as t1 JOIN (select * from property_address) as t6 on t1.property_id=t6.property_id join (select *  from country) as t2 on t6.country = t2.country_id JOIN  (select * from state) as t3 on t6.state = t3.state_id JOIN (select * from city) as t4 on t6.city = t4.city_id JOIN (select * from area) as t5 on t6.area = t5.area_id where ( t1.property_name ILIKE  '%' || $1 || '%' or  country_name ILIKE '%'||$1||'%' or state_name ILIKE '%'||$1||'%' or city_name ILIKE '%'||$1||'%' or area_name ILIKE '%'||$1||'%' or description ILIKE '%'||$1||'%') and status='Active' ", [i], i).then((data) => {

        res.send(data);

    });

    pgr.end();
})
//**bidding *rakesh/

tenant.get('/Bidding/:property_id', (req, res, next) => {

    var property_id = req.params.property_id;
    var db = pgr(conntstr);
    db.any('select b.bid_id,b.username,b.property_id,b.bidding_price,b.bidding_date,s.name from bidding b join signup s on s.username=b.username where property_id=$1', property_id).then((data) => {
        res.send(data);
    });
    pgr.end();
})

tenant.get('/username/:username', (req, res, next) => {
    var username = req.params.username;
    var db = pgr(conntstr);
    db.any(' select * from fn_tenant_signup_select($1) ', username).then((data) => {
        res.send(data)
    })
    pgr.end();
})

tenant.post('/Bidding', (req, res, next) => {
    var property_id = req.body.property_id;
    var bidding_price = req.body.bidding_price;
    var username = req.body.username;
    var dt = new Date()
    let month = dt.getMonth() + 1;
    var bidding_date = dt.getFullYear() + '_' + month + '_' + dt.getDate();
    console.log(property_id + username + bidding_price + bidding_date)
    var db = pgr(conntstr);
    db.any("select fn_bidding_insert($1,$2,$3,$4)", [username, property_id, bidding_price, bidding_date]).then((data) => {
        res.send({
            message: " inserted...."
        })
    })
    pgr.end();
})

// ** Trending  **//

tenant.get('/getTrendingId/:id', (req, res, next) => { //get data from add_favourites
    var id = req.params.id
    var db = pgr(conntstr);
    db.any("select * from fn_trending_select($1)", id).then((data) => {
        res.send(data)
    })
    pgr.end();
})



tenant.post('/postTrendingId', (req, res, next) => { //insert into trending
    var property_id = req.body.property_id;
    var property_type = req.body.property_type;
    var date = req.body.date;
    var count = 1
    var db = pgr(conntstr);
    db.any("select fn_trending_insert($1,$2,$3,$4)", [property_id, property_type, date, count]).then((data) => {
        res.send(data)

    })
    pgr.end();
})



tenant.put('/updateTrendingId/:id', (req, res, next) => { //update trending based on property_id
    var property_id = req.params.id;

    var db = pgr(conntstr);
    db.any('select * from fn_update_trends($1)', property_id).then((data) => {
        res.send(data);
    })
    pgr.end();

});


tenant.get('/getTrendingFiltersId/:filter/:city', (req, res, next) => { //get data from trending with month and city

    var filter = req.params.filter;
    var city = req.params.city;
    console.log(city)
    var db = pgr(conntstr);
    db.any("SELECT * from trending t join property_details o on t.property_id=o.property_id join property_address pa on pa.property_id = o.property_id left join city c on pa.city = c.city_id where (t.date >CURRENT_DATE - INTERVAL $1) and c.city_name=$2", [filter, city]).then((data) => {
        res.send(data)
    })
    pgr.end();
})

//** Rating **/

tenant.post('/postRating', (req, res, next) => {         // post rating data
    var property_id = req.body.property_id;
    var rating = req.body.rating;
    var username = req.body.username;
    var dt = new Date();
    let month = dt.getMonth() + 1;
    let date = dt.getFullYear() + '-' + month + '-' + dt.getDate();

    var db = pgr(conntstr);

    db.any('select fn_rating_insert($1,$2,$3,$4)', [property_id, rating, username, date]).then((data) => {
        res.send({
            message: " Inserted Sucessfully"
        });
    });
    pgr.end();
})

tenant.get('/getRating/:property_id/:username', (req, res, next) => { //get rating..
    var property_id = req.params.property_id;
    var username = req.params.username;

    var db = pgr(conntstr);
    db.any('select * from fn_rating_select($1,$2)', [property_id, username]).then((data) => {

        res.send(data)
    })

    pgr.end();
})


tenant.put('/updateRating/:property_id/:username', (req, res, next) => {       //update rating
    var property_id = req.params.property_id;
    var username = req.params.username;
    var rating = req.body.rating;

    var dt = new Date();
    let month = dt.getMonth() + 1;
    let date = dt.getFullYear() + '-' + month + '-' + dt.getDate();

    var db = pgr(conntstr);
    db.any("select fn_rating_update($3,$4,$1,$2)", [property_id, username, rating, date]).then((data) => {
        res.send(data);
    })
    pgr.end();
})

tenant.get('/getLatLng/:lat/:long/:page', (req, res, next) => { //get rating..
    var propertyArray = []
    page = (req.params.page) * 10
    var lat = req.params.lat
    var long = req.params.long
    console.log(lat + "" + long)
    var db = pgr(conntstr);
    db.any("select * from  (select a.*, o.*,pt.*,(2 * 3961 * asin(sqrt((sin(radians((o.latitude - 17.4315385)/ 2))) ^ 2 +cos(radians(17.4315385)) * cos(radians(o.latitude)) *(sin(radians( (o.longitude - 78.4467634)/ 2)))^ 2)))  as distance from property_location_map o join property_details a on o.property_id=a.property_id join property_types pt on pt.property_type_id=a.property_type_id and status='Active') as tb1 where tb1.distance<10 order by tb1.distance limit $3 ", [lat, long, page]).then((data) => {

        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    prop['img'] = "http://localhost:4500/no_image.gif"
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    // console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    // console.log(propertyArray)
                    res.send(propertyArray)
                }
            })

        })

    })
    pgr.end();
})

tenant.get('/ownersInfo/:propertyId', (req, res) => {
    var propertyId = req.params.propertyId;
    var db = pgr(conntstr);
    db.any('select * from fn_getownersinfo_byproperty ($1)', propertyId).then(data => {
        res.send(data);
    })
    pgr.end();
})

tenant.get('/notification/:username', (req, res) => {
    var username = req.params.username;
    var db = pgr(conntstr);
    db.any("select * from fn_getnotification_byusername($1)", username).then(data => {
        res.send(data);
    })
    pgr.end();
})

tenant.put('/notificationseen', (req, res) => {
    var id = req.body;
    var db = pgr(conntstr)
    for (let index = 0; index < id.length; index++) {
        db.any("select fn_updatenotification_seen($1)", [id[index]]).then(() => {
        })
    }
    res.send({ 'message': 'updated' })
    pgr.end();
})


tenant.get('/allnotifications/:username', (req, res) => {
    var username = req.params.username
    var db = pgr(conntstr);

    db.any("select * from fn_getallnotification_byusername($1)", username).then(data => {
        res.send(data);
    })
    pgr.end();
})

tenant.get('/checkgmailuser/:username', (req, res, next) => {
    var username = req.params.username;

    console.log(username + "sssssss")
    var db = pgr(conntstr);
    db.any("select * from fn_check_user( $1)", username).then((data) => {
        res.send(data)

    })
    pgr.end();
})



tenant.post('/gmailpost', (req, res, next) => {
    var name = req.body.name;
    var id = req.body.gmail_id;
    var email = req.body.gmail;
    var user_type = 'Owner/Tenant';
    var status = 'Active'
    console.log('name:' + name)
    console.log('id;' + id)
    console.log('email' + email)
    console.log('type' + user_type)

    var database = pgr(conntstr);
    database.any('select fn_signup_by_gmail($1,$2,$3,$4,$5,$6)', [name, id, email, email, user_type, status]).then((data) => {
        res.send({ message: " inserted...." })
    })
    pgr.end();
})


tenant.get('/BiddingGetByusername/:username/:page', (req, res, next) => {

    k = (req.params.page) * 10
    var username = req.params.username;
    var propertyArray = []

    var db = pgr(conntstr);
    db.any(" select * from property_details p join (select username,property_id,array_to_json(array_agg(bidding_price)) as bidding_prices from bidding where username=$1 group by username,property_id) pt on pt.property_id=p.property_id left outer join property_address pa on pa.property_id=p.property_id left join country c on c.country_id=pa.country left join state s on s.state_id=pa.state left join city ci on ci.city_id=pa.city left join area a on a.area_id=pa.area where p.status='Active' limit $2 ", [username, k]).then((data) => {
        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    prop['img'] = "http://localhost:4500/no_image.gif";
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    //  console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    // console.log(array[0])
                    res.send(propertyArray)
                }
            })

        })
    })
    pgr.end();
})


tenant.get('/getpropertybyareaorcity/:area/:city', (req, res) => {
    var db = pgr(conntstr);
    var area = req.params.area;
    var city = req.params.city;
    console.log(area + '' + city + '' + 'as')
    db.any('select * from fn_propertybyareaorcity($1,$2)', [city, area]).then(data => {
        console.log(data);
        res.send(data);
    })
    pgr.end();
})



tenant.post('/img', (req, res) => {
    console.log('im');
    
    res.send('upload');
})
tenant.post('/video', (req, res) => {
    console.log(req.body.propertyId)
    console.log('here')
    fn = req.body.property_id + '.mp4';
    cfn = path.join(__dirname,'videos/' + fn)
    console.log(fn);
    fs.writeFile(cfn, req.body.videos, 'base64', err => {
        if (err) {
            console.log(err)
        }
        else {
            res.send({'message':'video added'})
            console.log('addedd');
        }
    })         
})


tenant.get('/propertydetailsbyarea/:lat/:long/:propertytype/:city', (req, res) => {
    var db = pgr(conntstr);
    var propertyArray = [];

    console.log('here');
    var latitude = req.params.lat;
    var longitude = req.params.long;
    var propertyType = req.params.propertytype;
    var city = req.params.city;
    console.log(latitude + '' + longitude + '' + propertyType + '' + city + '' + 'as')
    db.any(`select * from  
  (select ar.city_name,r.area_name,r.area_id,a.property_type_id,a.*, o.*,pt.*,(2 * 3961 * asin
  (sqrt((sin(radians((o.latitude - $1)/ 2))) ^
   2 +cos(radians($1)) * cos(radians(o.latitude)) *
  (sin(radians( (o.longitude - $2)/ 2)))^ 2)))  
  as distance from property_location_map o left join property_details 
  a on o.property_id=a.property_id left join property_address pa on a.property_id=pa.property_id left join 
   property_types pt on 
  pt.property_type_id=a.property_type_id left join city ar on ar.city_id=pa.city left join area r on r.area_id=pa.area where a.property_type_id=$3 and ar.city_name=$4)
  as tb1 order by tb1.distance`, [latitude, longitude, propertyType, city]).then(data => {
        //res.send(data);
        data.forEach(prop => {

            console.log(prop)
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    console.log(propertyArray)
                    res.send(propertyArray)
                }
            })

        })
    }
    )
    pgr.end();
})


module.exports = tenant
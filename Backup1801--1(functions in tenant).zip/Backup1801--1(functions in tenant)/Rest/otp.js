var express = require('express');
var bodyparser = require('body-parser');
var qs = require("querystring");
var http = require("http");
const bodyParser = require("body-parser");
var path = require('path')
var otp = express.Router();

otp.use(bodyParser.urlencoded({
    extended: true
}));
otp.use(bodyparser.json())



otp.get('/:phno', (req, res, next) => {
    var body;
    var collect;
    var options = {

        "method": "GET",
        "hostname": "2factor.in",
        "port": null,
        "path": null,
        "headers": {
            "content-type": "application/x-www-form-urlencoded"
        }
    };
    var i = req.params.phno;
    console.log(i);

    options.path = "/API/V1/96ab36da-f79d-11e8-a895-0200cd936042/SMS/" + i + "/AUTOGEN"
    var req = http.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);

        });

        res.on("end", function () {
            body = Buffer.concat(chunks);

            // console.log(body.toString());
            collect = body


            vinod()
            // console.log(JSON.stringify(body.toString()))    //working
            // res.write(JSON.stringify(body.toString()));
        });
        // res.write(JSON.stringify(body.toString()));

    });
    function vinod() {

        var a = collect.toString()
        var b = JSON.parse(a)
        console.log(b) 
        res.send(a)
    }
    req.write(qs.stringify({}));
    req.end();

})


module.exports = otp;
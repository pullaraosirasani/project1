var fs = require('fs')
var path = require('path')
var express = require('express')
var promise = require('bluebird')
var bodyparser = require('body-parser')
var option = {
    promiseLib: promise
};

var pgr = require('pg-promise')(option)
var admin = express();
var config = require('./apiconfig')
var conntstr = config.connectionString


admin.all('*', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", '*');
    res.header("Access-Control-Allow-Headers", "Cache-Control,Pragma,Origin,Authorization,Content-Type,X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});

admin.use(bodyparser.json({ limit: '30mb' }));
admin.use(bodyparser.urlencoded({ limit: '30mb', extended: true }));


admin.get('/verified/:nearluk_verified', (req, res) => {
    console.log(nearluk_verified)
    var nearluk_verified = req.params.nearluk_verified
    var db = pgr(conntstr);
    db.any("select p.*,c.*,pt.*,co.*,s.mobile from property_details p left outer join Property_Types pt on p.property_type_id = pt.property_type_id left join  property_address pa on pa.property_id = p.property_id left join country co on pa.country = co.country_id  left join city c on pa.city = c.city_id left join signup s on p.username = s.username where p.nearluk_verified=$1 GROUP BY p.property_id,c.city_id,c.city_name,c.state_id,pt.property_type_id,pt.property_type,co.country_id,co.country_name,s.mobile", nearluk_verified).then(data => {
        res.send(data);
    })
    pgr.end();
})

admin.get('/GetSortingActive/:status', (req, res) => {
    var status = req.params.status
    var db = pgr(conntstr);
    db.any("select p.*,c.*,pt.*,co.*,s.mobile from property_details p left outer join Property_Types pt on p.property_type_id = pt.property_type_id left join  property_address pa on pa.property_id = p.property_id left join country co on pa.country = co.country_id  left join city c on pa.city = c.city_id left join signup s on p.username = s.username where p.status=$1 GROUP BY p.property_id,c.city_id,c.city_name,c.state_id,pt.property_type_id,pt.property_type,co.country_id,co.country_name,s.mobile", status).then(data => {
        res.send(data);
    })
    pgr.end();
})


admin.post('/postData', (req, res, next) => {
    var id = req.body.id;
    var name = req.body.name;
    var db = pgr(conntstr);
    db.any('insert into employee values($1,$2,$3)', [id, name])
})



admin.put('/verification/:property_id', (req, res) => {
    var db = pgr(conntstr);
    console.log('here')
    var property_id = req.params.property_id;
    db.any("update property_details set nearluk_verified='V' where property_id=$1", property_id).then(data => {
        res.send({ 'message': 'updated' })
    })
    pgr.end();
})
admin.put('/edituser/:username/:mobile/:email', (req, res) => {
    var db = pgr(conntstr);
    console.log('here')
    var username = req.params.username;
    var mobile = req.params.mobile;
    var email = req.params.email;

    db.any("update signup set mobile=$1, email=$2  where username=$3", [mobile, email, username]).then(data => {
        res.send({ 'message': 'updated' })
    })
    pgr.end();
})
admin.put('/Inactive/:property_id/:status', (req, res) => {
    var db = pgr(conntstr);
    console.log('here')
    var property_id = req.params.property_id;
    var status = req.params.status;
    db.any("update property_details set status=$1 where property_id=$2", [status, property_id]).then(data => {
        res.send({ 'message': 'updated' })
    })
    pgr.end();
})
admin.get('/', (req, res, next) => {
    var propertyArray = []
    var db = pgr(conntstr);
    db.any(` select p.*,c.*,pt.*,co.*,s.mobile from property_details p left outer join Property_Types
    pt on p.property_type_id = pt.property_type_id left join 
    property_address pa on pa.property_id = p.property_id 
    left join country co on pa.country = co.country_id 
	left join city c on pa.city = c.city_id 
	left join signup s on p.username = s.username 
     GROUP BY p.property_id,c.city_id,c.city_name,c.state_id,
     pt.property_type_id,pt.property_type,co.country_id,co.country_name,s.mobile`).then((data) => {
        // console.log('-----------')
        // console.log(data)
        // console.log('-----------')
        data.forEach(prop => {
            myPath = path.join(__dirname, 'Gallery/' + prop.property_id + '/Images/');

            fs.readdir(myPath, (err, files) => {
                if (files == undefined) {
                    propertyArray.push(prop)
                }
                else {
                    prop['img'] = "http://localhost:4500/" + prop.property_id + "/Images/" + files[0]
                    propertyArray.push(prop)
                    // console.log(prop)
                }
                if (data.length == propertyArray.length) {
                    res.send(propertyArray)
                }
            })

        })
    })
    pgr.end();
})

admin.get('/GetNotifications/:country_id', (req, res) => {
    // console.log(country_id)
    var country_id = req.params.country_id
    var db = pgr(conntstr);
    db.any("select c.admin_notification_id,c.message from admin_notifications c join signup s on c.country_id=s.country where c.country_id=$1 and c.status='A' group by c.admin_notification_id,c.message", country_id).then(data => {
        res.send(data);
    })
    pgr.end();
})




admin.put('/AdminNotification/:admin_notification_id/:status', (req, res, next) => {     //update enquiry_form based on username

    var admin_notification_id = req.params.admin_notification_id;
    var status = req.params.status;
    var db = pgr(conntstr);

    db.any('update admin_notifications set status=$1 where admin_notification_id=$2', [status, admin_notification_id]).then((data) => {
        res.send(data)

    })
    pgr.end();
})





admin.get('/GetAllAdminNotifications', (req, res) => {

    var db = pgr(conntstr);
    db.any("select * from  admin_notifications").then(data => {
        res.send(data);
    })
    pgr.end();
})


admin.post('/adminnotification/', (req, res, next) => {
    // console.log(req.body)
    var message = req.body.message;
    var country_id = req.body.country_id;
    var status = 'A';
    var db = pgr(conntstr);
    db.any('insert into admin_notifications values($1,$2,$3)', [message, country_id, status]).then(data => {
        res.send({ 'message': 'inserted sucessfully' })
    })
    pgr.end();
})


admin.post('/Contactpost/', (req, res, next) => {
    // console.log(req.body)
    var name = req.body.name;
    var email = req.body.email;
    var message = req.body.message;
    var status = 'A';
    var dt = new Date();
    let month = dt.getMonth() + 1;
    let date = dt.getFullYear() + '-' + month + '-' + dt.getDate();
    console.log('contact us post')
    var db = pgr(conntstr);
    db.any('insert into contact_us(name,email,message,status,posted_date) values($1,$2,$3,$4,$5)', [name, email, message, status, date]).then(data => {
        res.send({ "message": "inserted sucessfully" })
    })
    pgr.end();
})


admin.get('/Contacts', (req, res) => {
    var db = pgr(conntstr);
    db.any("select *from contact_us").then(data => {
        res.send(data);
    })
    pgr.end();
})

admin.put('/AdminContact/:ct_id', (req, res) => {
    var db = pgr(conntstr);
    console.log('here')
    var ct_id = req.params.ct_id;
    db.any("update contact_us set status='U' where ct_id=$1", ct_id).then(data => {
        res.send({ 'message': 'updated' })
    })
    pgr.end();
})






module.exports = admin
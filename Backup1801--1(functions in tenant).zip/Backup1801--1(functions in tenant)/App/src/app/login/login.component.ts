import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { login } from '../models/login';
import { NearlukService } from '../services/nearluk.service';
import swal from 'sweetalert2';
import { AppComponent } from '../app.component';
import { SocialUser, AuthService } from 'angularx-social-login';
import { GoogleLoginProvider, FacebookLoginProvider, LinkedInLoginProvider } from 'angularx-social-login';
import { gmaillogin } from '../models/gmailPost';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  display: boolean = false;
  login: login;//for login
  shows: boolean;
  user: SocialUser;
  invalidLogin: boolean;

  gmaillogin: gmaillogin;

  gmailBtnclick: number = 0;
  password() {
    this.shows = !this.shows;
  }

  cncl() {   //for cancel button
    this.display = false;
    this.router.navigate(['home'])
  }
  reg() {  //for register button
    this.router.navigate(['register'])
  }
  constructor(private router: Router, public myapp: AppComponent, private nls: NearlukService /*, private authService: AuthService */) {
    this.login = new login()
    this.gmaillogin = new gmaillogin();
  }

  forgotPassword() {    //navigate to forgot passsword component
    this.router.navigate(['forgotpswd']);
  }

  btnLoginClick(uid: any) { // for login check
    if ((this.login.uid == null) || (this.login.uid == '') || (this.login.pwd == null) || (this.login.pwd == '')) {
      this.invalidLogin = true;
    }

    this.nls.loginen(this.login.uid, this.login.pwd).subscribe((data) => {
      if (data.length > 0) {
        // if (this.login.pwd == data[0].password) {

        sessionStorage.setItem("uname", this.login.uid);

        swal({
          type: 'success',
          title: sessionStorage.getItem('uname'),
          text: 'Loged In Successfully',
          timer: 2000,
          showConfirmButton: false
        })
        if (sessionStorage.getItem("PP")) {
          this.router.navigate(['postproperty']);
          sessionStorage.removeItem("PP");
        }
        else {
          if (data[0].usertype == "Owner/Tenant") {
            sessionStorage.setItem("user_type", "Owner/Tenant");
            this.router.navigate(['home']);
            this.ngOnInit();
          }
          else if (data[0].usertype == "Admin") {
            sessionStorage.setItem("user_type", "Admin");
            this.router.navigate(['admin']);
            this.ngOnInit();
          }



          else {
            sessionStorage.setItem("user_type", "Agent");
            this.router.navigate(['agent']);
            this.ngOnInit();
          }
        }

      }
      else {
        // alert('user or password doesnt  exist')
        this.invalidLogin = true;
      }
    })
  }

  makeEventFalse() {
    this.invalidLogin = false;
  }

  // signInWithGoogle(): void {

  //   this.gmailBtnclick = 1;
  //   this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
  // }

  // signInWithFB(): void {
  //   this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
  // }

  // signInWithLinkedIn(): void {
  //   this.authService.signIn(LinkedInLoginProvider.PROVIDER_ID);
  // }

  // signOut(): void {
  //   this.authService.signOut();

  // }

  ngOnInit() {
    this.display = true; //for popup primeNg

    // this.authService.authState.subscribe((user) => {
    //   this.user = user;

    //   console.log(user)

    //   if (this.gmailBtnclick != 0) {

    //     this.gmaillogin.gmail = this.user.email
    //     this.gmaillogin.gmail_id = this.user.id
    //     this.gmaillogin.name = this.user.name

    //     this.nls.checkgmail(this.gmaillogin.gmail).subscribe((data) => {
    //       if (data.length == 0) {
    //         alert('added');

    //         this.nls.Insertgmail(this.gmaillogin).subscribe(
    //           (data) => {

    //             alert('valid')


    //             sessionStorage.setItem('uname', this.gmaillogin.gmail)
    //             sessionStorage.setItem('user_type', 'Owner/Tenant')

    //             this.router.navigate(['home'])

    //           })

    //         // console.log(data.length + "shiva")
    //         // console.log(data)
    //       }
    //       else {

    //         sessionStorage.setItem('uname', this.gmaillogin.gmail)
    //         sessionStorage.setItem('user_type', 'Owner/Tenant')

    //         this.router.navigate(['home'])

    //         // location.reload();

    //       }

    //     });

    //   }
    // });
  }
}



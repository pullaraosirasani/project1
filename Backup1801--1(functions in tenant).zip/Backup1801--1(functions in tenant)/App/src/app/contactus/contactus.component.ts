import { Router } from '@angular/router';
import { contactus } from './../models/contactus';
import { Component, OnInit } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
  contact: contactus
  constructor(private nls: NearlukService, private router: Router) {

  }

  ContectUs(myFrm: any) {

    // alert(JSON.stringify(this.contact))
    if ((this.contact.name == undefined) || (this.contact.email == undefined) || (this.contact.message == undefined)) {

    }
    else {

      this.nls.SendContact(this.contact).subscribe((data) => {
        alert(JSON.stringify(data))
        myFrm.resetForm();
      })
    }

  }

  onSubmit(myFrm: NgForm) {
    myFrm.resetForm();
  }

  ngOnInit() {
    this.contact = new contactus();
  }

}

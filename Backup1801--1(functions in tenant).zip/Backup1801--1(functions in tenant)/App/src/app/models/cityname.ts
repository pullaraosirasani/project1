export class city{
    city:any;
}
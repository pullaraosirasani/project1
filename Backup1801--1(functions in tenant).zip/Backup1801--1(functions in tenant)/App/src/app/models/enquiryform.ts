export class Enquiry_Form {
    // eq_id:number;
    username: string;
    property_type_id: any;
    min_price: number
    max_price: number
    city: any
    facing: string
    landmarks: string
    country: any
    state: any
    currency: any
    area: any
}
export class contactus {
    // eq_id:number;
    name: string;
    email: any;
    message:any;
    
}


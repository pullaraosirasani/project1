export class tenantnotifications {
    property_id: string
    from_username: string
    to_username: any;
    message: string
    notifydate: Date
    status: string
    notification_type: string
}
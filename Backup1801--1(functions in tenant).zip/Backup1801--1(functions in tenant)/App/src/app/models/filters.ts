export class filters {
    propertyTypeId: any [];
    cityName: string;
    facing:any [];
    minprice:any;
    maxprice:any;
    veification:any;
    rating:any;
    // mobile: any
    // password: string
    // gender: string
    // address: string
    // present_address: string
    // occupation: string
    // email: string
    // dob: string
    // image: string
    // notification_count: number;
    // owner_notfication_count: number
    // count: number
}
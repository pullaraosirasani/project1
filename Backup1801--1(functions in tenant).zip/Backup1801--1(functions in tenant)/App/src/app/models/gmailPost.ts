export class gmaillogin {
    gmail: string;
    gmail_id: string;
    name: string;
    // comments: string;
    // date: string;
}
export class editimg
{
    image:any
    path:any
}
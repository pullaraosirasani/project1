export class adminnotification{
    message:any;
    country_id:any;
    status:any;
}
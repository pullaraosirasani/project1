export class Bidding {
    bid_id:string;
    username: string;
    property_id: string;
    bidding_price:string;
    bidding_date:string;
}
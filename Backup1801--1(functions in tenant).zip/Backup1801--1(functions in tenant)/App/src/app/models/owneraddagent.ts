export class owneraddagent{
    property_id:any
    agent_username:string
    status:string;
}
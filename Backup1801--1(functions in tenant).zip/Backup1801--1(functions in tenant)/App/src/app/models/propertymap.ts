export class propertylocation {
    property_id: string;
    latitude: number;
    longitude: number;
    landmark1: any;
    lat: any;
    lan: any;
    city: any;
    district:any
}
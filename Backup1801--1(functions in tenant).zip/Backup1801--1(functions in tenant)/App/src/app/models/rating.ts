export class rating {

    property_id: string;
    username: string;
    rating: number
    date: string;
}

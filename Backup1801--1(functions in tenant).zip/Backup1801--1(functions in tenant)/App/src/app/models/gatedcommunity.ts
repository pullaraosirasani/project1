export class community {

    cm_id: any;
    community_name: string;
    community_description: string;
    city: any;
}
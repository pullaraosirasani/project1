export class postproperty {
    property_id: any;
    property_type: string;
    address_proof_id: string;
    property_type_id: string;
    property_name: string;
    address_proof: string;
    address: string;
    pincode: string;
    landmarks: string;
    dimensions: string;
    dimensions_units: string;
    city: any;
    state: any;
    country: any;
    area: any;
    images: any;
    units_id: any;
    propertyArea: any;
    construction_status: any;
    security_deposit: any;
    monthly_maintainance: any;
    facing: any;
    currency: any;
    enable_bidding: boolean;
    rental_period: any;








    lat1: any;
    lan1: any;
    landmark1: any;
    property_spec: string;

    price: string;
    description: string;
    username: string;
    construction: string;
    rating: string;
    usercheck: string;
    status: string;

    cm_id: any;
    community_name: string;
    community_description: string;


}
export class propertyAddress{
    
   property_id:any;
   address_proof_type:any;
   address_proof_id:any;
   address:any;
   pincode:any;
   landmarks:any;
   country:any;
   state:any;
   city:any;
   area:any;
   nearby_propertyname:any;
   district:any;
}
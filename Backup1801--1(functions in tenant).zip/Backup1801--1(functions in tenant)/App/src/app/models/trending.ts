export class Trending {
property_id:any
property_type:any
date:any
// city:string
}
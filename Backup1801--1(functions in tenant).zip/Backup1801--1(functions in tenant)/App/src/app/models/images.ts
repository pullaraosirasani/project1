export class images {
    image: any;
    property_id: any;
}

export class Profile {
    image: any;
    username: any;
}

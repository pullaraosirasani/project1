export class propertylocation {
    property_id: string;
    latitude: number;
    longitude: number;
   
    

   

}
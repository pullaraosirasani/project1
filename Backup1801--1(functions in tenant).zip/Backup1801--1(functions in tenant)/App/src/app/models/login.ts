export class login {
    uid:string
    pwd:string
}
export class videos {
    videos: any;
    property_id: any;
}

export class forum {
    comment_id: string;
    property_id: string;
    username: string;
    comments: string;
    date: string;
}

export class register {
    name: string
    username: string
    isd: any
    mobile: any
    password: string
    gender: string
    address: string
    present_address: string
    occupation: string
    email: string
    dob: string
    image: string
    notification_count: number;
    owner_notfication_count: number
    count: number
}

export class Reply {

    comment_id: number;
    username: string;
    reply: any;


}





import { Component, OnInit } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';
import { Router } from '@angular/router';
import { register } from '../models/register';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  updateprofile: any;
  username: any;

  constructor(private nls: NearlukService, private router: Router) { }

  update() {
    this.router.navigate(['updateprofile']);
  };

  changePassword() {
    this.router.navigate(['changepswd/' + this.username])
  };

  ngOnInit() {
    this.username = sessionStorage.getItem('uname');
    this.nls.getByUsernameWithImage(this.username).subscribe((data) => {
      this.updateprofile = data;
    });
  };
}


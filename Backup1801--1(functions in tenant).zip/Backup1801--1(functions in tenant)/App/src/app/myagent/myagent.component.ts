import { NearlukService } from './../services/nearluk.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { tenantnotifications } from '../models/tenantnotifications';

@Component({
  selector: 'app-myagent',
  templateUrl: './myagent.component.html',
  styleUrls: ['./myagent.component.css']
})
export class MyagentComponent implements OnInit {

  myagent: any;
  a: any


  notification: tenantnotifications;
  agentMoreDetails: boolean;
  agentData: any;
  constructor(private agent: NearlukService, private acr: Router) {
    this.notification = new tenantnotifications();
  }



  deleteAgents(pid: any, agent: any, propertyname: any) {
    this.notification.to_username = agent;
    this.notification.from_username = sessionStorage.getItem('uname');
    this.notification.message = sessionStorage.getItem('uname') + ' ' + 'has removed you from property' + ' ' + propertyname;
    this.notification.notification_type = "agentremoved";
    this.notification.status = "unseen";
    this.notification.notifydate = new Date();
    this.notification.property_id = pid;
    this.agent.addagentnotifications(this.notification).subscribe(data => {
      console.log(data);
    })
    this.agent.deleteMyAgent(pid, agent).subscribe((data) => {
      alert("deleted")
      this.acr.navigateByUrl('/myagentref', { skipLocationChange: true }).then(() =>
        this.acr.navigate(["myagent"]));
    })
  }

  agentInfo(agent: any) {
    this.agent.getByUsernameWithImage(agent).subscribe((data) => {
      this.agentData = data;
      this.agentMoreDetails = true;
    })
  }

  cncl() {
    this.agentMoreDetails = false;
  }

  ngOnInit() {
    let owner = sessionStorage.getItem("uname");

    this.agent.GetMYAgents(owner).subscribe((data) => { // my AGENTS Get
      this.myagent = data;

      // alert(JSON.stringify(data))

    })

  }

}

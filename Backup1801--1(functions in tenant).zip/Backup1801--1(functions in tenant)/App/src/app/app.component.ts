
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import swal from 'sweetalert2';
import { register } from './models/register';
import { NearlukService } from './services/nearluk.service';
import { owneraddagent } from './models/owneraddagent'
import { SelectItem } from 'primeng/api';
import { tenantnotifications } from './models/tenantnotifications';
import { filters } from './models/filters';
import { GMapsService } from './services/gmaps.service';

interface Facing {
  name: string,
  code: string
}

interface propertytype {
  id: string,
  name: string
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  visibleSidebar1;
  filter;
  pricefilter;
  propertytype: SelectItem[];
  FacingSelected: any[];
  facing: SelectItem[];
  rating: SelectItem[];
  verification: SelectItem[];
  logstatus: Observable<string>
  updateProfile: register;
  city: string;
  propertyList: any;
  notificationscount: number;
  notifications: any[];
  notifyvisible = "";
  shownotify = "";
  nomessage: string;
  notificationseen: any[] = [];
  addagent: owneraddagent;
  display: boolean;
  agent;
  owner;
  admin;
  tenantnotify: tenantnotifications;
  filterObj: filters;
  veification: any;
  ratings: any
  filte: any
  filterss: any
  propertyid: any;
  minprices: any;
  maxprices: any;
  facings: any;
  minprice: any;
  maxprice: any;
  selectedFacing: Facing[];
  country_id: any;
  adminnotification: any;
  flag: string;
  latt: number;
  lngg: number;
  compare1: any = 0;
  compare2: any = 0;
  compare3: any = 0;
  comparecount: any = 0;
  maxx: boolean = false;
  profileUser: any;
  userImage: any;
  citylocation: boolean;


  //Notifications by aakash and manikanta
  //Notifications by aakash and manikanta
  notify() {

    this.nls.getnotification(sessionStorage.getItem('uname')).subscribe(data => {

      this.notifyvisible = "visible";

      this.notifications = data;
      // alert(JSON.stringify(data))
      if (data.length == 0) {
        this.nomessage = "no new notifications";
      }
      else {
        for (let index = 0; index < this.notifications.length; index++) {

          this.notificationseen.push(this.notifications[index].notification_id)
          // console.log(this.notificationseen);
        }
      }



    })
  }
  //Side Nav menu
  btnCompare() {

    this.router.navigate(['compare'])
  }
  menu() {
    this.visibleSidebar1 = true;

    document.getElementById("main").style.marginLeft = "280px";
    document.getElementById("mainnav").style.marginLeft = "280px";
  }
  close() {
    document.getElementById("main").style.marginLeft = "0";
    document.getElementById("mainnav").style.marginLeft = "0";
  }

  text: string;

  results: string[] = [];


  searchCity(event) {
    this.results.length = 0;

    if (event.query.length > 2) {
      this.nls.cityAutoComplete(event.query).subscribe(data => {
        this.results = data


        console.log(this.results)
      });
    }

  }

  //Update status of notifications
  seen() {
    this.notifyvisible = "";
    this.nls.updateNotification(this.notificationseen).subscribe(data => {
      // console.log(data);
      this.ngOnInit();
    })
  }
  //ViewAllNotifications
  allnotify() {
    this.notifyvisible = "";
    this.nls.updateNotification(this.notificationseen).subscribe(data => {
      // console.log(data);
      this.ngOnInit();
    })
    this.router.navigate(['allnotifications'])
  }
  //navigate to agent profile by manikanta and aakash

  agentprofile(username) {
    // console.log('agents')

    window.open("agentprofile" + '/' + username)
  }
  propertyTypeOnChange(c: any) {


    // const myObjStr = JSON.stringify(c);
    this.filterObj.propertyTypeId = c.value
    alert(this.filterObj.propertyTypeId + "asa")
    // alert((c.value.id))
  }
  clickprice(min: HTMLInputElement, max: HTMLInputElement) {

    if (parseInt(max.value) > parseInt(min.value)) {
      this.filterObj.minprice = min.value;
      this.filterObj.maxprice = max.value;
      this.display = false;
      this.maxx = false;
    }
    else {
      this.display = true;
      this.maxx = true;
    }

  }
  clickCity(s: any) {
    this.filterObj.cityName = s.value

  }
  price() {
    this.display = true;
  }
  hide() {

    if (this.filter == true) {
      this.filter = false;
    }
    else {
      this.filter = true;
    }
  }


  constructor(private router: Router, private nls: NearlukService, private gMapsService: GMapsService) {
    this.updateProfile = new register();
    this.shownotify = sessionStorage.getItem('uname');
    this.addagent = new owneraddagent();
    this.tenantnotify = new tenantnotifications();
    this.filterObj = new filters();

    this.propertytype = [
      { label: 'Property Type', value: null },
      // { label: 'Houses', value: { id: 1, name: 'Houses', code: 'Houses' } },
      // { label: 'Shops', value: { id: 2, name: 'Shops', code: 'Shops' } },
      // { label: 'ShoppingMalls', value: { id: 3, name: 'ShoppingMalls', code: 'LDN' } },
      // { label: 'Colleges', value: { id: 4, name: 'Colleges', code: 'IST' } },
      // { label: 'Schools', value: { id: 5, name: 'Schools', code: 'PRS' } }
    ];
    this.facing = [
      { label: 'North', value: ['North'] },
      { label: 'South', value: ['South'] },
      { label: 'East', value: ['East'] },
      { label: 'West', value: ['West'] },
      { label: 'North-East', value: ['North-East'] },
      { label: 'North-West', value: ['North-West'] },
      { label: 'South-East', value: ['South-East'] },
      { label: 'South-West', value: ['South-West'] }


    ];
    this.verification = [
      { label: 'Verified', value: { id: 1, name: 'V', code: 'Verified' } },
      { label: 'Not Verified', value: { id: 2, name: 'N', code: 'Not Verified' } },

    ];
    this.rating = [
      { label: '1', value: { id: 1, name: '1', code: '1' } },
      { label: '2', value: { id: 2, name: '2', code: '2' } },
      { label: '3', value: { id: 3, name: '3', code: '3' } },
      { label: '4', value: { id: 4, name: '4', code: '4' } },
      { label: '5', value: { id: 5, name: '5', code: '5' } }
    ];

  }

  makefiltersnull() {
    this.filterObj.propertyTypeId = undefined;
    this.filterObj.cityName = null;
    this.minprice = null;
    this.maxprice = null;
    this.filterObj.facing = null;
    this.filterObj.veification = null;
    this.filterObj.rating = null;
  }


  CheckLocalStore(): Observable<any> {
    return of(sessionStorage.getItem("uname"));

  }
  NearU() {
    this.router.navigate(['nearu']);
  }

  maxxPrice() {
    this.maxx = false;
  }
  search(min: any, max: any, cityname: any) {
    if (sessionStorage.getItem('state') == null && this.filterObj.cityName == null) {
      this.citylocation = true;
      alert("select the city")
      return;
    }

    if (cityname.length == 0 && sessionStorage.getItem('state') == null) {
      alert("select the city")
      return;
    }

    if (parseInt(min.value) > parseInt(max.value)) {
      this.maxx = true;
    }
    else {
      //     search=1

      //  this.router.navigate(['home' + '/' + search])

      //     this.router.navigateByUrl('/home', { skipLocationChange: true }).then(() =>
      //       this.router.navigate(['home' + '/' + search.value]));


      if (this.filterObj.cityName == undefined) {
        this.filterObj.cityName = sessionStorage.getItem('city') + ',' + sessionStorage.getItem('state')


        this.filterObj.cityName = this.filterObj.cityName.trim();



      }
      // alert(this.filterObj.propertyTypeId+' '+[this.filterObj.facing]+ +this.filterObj.cityName)
      // this.veification=this.filterObj.veification.name
      console.log(this.filterObj.veification == undefined)

      if (this.filterObj.veification == undefined) {
        this.veification = 'undefined'
      }
      else {
        this.veification = this.filterObj.veification.name
      }
      if (this.filterObj.minprice == undefined) {
        alert('here')
        this.minprices = 'undefined'
      }
      else {
        this.minprices = this.filterObj.minprice
      }
      if (this.filterObj.maxprice == undefined) {
        this.maxprices = 'undefined'
      }
      else {
        this.maxprices = this.filterObj.maxprice
      }
      if (this.filterObj.facing == undefined) {
        this.facings = 'undefined'
      }
      else {
        this.facings = this.filterObj.facing
      }
      if (this.filterObj.propertyTypeId == undefined) {
        this.propertyid = 'undefined'
      }
      else {
        this.propertyid = (this.filterObj.propertyTypeId)
      }
      if (this.filterObj.rating == undefined) {
        this.ratings = 0
      }
      else {
        this.ratings = this.filterObj.rating.name
      }
      // alert(this.filterObj.veification.name)
      // alert(this.filterObj.minprice+''+this.filterObj.maxprice+"shi")

      this.filterss = { 'facing': JSON.stringify(this.facings), 'cityname': this.filterObj.cityName, 'propertytypeid': this.propertyid, 'minprice': this.minprices, 'maxprice': this.maxprices, 'verification': this.veification, 'ratings': this.ratings }
      sessionStorage.setItem('filterss', JSON.stringify(this.filterss))
      // sessionStorage.setItem('facing',JSON.stringify(this.filterObj.facing)) 
      // sessionStorage.setItem('cityname',this.filterObj.cityName);
      // sessionStorage.setItem('minprice',this.filterObj.minprice);
      // sessionStorage.setItem('maxprice',this.filterObj.maxprice);
      // sessionStorage.setItem('verification',this.veification);
      // sessionStorage.setItem('rating',this.ratings)
      // sessionStorage.setItem('propertytypeid',JSON.stringify(this.filterObj.propertyTypeId))
      // this.nls.getfilters(this.filterObj.propertyTypeId,this.filterObj.facing,this.filterObj.cityName,this.filterObj.minprice,this.filterObj.maxprice,this.veification,this.ratings).subscribe(data => {
      //  this.router.navigate(['home'+'/fdf'])

      this.router.navigateByUrl('/homeref', { skipLocationChange: true }).then(() =>
        this.router.navigate(["home" + "/filters"]));


      //  alert(JSON.stringify(data))
      //   data;
      //   this.filte=data;
      //   this.fil="sddf";

      // })

      // console.log( this.filterObj.propertyTypeId))
      // this.router.navigate(['search' + '/' + search.value])
      // this.router.navigateByUrl('/homeref', { skipLocationChange: true }).then(() =>
      //   this.router.navigate(['search' + '/' + search.value]));

    }
  }
  accept(username, property_id, notification_id) {
    this.tenantnotify.property_id = property_id
    this.tenantnotify.from_username = sessionStorage.getItem('uname');
    alert(this.tenantnotify.from_username)
    this.tenantnotify.to_username = username;
    alert(this.tenantnotify.to_username)
    this.tenantnotify.message = "accept";
    this.tenantnotify.status = "unseen";
    this.tenantnotify.notification_type = 'accept';
    alert('123')
    this.tenantnotify.notifydate = new Date();
    this.nls.addagentnotifications(this.tenantnotify).subscribe(data => {
      // console.log(data);
    })

    this.nls.updateNotification([notification_id]).subscribe(data => {
      // console.log(data);
      this.ngOnInit();

    })
    this.addagent.agent_username = username;
    this.addagent.property_id = property_id;
    this.addagent.status = 'accepted'

    this.nls.insertowneragent(this.addagent).subscribe(data => { console.log(data) })
    this.nls.updateagentrequest(notification_id, this.addagent.status).subscribe(data => {

      this.notify();
      this.ngOnInit();
    })

  }
  reject(username, property_id, notification_id) {

    this.nls.updateNotification([notification_id]).subscribe(data => {
      // console.log(data);
      this.ngOnInit();
    })
    this.addagent.agent_username = username;
    this.addagent.property_id = property_id;
    this.addagent.status = 'rejected';
    // this.nls.insertowneragent(this.addagent).subscribe(data => { console.log(data) })
    this.nls.updateagentrequest(notification_id, this.addagent.status).subscribe(data => {
      // console.log(data)
      this.notify();
      this.ngOnInit();
    })
  }

  postproperty() {
    if (sessionStorage.getItem('uname')) {
      this.router.navigate(['postproperty'])
    }
    else {
      swal({
        title: 'You are not logged in!!',
        text: "Please login to post your property!!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Login Here'
      }).then((result) => {
        if (result.value) {
          sessionStorage.setItem("PP", "postProperty");
          this.router.navigate(['login'])
        }
      })
    }
  }

  homeNavigate() {
    this.makefiltersnull();

    let user = sessionStorage.getItem("user_type");
    alert(user)
    if (user == 'Agent') {
      this.router.navigate(['agent']);
    }

    else if (user == 'Admin') {
      this.router.navigate(['admin']);
    }
    else {
      this.router.navigate(['home']);
    }
  }

  LogoutClick() {
    this.makefiltersnull();

    sessionStorage.removeItem('country');
    this.visibleSidebar1 = false;
    swal({
      title: 'Are you sure!!',
      text: "Logout from Nearluk!!",
      width: '400px',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        sessionStorage.removeItem("uname")
        sessionStorage.clear();
        this.router.navigateByUrl('/homeref', { skipLocationChange: true }).then(() =>
          this.router.navigate(["home"]));
        this.ngOnInit();
        this.ngDoCheck();
      }
    })
  }

  ngDoCheck() {
    this.CheckLocalStore().subscribe((data) => { this.logstatus = data })

    if (sessionStorage.getItem('compare1') != null) { this.compare1 = 1 } else { this.compare1 = 0 }
    if (sessionStorage.getItem('compare2') != null) { this.compare2 = 1 } else { this.compare2 = 0 }
    if (sessionStorage.getItem('compare3') != null) { this.compare3 = 1 } else { this.compare3 = 0 }
    if (sessionStorage.getItem('remove') == 'remo') {
      this.compare1 = 0;
      this.compare2 = 0;
      this.compare3 = 0;

      sessionStorage.removeItem('remove')

    }

    this.comparecount = this.compare1 + this.compare2 + this.compare3


  }
  count() {
    this.nls.getnotification(sessionStorage.getItem('uname')).subscribe(data => {
      this.notificationscount = data.length;
      // console.log(this.notificationscount + 'n')
      if (this.notificationscount == 0) {
        this.notificationscount = null;
      }
    })
  }

  profile() {
    this.router.navigate(['profile'])
  }
  changepasswd() {
    this.router.navigate(['changepswd/' + sessionStorage.getItem('uname')])
  }

  ProfileImg() {
    let z = sessionStorage.getItem('uname');
    this.nls.getByUsernameWithImage(z).subscribe((data) => {
      this.profileUser = data[0].name;
      this.userImage = data[0].img;
      this.country_id = data[0].country_id;

      if (data[0].user_type == 'Agent') {
        this.agent = true;
      }
      else if (data[0].user_type == 'Admin') {
        this.admin = true;
      }
      else {
        this.owner = true;
      }

      this.country_id = data[0].country_id;
      // alert(this.country_id)

      if (this.country_id != null) {
        this.nls.GetNofication(this.country_id).subscribe((data) => {
          this.adminnotification = data;
          // alert(JSON.stringify(data))
        });
      }
    });
  }


  ngOnInit() {

    if (sessionStorage.getItem("uname")) {
      setInterval(() => {
        this.count()
      }, 5000)
    }

    if (sessionStorage.getItem("uname")) {
      this.ProfileImg();
    }
    let z = sessionStorage.getItem('uname');

    // this.nls.getByUsernameWithImage(z).subscribe((data) => {
    //   this.updateProfile = data;
    //   // this.profileUser = data[0].name;
    //   // this.userImage = data[0].img;

    //   this.country_id = data[0].country_id;
    //   // alert(this.country_id)

    //   if (this.country_id != null) {
    //     this.nls.GetNofication(this.country_id).subscribe((data) => {
    //       this.adminnotification = data;
    //       // alert(JSON.stringify(data))
    //     });
    //   }


    //   if (data[0].user_type == 'Agent') {
    //     this.agent = true;
    //   }
    //   else if (data[0].user_type == 'Admin') {
    //     this.admin = true;
    //   }
    //   else {
    //     this.owner = true;
    //   }
    // });



    this.city = sessionStorage.getItem('city')

    this.nls.getPropertyType().subscribe((data) => {//Get Property Type Dropdown

      // alert(JSON.stringify(data))
      this.propertytype = data;

    });



    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latt = position.coords.latitude;
        this.lngg = position.coords.longitude;
        this.gMapsService.getLatLan(this.latt, this.lngg).subscribe(result => {

        }, error =>
            console.log(error),

          () => console.log('Geocoding completed!')
        );


      });
    }
    else {
      alert("Geolocation is not supported by this browser.");
    }

    // Display Flag Code  
    let country = sessionStorage.getItem('country');

    let con = country.trim();

    this.flag = 'http://localhost:4500/' + con + '.png'
  }

}

import { Component, OnInit } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from '../app.component';
import { Trending } from '../models/trending';
import { GMapsService } from '../services/gmaps.service';

@Component({
  selector: 'app-nearu',
  templateUrl: './nearu.component.html',
  styleUrls: ['./nearu.component.css']
})
export class NearuComponent implements OnInit {

  propertyList: any; // Home Cards Get
  latt: any;
  lngg: any;
  Trending: Trending;
  city: any;
  array: any[] = [];
  count: number = 0;
  showPopup: boolean = false;
  pid1: any;

  p: number;
  event: number = 1;

  pagecount: any;
  constructor(private nls: NearlukService, private router: Router, public myapp: AppComponent, private gMapsService: GMapsService, private acr: ActivatedRoute) {
    this.Trending = new Trending();
  }


  
  page($event) {
    this.event = $event;
    this.ngOnInit();
  }

  pagepage(){
    let j = this.acr.snapshot.params.id;
 
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latt = position.coords.latitude;
        this.lngg = position.coords.longitude;
        this.event = this.event + 1;
        this.nls.nearU(this.latt, this.lngg,this.event).subscribe((data) => {
          this.propertyList = data;
        })
        this.gMapsService.getLatLan(this.latt, this.lngg).subscribe(result => {

        }, error =>
            console.log(error),

          () => console.log('Geocoding completed!')
        );


      });
    }
    else {
      alert("Geolocation is not supported by this browser.");
    }

  }

  checkedd(property_id: any, chk: any) {

    if (chk.checked) {

      this.array.push(property_id)
      this.count++
      if (this.count > 3) {
        this.count--;
        chk.checked = false;
        alert("Excedd the limit ...")
        this.array.splice(this.array.length - 1, 1);
      }
      else {

      }
    }

    else {
      let index = this.array.indexOf(property_id)
      // this.array.pop();
      this.array.splice(index, 1);
      this.count--
    }


  }

  btnCompare() {

    this.router.navigate(['compare/' + this.array[0] + '/' + this.array[1] + '/' + this.array[2]])
  }


 

  // MoreDetails(property_id: any) {
  //   // alert(property_id)


  //   this.router.navigate(['moredetails' + '/' + property_id])
  // }

  closeEventHandler(res: boolean) {
    this.showPopup = res;
  }
  MoreDetails(property_id: any,ownername:any) {
    alert(ownername)
        var username=sessionStorage.getItem('uname');
    
        if(username!=null && ownername!= username){
          this.nls.Insert_property_views(property_id,username).subscribe((data) => {
           
          })
        }
        
        alert("val of showpoopup :" + this.showPopup);
    
        this.pid1 = property_id;
    
        alert("Property Id is  : " + this.pid1)
        this.showPopup = true;
    
    
    
        // window.open("moredetails" + '/' + property_id);
      }

  trendings(type, id) {   //insert and update trending when clicked on card
    alert("trending")
    var dt = new Date()
    let h = dt.getMonth() + 1;
    this.Trending.date = dt.getFullYear() + '_' + h + '_' + dt.getDate();
    alert(this.Trending.date)

    this.Trending.property_type = type;
    this.Trending.property_id = id;

    this.nls.getTrendingId(id).subscribe((data) => {
      alert(JSON.stringify(data))
      if (data.length < 1) {
        alert("not ")
        this.nls.insertTrendingCount(this.Trending).subscribe((data) => {
          alert("posted")
        })
      }
      else {
        alert("yes")
        this.nls.updateTrendingCount(id).subscribe((data) => {
          alert("puted")
        })
      }
    })


  }

  trendingFilter(filter) {    //
    alert(filter.value)
    this.city = sessionStorage.getItem('city').toString().trim()

    console.log(this.city)
    // this.city = 'vijayawada'

    this.nls.getTrendingFiltersId(filter.value, this.city).subscribe((data) => {
      alert(JSON.stringify(data))
      this.propertyList = data;
    })
  }

  ngOnInit() {
    this.pagepage();
  
  }

}

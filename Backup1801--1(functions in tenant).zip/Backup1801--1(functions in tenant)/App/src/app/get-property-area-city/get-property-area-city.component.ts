import { Component, OnInit } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';
import { GMapsService } from '../services/gmaps.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-get-property-area-city',
  templateUrl: './get-property-area-city.component.html',
  styleUrls: ['./get-property-area-city.component.css']
})
export class GetPropertyAreaCityComponent implements OnInit {
  latt: number;
  lngg: number;
  propertyList: any;
  showPopup: boolean;
  pid1: any;
  display: boolean;

  constructor(private nls: NearlukService, private gMapsService: GMapsService, private acr: ActivatedRoute) { }
  closeEventHandler(res: boolean) {
    this.showPopup = res;
  }
  MoreDetails(property_id: any) {
    alert('here');
    alert("val of showpoopup :" + this.showPopup);

    this.pid1 = property_id;

    alert("Property Id is  : " + this.pid1)
    this.showPopup = true;



    // window.open("moredetails" + '/' + property_id);
  }
  ngOnInit() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latt = position.coords.latitude;
        this.lngg = position.coords.longitude;

        var propertytype = this.acr.snapshot.params.propertytype;

        var city = sessionStorage.getItem('city').trim();
        this.nls.getproertytypebylatlng(this.latt, this.lngg, propertytype, city).subscribe(data => {
          this.propertyList = data
          sessionStorage.setItem('getpropertybyarea', 'true');
          this.display = true;;
        })
        this.gMapsService.getLatLan(this.latt, this.lngg).subscribe(result => {

        }, error =>
            console.log(error),

          () => console.log('Geocoding completed!')
        );
   });
    }
    else {
      alert("Geolocation is not supported by this browser.");
    }
  }
}

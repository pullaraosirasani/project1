import { videos } from './../models/videos';
import { Component, OnInit } from '@angular/core';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { Validators, FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { images } from '../models/images';
import { Router } from '@angular/router';
import { community } from '../models/gatedcommunity';

import { propertyAddress } from '../models/propertyAddress';
import { postproperty } from '../models/property';
import { propertylocation } from '../models/propertymap';
import { NearlukService } from '../services/nearluk.service';


class Aminity {
  id: number;
  amName: string;
}
interface marker {
  lat: number;
  lng: number;
  label?: string;
  draggable: boolean;
}


@Component({
  selector: 'app-post-property',
  templateUrl: './post-property.component.html',
  styleUrls: ['./post-property.component.css']
})


export class PostPropertyComponent implements OnInit {

  div: any;
  community_add_Show: boolean = false;
  ThirdButton: boolean = false;
  SecondButton: boolean = false;
  FirstButton: any = false;
  nearByArr: any[] = [];
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;

  property: postproperty;
  optionPropertyType: any;     // Dropdowns
  optionCurrency: any;  // Dropdowns
  optionsdimensionsunits: any;  // Dropdowns
  propertylocation: propertylocation;
  city: any;
  district: any
  amenitiesGet: any;
  count: any;
  propertyId: any;
  amenitiesPost: any;
  facilitiesGet: any;
  amenitiesPostValue: any;
  amenitiesPostid: any;
  propertyaddress: propertyAddress;
  optionscountries: any; // Dropdowns
  optionsState: any;// Dropdowns
  optionsCity: any;// Dropdowns
  optionsArea: any;// Dropdowns
  amArray: any[] = [];
  markers: marker[];
  uploadFiles: any[] = [];
  img: images;
  facilitiesImg: any;
  facilitiesGet1: any[] = [];
  gatedcommunity: community;

  showCancelButton: boolean = false;
  optionscity: any;
  optionsstate: any;


  public address: any;
  public typesOptions: string[];
  public options = { type: 'address', componentRestrictions: { country: null } };
  public lat: number = 17.4269661;
  public lng: number = 78.44887770000003;
  display: boolean;
  gcommunity: any;
  uploadedFiles: any[] = [];
  vid: videos;
  map1: string;
  video: videos;
  displayvideo: boolean;
  isUploadEnable: boolean;
  Communityvalue: any;


  constructor(private nls: NearlukService, private _formBuilder: FormBuilder, private router: Router) {
    this.property = new postproperty();
    this.propertylocation = new propertylocation();
    this.propertyaddress = new propertyAddress();
    this.img = new images();
    this.gatedcommunity = new community();
    this.vid = new videos();
    this.video=new videos();
  }




  videoUpload(event) { //video upload
    this.vid.property_id = this.propertyId
    for (let file of event.files) {
      this.uploadedFiles.push(file);
      let fr = new FileReader()
      fr.readAsDataURL(this.uploadedFiles[0]);
      fr.onload = (evnt: any) => {
        this.vid.videos = fr.result;
        alert(this.vid.videos)
        this.vid.videos = this.vid.videos.replace("data:video/mp4;base64,", "")
        this.vid.videos = this.vid.videos.replace("data:video/x-ms-wmv;base64,", "")
        this.vid.videos = this.vid.videos.replace("data:video/x-ms-mp4;base64,", "")

        // this.nls.addim(this.vid).subscribe(data => { console.log(data) })
      }
    }
  }
  ;
  // public uploader: FileUploader

  // uploadAll() { //video upload
  //   this.uploader.uploadAll();
  //   this.router.navigateByUrl('/mypropertiesref', { skipLocationChange: true }).then(() =>
  //     this.router.navigate(['myproperties']));
  // }


  onUpload(event) {     //upload Images
    this.img.property_id = this.propertyId;
    alert(this.propertyaddress.property_id + 'PROPERTY ID')
    for (let file of event.files) {
      this.uploadFiles.push(file);
    }
    for (let i = 0; i < this.uploadFiles.length; i++) {
      this.img.image = this.uploadFiles[i];

      var reader = new FileReader();
      reader.readAsDataURL(this.uploadFiles[i]);   // read file as data url
      reader.onload = (ev: any) => {                 // called once readAsDataURL is completed
        this.img.image = ev.target.result;

        this.img.image = this.img.image.replace('data:image/gif;base64,', '')
        this.img.image = this.img.image.replace('data:image/jpeg;base64,', '')
        this.img.image = this.img.image.replace('data:image/png;base64,', '')

        this.nls.addImages(this.img).subscribe((data) => {


        })
      }
    }
    alert('uploaded')
    // this.uploadAll();


  }

  communityFormShow() {
    this.community_add_Show = true;
  }
  hide_popup_community_name() {
    this.property.cm_id = this.Communityvalue;
    this.display = false;
  }

  
  postgated_community(form: any) {
    // alert()
    // alert(cn+cd+cc)
    if ((this.gatedcommunity.community_name == '') || (this.gatedcommunity.community_name == null) || (this.gatedcommunity.city == '') || (this.gatedcommunity.city == null)) {
      // alert('this.gatedcommunity')
    }
    // let comObj: community = new community();



    // this.gatedcommunity.community_name = cn.value
    // this.gatedcommunity.community_description = cd.value;
    // this.gatedcommunity.city = cc.value
    else {
      this.nls.gated_community(this.gatedcommunity).subscribe((data) => {
        // alert("posted successfully")
        this.property.cm_id = data[0].add_community
        this.display = false;

        // alert(JSON.stringify(data))
        // alert(data.cm_id)
      })
    }
  }

  gatcommunity(event: any) {
    if (event.target.checked == true) {
      this.display = true;
    }
  }

  cncl() {

  }

  addProperty() {
    this.nls.addProperty(this.property).subscribe((data) => {  //Post property Step 1
      alert(JSON.stringify(data))
      this.propertyId = data.id
      alert(data.id)

    })
  }

  submitlastpage() {

    this.img.property_id = this.propertyId;
    // this.nls.addim(this.vid).subscribe(data => { console.log(data) })
    this.nls.setPropertyAsActive(this.propertyId).subscribe((data) => {

    })
    // this.nls.addImages(this.img).subscribe((data) => {

    // })
    // this.uploader.uploadAll();

    this.router.navigateByUrl('/mypropertiesref', { skipLocationChange: true }).then(() =>
      this.router.navigate(['myproperties']));


  }

  nearBy(a: any) {
    this.nearByArr.push(a.value)
  }

  nearClick1() {
    //    this.FirstButton=true
    this.SecondButton = true
  }

  nearClick2() {
    this.ThirdButton = true
    // this.SecondButton=false
  }


  amenity(id: number, a) {   // Storing Aminities in an Array
    let amObj: Aminity;
    amObj = new Aminity();
    amObj.id = id;
    amObj.amName = a.value;


    this.amArray.push(amObj)

    this.count = 0
    this.amArray.forEach(element => {
      if (element.id == id) {
        this.count = this.count + 1;
        if (this.count == 2) {
          this.amArray.forEach(element2 => {
            if (element2.id == id) {
              let index = this.amArray.indexOf(element2)
              console.log(element)
              this.amArray.splice(index, 1);
            }
          })
          this.amArray.push(amObj)
          this.count = 0;
        }
      }
    });
    console.log(this.amArray);
  }


  array: any = [];
  checkBox(a: any) {    // storing facilities in an array
    this.array = this.array.concat(a)
    this.count = 0
    for (let i = 0; i <= this.array.length; i++) {

      if (this.array[i] == a) {
        this.count = this.count + 1;

        if (this.count == 2) {
          let index = this.array.indexOf(a)
          this.array.pop();
          this.array.splice(index, 1);
          console.log('this.array')
          this.count = 0
        }
      }
    }
    console.log(this.array);
  }

  addFacilitiesAndAmenities() {  // Posting Facilities & Aminities (Step 3)

    for (var i = 0; i < this.amArray.length; i++) {

      this.nls.addAmenities(this.propertyId, this.amArray[i].id, this.amArray[i].amName).subscribe((data) => {
      });
    }

    for (var i = 0; i < this.array.length; i++) {
      this.nls.addFacilities(this.array[i], this.propertyId).subscribe((data) => {
      });
    }
  }


  getStatesByCountryId(countryId) { // Get States By CountryId

    this.nls.getStatesByCountry(countryId.value).subscribe((data) => {
      this.optionsState = data;

    })
  }


  getCitysByStateId(stateId: any) { // Get Citys By StateId


    this.nls.getCitysByStateId(stateId.value).subscribe((data) => {
      this.optionsCity = data;

    })
  }
  getAreaByCityId(cityId: any) {  // Get Area By CityId

    this.nls.getAreasByCityId(cityId.value).subscribe((data) => {
      this.optionsArea = data

        ;
    })
  }


  // public uploader: FileUploader = new FileUploader({ url: 'http://localhost:4500/property/video/'+this.propertyId });

  // addPropertyAddress() {   // Posting Property Map and Address (Step 2)
  //   alert(this.propertyId)
  //   this.propertyaddress.property_id = this.propertyId;
  //   this.div = 'video';
  //   if (this.div) {
  //     this.uploader = new FileUploader({ url: 'http://localhost:4500/property/video/' + this.propertyId });
  //   }

  //   this.propertylocation.property_id = this.propertyId;

  //   //this.propertysNearBy.property_id=this.propertyId;
  //   //this.propertysNearBy.nearby_propertyname=this.propertyaddress.nearby_propertyname

  //   this.propertylocation.latitude = this.lat
  //   this.propertylocation.longitude = this.lng
  //   this.propertylocation.city = this.city
  //   // this.propertylocation.district = this.district
  //   // alert(this.propertylocation.latitude + "" + this.propertylocation.longitude + this.propertylocation.city)
  //   //console.log(this.propertysNearBy.nearby_propertyname)
  //   this.nls.addPropertyAddress(this.propertyaddress).subscribe((data) => {

  //   })


  //   this.nearByArr.forEach(element => {
  //     this.propertyaddress.nearby_propertyname = element

  //     this.nls.PropertyNearBy(this.propertyaddress).subscribe((data) => {

  //     })


  //   })


  //   this.nls.addPropertylocationMap(this.propertylocation).subscribe((data) => {
  //   })




  // }


  postPropertyAddress() {   // Posting Property Map and Address (Step 2)

    alert(this.propertyId)
    this.propertyaddress.property_id = this.propertyId;
    this.div = 'video';
    // if (this.div) {
    //   this.uploader = new FileUploader({ url: 'http://localhost:4500/property/video/' + this.propertyId });
    // }

    this.propertylocation.property_id = this.propertyId;

    //this.propertysNearBy.property_id=this.propertyId;
    //this.propertysNearBy.nearby_propertyname=this.propertyaddress.nearby_propertyname

    this.propertylocation.latitude = this.lat
    this.propertylocation.longitude = this.lng
    // this.propertylocation.city = this.city
    alert("Address is  : " + this.propertyaddress.address)

    // this.propertylocation.district = this.district
    // alert(this.propertylocation.latitude + "" + this.propertylocation.longitude + this.propertylocation.city)
    //console.log(this.propertysNearBy.nearby_propertyname)



    this.nls.addPropertyAddress(this.propertyaddress).subscribe((data) => {
      alert(JSON.stringify(this.propertyaddress))
    })


    this.nearByArr.forEach(element => {
      this.propertyaddress.nearby_propertyname = element

      this.nls.PropertyNearBy(this.propertyaddress).subscribe((data) => {

      })
    })


    this.nls.addPropertylocationMap(this.propertylocation).subscribe((data) => {
    })
  }

  UpdateProperty(propertyId: any) {
    alert(propertyId + "hiiiiiiiii")
    this.property.property_id = this.propertyId

    alert(this.property.property_id + "hellokjhdkfsh")

    this.nls.properetyupdateProperty(this.property).subscribe((data) => {  //Post property Step 1
    })
  }

  updatePropertyDetails() {


    this.property.property_id = this.propertyId


    this.nls.deleteFacilitiesAndAmnities(this.propertyId).subscribe((data) => {
      console.log(data)
      if (this.amArray != null) {

        for (var i = 0; i < this.amArray.length; i++) {
          this.nls.addAmenities(this.propertyId, this.amArray[i].id, this.amArray[i].amName).subscribe((data) => {
          });
        }
      }
      alert(this.array.length)
      console.log(this.array)

      if (this.array.length != null) {
        for (var i = 0; i < this.array.length; i++) {
          this.nls.addFacilities(this.array[i], this.propertyId).subscribe((data) => {
          });
        }
      }
    })

    this.nls.updateProperty(this.property).subscribe((data) => {

    });
  }



  getAmenties(propertyTypeid) {  // Get Amenties
    this.nls.getAmenties(propertyTypeid.value).subscribe((data) => {
      this.amenitiesGet = data
      alert(JSON.stringify(this.amenitiesGet))

        ;
    });
  };
  getFacilities(propertyTypeid: any) {

    this.nls.getFacilities1(propertyTypeid.value).subscribe((data) => {

      data.forEach(element => {
        let obj: any = { "fid": element.facilityid, "fname": element.facilityname, "fimg": "http://localhost:4500/" + element.facilityname + '.png' }
        this.facilitiesGet1.push(obj);

      });
      console.log("Faiclities with images: " + JSON.stringify(this.facilitiesGet1))
    })

  }

  closeClick() {
    this.display = false;

  }

  getStates(id: any) {
    this.nls.getStatesByCountry(id.value).subscribe((data) => {
      this.optionsstate = data;
    });
  }
  getCities(id: any) {
    this.nls.getCitysByStateId(id.value).subscribe((data) => {
      this.optionscity = data;
    });
  }

  getAreas(id: any) {
    this.nls.getAreaByCityId(id.value).subscribe((data) => {
      this.optionsArea = data;
    })
  }

  onSubmit(form: NgForm) {
    form.resetForm();
  }

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({   //For Stepper
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({  // For Stepper
      secondCtrl: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({ // For Stepper
      thirdCtrl: ['', Validators.required]
    });

    this.property.username = sessionStorage.getItem('uname');
    this.property.enable_bidding = true;


    this.nls.getCountries().subscribe((data) => { //Get Countries Dropdown
      this.optionscountries = data;
    })

    this.nls.getPropertyType().subscribe((data) => {//Get Property Type Dropdown
      this.optionPropertyType = data;
    });

    this.nls.getgatedcommunity().subscribe((data) => {//Get Property Type Dropdown
      this.gcommunity = data
        //alert(JSON.stringify(data))
        //alert(this.gcommunity.cm_id)

        ;
    });


    this.nls.getcurrency().subscribe((data) => { //Get Currency Dropdown
      this.optionCurrency = data
        // alert(JSON.stringify(this.optionCurrency));

        ;
    });

    this.nls.getCountry().subscribe((data) => {
      this.options = data;
    });

    this.nls.getUnits().subscribe((data) => {  //Get Dimensions dropdown
      this.optionsdimensionsunits = data;
      // alert(JSON.stringify(data))

    })
  }
  // getAddress(place: Address) {
  //   console.log(place);
  // }
  // FormatAddress(event: any) { //Lat Long Bindings(Marker)
  //   console.log(event);
  //   this.markers = [{ lat: event.lat, lng: event.lng, label: 'A', draggable: true }]
  // }

  handleAddressChange(address: Address) {

    // alert(JSON.stringify(address))
    // alert(JSON.stringify(address.address_components))
    // alert(JSON.stringify(address.address_components[0].long_name))

    let addr = JSON.stringify(address.formatted_address)
    // var lastItem = item.split(",").pop(-1);
    // let country = addr.split(/[\s,]+/)
    // alert(addr)
    // alert(country)
    // alert(country[country.length - 1] + "con")
    let ad = JSON.parse(addr)
    let cntry = ad.split(/[\s,]+/)
    let country = cntry[cntry.length - 1];
    alert(country)
    // this.propertyaddress.country = country;

    let latlngData = JSON.stringify(address.geometry.location)
    let latValue = JSON.parse(latlngData).lat;
    let lngValue = JSON.parse(latlngData).lng

    this.markers = [{ lat: latValue, lng: lngValue, label: 'A', draggable: true }]

  }

  FormatAddress(event: any) { //Lat Long Bindings(Marker)
    this.propertyaddress.country = event.country
    this.propertyaddress.city = event.city
    this.propertyaddress.state = event.state

    this.propertyaddress.district = event.district;
    alert(this.propertyaddress.district)
    console.log(this.propertyaddress.country);
    this.map1 = "./assets/images/nearU.png"
    this.markers = [{ lat: event.lat, lng: event.lng, label: 'A', draggable: true }]

    // this.nls.getAreasByCityId(this.propertyaddress.city).subscribe((data) => {
    //   alert(this.propertyaddress.city)
    //   console.log(this.propertyaddress.city)
    //   this.optionsArea = data
    //   console.log(data)


    // })
    this.nls.getAreasByCityname(this.propertyaddress.city, this.propertyaddress.district, this.propertyaddress.state).subscribe((data) => {

      console.log(this.propertyaddress.city)
      this.optionsArea = data;
      console.log(data);
    })
  }
  onChange(event: any) { //Change Marker address
    console.log(event);
    if (event === 'country') {
      this.options = { type: 'country', componentRestrictions: { country: null } };
    }
    this.address = '';
  }

  markerDragEnd(m: marker, $event: any) { //Google Map Marker Dragging code
    console.log(m, $event);
    let a = $event
    console.log(a);
    this.lat = $event.coords.lat
    this.lng = $event.coords.lng

  }

  validateFile(event,file){

    for (let index = 0; index < event.files.length; index++) {
      
     console.log(event.files[index].type)
     console.log('hgghgh')
     if(event.files[index].type=='video/mp4'){
      this.isUploadEnable=true;
      
    }
    else{
      this.isUploadEnable=false;
      alert('upload mp4 video');
      this.isUploadEnable=true;
      file.remove(event,index);
      console.log();
    }
    }
    // for(let files of event.files){
    
    // if(files.type=='video/mp4'){
    //   this.isUploadEnable=true;
    //   console.log(files);
    // }
    // else{
    //   this.isUploadEnable=false;
    //   alert('upload mp4 video');
    //   file.remove(event,0);
    //   console.log(files);
    // }
    // }
      }
  onvideoUpload(event) {
    this.video.property_id = this.propertyId
    for(let file of event.files) {
      
        this.uploadedFiles.push(file);
        let fr = new FileReader()
        fr.readAsDataURL(this.uploadedFiles[0]); 
        alert(this.uploadFiles)
        console.log(this.uploadFiles)
        fr.onload=(evnt:any)=>{
          this.video.videos=fr.result;
        var formatt=this.video.videos.split(';',1);
        alert(formatt);
        if(formatt=='data:video/mp4'){
          this.displayvideo=true;
          this.video.videos=this.video.videos.replace("data:video/mp4;base64,","")
          this.video.videos=this.video.videos.replace("data:image/jpeg;base64,","")
          this.video.videos=this.video.videos.replace("data:video/x-ms-wmv;base64,","")
          console.log(this.video)
          alert(this.video.videos)
          this.nls.addvideos(this.video).subscribe(data=>{data})
        }
        else{
          this.uploadFiles.pop(); 
        alert(this.uploadFiles);
        console.log(this.uploadFiles)
          alert('please upload only mp4 video formatt');
        }
          
        }
        }
      
        console.log('here');
        console.log(this.uploadedFiles)
       

  
}


}

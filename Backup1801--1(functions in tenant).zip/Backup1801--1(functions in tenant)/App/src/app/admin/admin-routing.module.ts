import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { GetuserdetailsComponent } from './getuserdetails/getuserdetails.component';
import { GetcontactdetailsComponent } from './getcontactdetails/getcontactdetails.component';
import { NotificationComponent } from './notification/notification.component';

const routes: Routes = [
  {path:'admin', component:AdminhomeComponent},
  {path:'userdetails', component:GetuserdetailsComponent},
  {path:'contact', component:GetcontactdetailsComponent},
  {path:'notification', component:NotificationComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { GetcontactdetailsComponent } from './getcontactdetails/getcontactdetails.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { GetuserdetailsComponent } from './getuserdetails/getuserdetails.component';
import { NotificationComponent } from './notification/notification.component';
import { InputSwitchModule } from 'primeng/inputswitch';
import { DialogModule } from 'primeng/dialog';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [GetcontactdetailsComponent, AdminhomeComponent, GetuserdetailsComponent, NotificationComponent],
  imports: [
    CommonModule,
    AdminRoutingModule,
    InputSwitchModule,
    DialogModule,
    FormsModule
  ],
  exports:[GetuserdetailsComponent, AdminhomeComponent, NotificationComponent, GetcontactdetailsComponent]
})
export class AdminModule { }

import { Component, OnInit } from '@angular/core';
import { NearlukService } from 'src/app/services/nearluk.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {

  propertyList: any;
  display = "";
  userdetails: any[] = [];
  username;
  checked: boolean = true;
  email;
  notchecked = false;
  myProp = 'V'
  myProp1 = 'Active'

  constructor(private nls: NearlukService) { }

  AdminSort(sorting) {
    if (sorting.value == 'V') {

      this.nls.GetSorting(sorting.value).subscribe((data) => {
        this.propertyList = data;
      })
    }
    else if (sorting.value == 'N') {
      this.nls.GetSorting(sorting.value).subscribe((data) => {
        this.propertyList = data;
      })

    }
    else if (sorting.value == 'Incomplete') {
      this.nls.GetSortingActive(sorting.value).subscribe((data) => {
        this.propertyList = data;
      })
    }
    else if (sorting.value == 'Active') {
      this.nls.GetSortingActive(sorting.value).subscribe((data) => {
        this.propertyList = data;
      })
    }
  }

  handleChange(event, property_id) {
    alert(JSON.stringify(event))
    this.nls.verified(property_id).subscribe(data => {
      if (event == false) {
        this.myProp = 'V';
      }
    })
  }
  handleChangee(event, property_id) {
    alert(JSON.stringify(event))

    this.nls.verified(property_id).subscribe(data => {
      alert('here')
      if (event == false) {
        alert('here')
        this.nls.Inactive(property_id, 'Incomplete').subscribe(data => {
          console.log(data);
          this.myProp1 = 'Active';
        })

      }
      else {
        this.nls.Inactive(property_id, 'Active').subscribe(data => {
          console.log(data);
          this.myProp1 = 'Incomplete';

        })
      }
    })
  }

  ngOnInit() {

    this.nls.GetAdminHomeDetails().subscribe((data) => { // Home Cards Get
      this.propertyList = data;
    })
  }
}


import { Component, OnInit } from '@angular/core';
import { NearlukService } from 'src/app/services/nearluk.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-getcontactdetails',
  templateUrl: './getcontactdetails.component.html',
  styleUrls: ['./getcontactdetails.component.css']
})
export class GetcontactdetailsComponent implements OnInit {

  contact: any;

  constructor(private nls: NearlukService) { }


  StatusUpdate(ct_id:any){

    this.nls.updateStatus(ct_id).subscribe((data) => {

    })
    
  }

  ngOnInit() {

    this.nls.getContact().subscribe((data) => {

      this.contact = data
      alert(JSON.stringify(data))

    })

  }
}

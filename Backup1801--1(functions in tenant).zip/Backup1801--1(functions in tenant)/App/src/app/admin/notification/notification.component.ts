import { Component, OnInit } from '@angular/core';
import { adminnotification } from 'src/app/models/adminnotification';
import { NearlukService } from 'src/app/services/nearluk.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  notify: adminnotification;
  options: any;
  countryid: any;
  NotificationBind: any;
  constructor(private nls: NearlukService) {
    this.notify = new adminnotification();
  }
  StatusInactive(id: any) {
    let status = "A"
    this.nls.statusDelete(id, status).subscribe(data => {
      this.ngOnInit();
    })
  }
  StatusDelete(id: any) {
    let status = "I"
    this.nls.statusDelete(id, status).subscribe(data => {
      this.ngOnInit();
    })

  }








  send(msg) {
    alert(msg);
    this.notify.message = msg;
    this.notify.country_id = this.countryid
    this.nls.adminnotification(this.notify).subscribe(data => {
      console.log(data);
    })
  }
  country(c) {
    this.countryid = c;
  }

  ngOnInit() {
    this.nls.getCountries().subscribe((data) => {

      this.options = data
      // alert(JSON.stringify(data))

    })

    this.nls.GetAllAdminNotifications().subscribe((data) => {
      this.NotificationBind = data;
    })
  }

}


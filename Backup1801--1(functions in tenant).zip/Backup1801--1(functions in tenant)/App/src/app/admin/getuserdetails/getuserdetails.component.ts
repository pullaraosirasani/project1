import { Component, OnInit } from '@angular/core';
import { NearlukService } from 'src/app/services/nearluk.service';

@Component({
  selector: 'app-getuserdetails',
  templateUrl: './getuserdetails.component.html',
  styleUrls: ['./getuserdetails.component.css']
})
export class GetuserdetailsComponent implements OnInit {
  Users: any;
  userdetails: any[] = [];
  display: string = "";
  username: any;
  display1="";
  search1="";

  constructor(private nls: NearlukService) { }
  Edit(username) {
    this.username = username;
    alert(username)
    this.display = "sdsd";
    this.nls.getByUserName(username).subscribe(data => {
      this.userdetails = data[0]
      console.log(this.userdetails)

    })
  }
  search(search){
    this.display1="sdd";
    this.search1=search;
    this.nls.getByUserName(search).subscribe(data=>{
      this.Users=data[0];
      console.log(this.Users)
    })
  }
  edituser(mobile, email) {


    this.nls.edituserbyadmin(this.username, mobile, email).subscribe(data => {
      console.log(data)
      this.display = "";
      this.search(this.username);
    })
  }

  ngOnInit() {

    // this.nls.getAllUsers().subscribe(data => {
    //   console.log(data);
    //   this.Users = data;
    //   // alert(JSON.stringify(data))

    // })

  }

}

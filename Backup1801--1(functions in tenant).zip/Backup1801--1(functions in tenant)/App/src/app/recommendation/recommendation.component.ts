import { Component, OnInit } from '@angular/core';
import { Enquiry_Form } from '../models/enquiryform';
import { ActivatedRoute } from '@angular/router';
import { NearlukService } from '../services/nearluk.service';

@Component({
  selector: 'app-recommendation',
  templateUrl: './recommendation.component.html',
  styleUrls: ['./recommendation.component.css']
})
export class RecommendationComponent implements OnInit {

  Enquiry: Enquiry_Form;
  i: any
  optionsarea: any
  Propertys: any;
  filter: any[] = [];
  count: any = 0;
  count1: any = 0;
  filter1: any[] = [];
  filter2: any[] = [];
  count2: number = 0;
  filter3: any[] = [];
  count3: number = 0;
  filter4: any = [];
  count4: number = 0;
  totalcount: number = 0;
  display = "";
  message = "Your enquiry form doesn't match our properties"
  showPopup: boolean = false;
  pid1: any;
  filter5: any = [];
  count5: number = 0;
  filter_city: any = [];
  count6: number = 0;

  p: number;

  constructor(private nls: NearlukService, private acr: ActivatedRoute) {

    this.Enquiry = new Enquiry_Form();

  }



  closeEventHandler(res: boolean) {
    this.showPopup = res;
  }


  MoreDetails(property_id: any, ownername: any) {
    alert(property_id)

    alert('here');
    var username = sessionStorage.getItem('uname');

    if (username != null && ownername != username) {
      this.nls.Insert_property_views(property_id, username).subscribe((data) => {

      })
    }


    alert("val of showpoopup :" + this.showPopup);

    this.pid1 = property_id;

    alert("Property Id is  : " + this.pid1)
     this.showPopup = true;
  }

  ngOnInit() {
    let username = sessionStorage.getItem('uname');
    this.nls.GetPropertyRecommendations(username).subscribe((data) => {
      this.Enquiry.property_type_id = data[0].propertytypeid;
      this.Enquiry.min_price = data[0].minprice;
      this.Enquiry.max_price = data[0].maxprice;
      this.Enquiry.facing = data[0].face;
      this.Enquiry.country = data[0].countryid;
      this.Enquiry.state = data[0].stateid;
      this.Enquiry.city = data[0].cityid;
      this.Enquiry.area = data[0].areaid;




      this.nls.SearchInOwnerPrpertyByEnquiryForm(this.Enquiry).subscribe((data) => {

        for (let index = 0; index < data.length; index++) {

          if (data[index].stateid === this.Enquiry.state) {
            this.filter5.push(data[index])
            this.count5 = 1;
          }

        }
        if (this.count5 == 0) {
          this.filter5 = data;
        }
        for (let index = 0; index < this.filter5.length; index++) {

          if (parseInt(this.filter5.cityid) == parseInt(this.Enquiry.city)) {
            this.filter_city.push(this.filter5[index])
            this.count6 = 1;
          }

        }
        if (this.count6 == 0) {
          this.filter_city = this.filter5;
        }

        for (let index = 0; index < this.filter_city.length; index++) {

          if (this.filter_city[index].face == this.Enquiry.facing) {
            this.filter.push(this.filter_city[index])
            this.count = 1;
          }
        }
        if (this.count == 0) {
          this.filter = this.filter5;
        }

        for (let index = 0; index < this.filter.length; index++) {

          if (parseInt(this.filter[index].propertytypeid) == parseInt(this.Enquiry.property_type_id)) {

            this.filter1.push(this.filter[index])
            this.count1 = 1;
          }

        }
        if (this.count1 == 0) {
          this.filter1 = this.filter;
        }
        for (let index = 0; index < this.filter1.length; index++) {
          if (parseInt(this.filter1[index].areaid) == parseInt(this.Enquiry.area)) {
            this.filter2.push(this.filter1[index])
            this.count2 = 1;
          }
        }
        if (this.count2 == 0) {
          this.filter2 = this.filter1;
        }
        for (let index = 0; index < this.filter2.length; index++) {

          if (parseInt(this.filter2[index].pprice) >= this.Enquiry.min_price) {
            this.filter3.push(this.filter2[index])
            this.count3 = 1;
          }
        }

        if (this.count3 == 0) {
          this.filter3 = this.filter2;
        }
        for (let index = 0; index < this.filter3.length; index++) {

          if (parseInt(this.filter3[index].pprice) <= this.Enquiry.max_price) {
            this.filter4.push(this.filter3[index])
            this.count4 = 1;
          }

        }
        if (this.count4 == 0) {
          this.filter4 = this.filter3;
        }
        this.totalcount = this.count + this.count1 + this.count2 + this.count3 + this.count4 + this.count5 + this.count6;
        alert(this.totalcount + ' ' + this.count + ' ' + this.count1 + ' ' + this.count2 + ' ' + this.count3 + ' ' + this.count4 + '' + this.count5)
        if (this.totalcount >= 3) {

          this.Propertys = this.filter4;
        }
        else {
          this.display = "ssdas";
        }

        console.log(data);

        console.log(this.filter5)
        console.log(this.filter_city)
        console.log(this.filter);
        console.log(this.filter1);
        console.log(this.filter2);
        console.log(this.filter3);
        console.log(this.filter4);

      })
    })
  }

}



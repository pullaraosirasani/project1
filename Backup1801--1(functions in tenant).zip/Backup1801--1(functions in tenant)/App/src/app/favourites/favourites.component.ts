import { Component, OnInit } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';
import { Router } from '@angular/router';
import swal from 'sweetalert2';

@Component({
  selector: 'app-favourites',
  templateUrl: './favourites.component.html',
  styleUrls: ['./favourites.component.css']
})
export class FavouritesComponent implements OnInit {

  favourites: any;
  i: any;
  showPopup: boolean = false;
  pid: any;
  pid1: any;

  p: number;
  event: number = 1;

  pagecount: any;
  constructor(private srvc: NearlukService, private router: Router) { }



  page($event) {
    this.event = $event;
    this.ngOnInit();
  }

  pagepage() {

    let uname = sessionStorage.getItem('uname');
    this.event = this.event + 1;
    this.srvc.getFavouriteDetails(uname, this.event).subscribe((data) => {
      // alert(JSON.stringify(data))
      this.favourites = data;
      console.log(data)
    })
  }

  ngOnInit() {
    this.pagepage();
  }


  Owner_Property_details(property_id: string, ownername: any) {




    var username = sessionStorage.getItem('uname');

    if (username != null && ownername != username) {


      this.srvc.Insert_property_views(property_id, username).subscribe((data) => {

      })
    }
    alert("val of showpoopup :" + this.showPopup);

    this.pid1 = property_id;

    alert("Property Id is  : " + this.pid1)
    this.showPopup = true;
  }

  btnDelClick(property_id: any, username: any) {
    swal({
      title: 'Are you sure to delete?',
      text: "You won't be able to revert this!!!",
      type: "warning",
      width: '400px',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.srvc.deleteFromFav(username, property_id).subscribe((data) => {
          this.ngOnInit();
          swal(
            'Deleted!',
            'Your file has been deleted.',
            'success'
          )
        })
      }
    })


  }

  closeEventHandler(res: boolean) {
    this.showPopup = false;
  }
}


import { AuthServiceConfig } from 'angularx-social-login';
import { AdminRoutingModule } from './admin/admin-routing.module';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { PostPropertyComponent } from './post-property/post-property.component';
import { ProfileComponent } from './profile/profile.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { ChfgpasswordComponent } from './chfgpassword/chfgpassword.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { EnquiryFormComponent } from './enquiry-form/enquiry-form.component';
import { RecommendationComponent } from './recommendation/recommendation.component';
import { MoredetailsComponent } from './moredetails/moredetails.component';
import { FavouritesComponent } from './favourites/favourites.component';
import { ContactagentComponent } from './contactagent/contactagent.component';
import { MyagentComponent } from './myagent/myagent.component';
import { MypropertiesComponent } from './myproperties/myproperties.component';
import { UpdatepropertyComponent } from './updateproperty/updateproperty.component';
import { CompareComponent } from './compare/compare.component';
import { ViewallnotificationsComponent } from './viewallnotifications/viewallnotifications.component';
import { NearuComponent } from './nearu/nearu.component';
import { FaqsComponent } from './faqs/faqs.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { MyOwnersComponent } from './agent/my-owners/my-owners.component';
import { BiddingComponent } from './bidding/bidding.component';
import { AgentRoutingModule } from './agent/agent-routing.module';
import { GetPropertyAreaCityComponent } from './get-property-area-city/get-property-area-city.component';
import { AuthenticateService as AuthGuard } from './services/authenticate.service';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'homeref', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'home/:value', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'loginref', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'postproperty', component: PostPropertyComponent, canActivate: [AuthGuard] },
  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },
  { path: 'updateprofile', component: UpdateprofileComponent, canActivate: [AuthGuard] },
  { path: 'changepswd/:username', component: ChfgpasswordComponent, canActivate: [AuthGuard] },
  { path: 'forgotpswd', component: ChfgpasswordComponent },
  { path: 'contactus', component: ContactusComponent },
  { path: 'aboutus', component: AboutusComponent },
  { path: 'enquiry', component: EnquiryFormComponent, canActivate: [AuthGuard] },
  { path: 'Recommendations', component: RecommendationComponent, canActivate: [AuthGuard] },
  { path: 'moredetails/:property_id', component: MoredetailsComponent, canActivate: [AuthGuard] },    //moredetails
  { path: 'favourites', component: FavouritesComponent, canActivate: [AuthGuard] },
  { path: 'contactagent', component: ContactagentComponent, canActivate: [AuthGuard] },
  { path: 'contactagent/:property_id', component: ContactagentComponent, canActivate: [AuthGuard] },
  { path: 'myagent', component: MyagentComponent, canActivate: [AuthGuard] },
  { path: 'myproperties', component: MypropertiesComponent, canActivate: [AuthGuard] },
  { path: 'search/:id', component: HomeComponent },
  { path: 'updateproperty/:propertyid', component: UpdatepropertyComponent, canActivate: [AuthGuard] },
  { path: 'compare', component: CompareComponent },
  { path: 'allnotifications', component: ViewallnotificationsComponent, canActivate: [AuthGuard] },
  { path: 'myowners', component: MyOwnersComponent, canActivate: [AuthGuard] },
  { path: 'nearu', component: NearuComponent },
  { path: 'faqs', component: FaqsComponent },
  { path: 'bidding', component: BiddingComponent, canActivate: [AuthGuard] },
  { path: 'getpropertybyarea/:propertytype', component: GetPropertyAreaCityComponent },
  { path: '**', component: PageNotFoundComponent },
 // { path: 'admin', loadChildren: './admin/admin.module#AdminModule' }


];

@NgModule({
  imports: [RouterModule.forRoot(routes), AgentRoutingModule, AdminRoutingModule],
  exports: [RouterModule],
  providers: [
    AuthGuard
  ],
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';
import { Router } from '@angular/router';
import { owneraddagent } from '../models/owneraddagent'
import { tenantnotifications } from '../models/tenantnotifications';

@Component({
  selector: 'app-viewallnotifications',
  templateUrl: './viewallnotifications.component.html',
  styleUrls: ['./viewallnotifications.component.css']
})
export class ViewallnotificationsComponent implements OnInit {

  notifications: any[];
  tenantnotify: tenantnotifications;
  addagent: owneraddagent;
  constructor(private service: NearlukService, private router: Router) {
    this.addagent = new owneraddagent();
    this.tenantnotify = new tenantnotifications();
  }
  moredetails(property_id) {
    console.log(property_id)
    this.router.navigate(['moredetails/' + property_id])
  }
  agentprofile(username) {
    console.log('agents')

    this.router.navigate(["agentprofile" + '/' + username])
  }
  accept(username: any, property_id: any, notification_id: any) {
    alert('accept')
    this.tenantnotify.property_id = property_id;
    this.tenantnotify.from_username = sessionStorage.getItem('uname');
    this.tenantnotify.to_username = username;
    this.tenantnotify.message = "";
    this.tenantnotify.status = "unseen";
    this.tenantnotify.notification_type = 'accept';

    this.tenantnotify.notifydate = new Date();

    this.service.addagentnotifications(this.tenantnotify).subscribe(data => {
      console.log(data);
    })
    this.addagent.agent_username = username;
    alert(this.addagent.agent_username)
    this.addagent.property_id = property_id;
    this.addagent.status = 'accepted'
    this.service.insertowneragent(this.addagent).subscribe(data => { console.log(data) })
    this.service.updateagentrequest(notification_id, this.addagent.status).subscribe(data => {
      console.log(data)
      this.ngOnInit();
    })

  }
  reject(username: any, property_id: any, notification_id: any) {
    this.tenantnotify.property_id = property_id
    this.tenantnotify.from_username = sessionStorage.getItem('uname');
    this.tenantnotify.to_username = username;
    this.tenantnotify.message = "";
    this.tenantnotify.status = "unseen";
    this.tenantnotify.notification_type = 'reject';
    this.tenantnotify.notifydate = new Date();
    this.service.addagentnotifications(this.tenantnotify).subscribe(data => {
      console.log(data);
    })
    this.addagent.agent_username = username;
    this.addagent.property_id = property_id;
    this.addagent.status = 'rejected';
    // this.service.insertowneragent(this.addagent).subscribe(data => { console.log(data) })
    this.service.updateagentrequest(notification_id, this.addagent.status).subscribe(data => {
      console.log(data)
      this.ngOnInit();
    })
  }
  ngOnInit() {
    var username = sessionStorage.getItem('uname');

    this.service.allnotifications(username).subscribe(data => {

      this.notifications = data;
      alert(JSON.stringify(data));

    })
  }

}

import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { postproperty } from '../models/property';
import { propertylocation } from '../models/propertymap';
import { NearlukService } from '../services/nearluk.service';
import { editimg } from '../models/editimg';
import { images } from '../models/images';
class Aminity {
  id: number;
  amName: string;
}
@Component({
  selector: 'app-updateproperty',
  templateUrl: './updateproperty.component.html',
  styleUrls: ['./updateproperty.component.css']
})

export class UpdatepropertyComponent implements OnInit {


  propertyDetailsforUpdate: postproperty;
  propertyId: any;
  property: any;
  propertylocation: propertylocation;
  optionPropertyType: any;
  facilitiesGet: any;
  amenitiesGet: any;
  propertyTypeid: any;
  array: any = [];
  count: any;

  facilitiesGetUserSelected: any;
  facilitiesGetUsernotSelected: any;

  optionsdimensionsunits: any;
  optionCurrency: any;

  facilitiesArray: any[] = [];
  facilitiesGet3: any[] = [];
  amenitiesArray: any[] = [];

  amenitiesArrayGet: any[] = [];
  amenitiesUserNotSelected: any;
  amArray: any[] = [];
  editimg: editimg;
  img: images;
  uploadFiles: any[] = [];
  dispalayimages: any[];
  constructor(private service: NearlukService, private acr: ActivatedRoute, private router: Router) {

    this.property = new postproperty();
    this.propertyDetailsforUpdate = new postproperty();
    this.propertylocation = new propertylocation();
    this.editimg = new editimg();
    this.img = new images();

  }


  checkBox(a: any) {

    this.array = this.array.concat(a)

    this.count = 0
    for (let i = 0; i <= this.array.length; i++) {

      if (this.array[i] == a) {


        this.count = this.count + 1;

        if (this.count == 2) {
          let index = this.array.indexOf(a)
          console.log(index + "step4")
          this.array.pop();
          this.array.splice(index, 1);
          console.log('this.array')
          this.count = 0
        }
      }
    }
    console.log(this.array);
  }



  amenity(id: number, a) {

    let amObj: Aminity;
    amObj = new Aminity();
    amObj.id = id;
    amObj.amName = a.value;

    this.amArray.push(amObj)

    this.count = 0
    this.amArray.forEach(element => {
      if (element.id == id) {
        this.count = this.count + 1;
        if (this.count == 2) {
          this.amArray.forEach(element2 => {
            if (element2.id == id) {
              let index = this.amArray.indexOf(element2)
              console.log(element)
              this.amArray.splice(index, 1);
            }
          })
          this.amArray.push(amObj)
          this.count = 0;
        }
      }
    });
    console.log(this.amArray);
  }




  updatePropertyDetails() {
    this.property.username = 'charan';


    this.propertyDetailsforUpdate.property_id = this.propertyId


    this.service.deleteFacilitiesAndAmnities(this.propertyId).subscribe((data) => {
      console.log(data)
      if (this.amArray != null) {

        for (var i = 0; i < this.amArray.length; i++) {
          this.service.addAmenities(this.propertyId, this.amArray[i].id, this.amArray[i].amName).subscribe((data) => {
          });
        }
      }
      // alert(this.array.length)
      console.log(this.array)

      if (this.array.length != null) {
        for (var i = 0; i < this.array.length; i++) {
          this.service.addFacilities(this.array[i], this.propertyId).subscribe((data) => {
          });
        }
      }


    })

    this.service.updateProperty(this.propertyDetailsforUpdate).subscribe((data) => {
      alert('updated succesfully...')
      this.router.navigate(['myproperties']);
    });


  }

  onUpload(event) {     //upload Images
    this.img.property_id = this.propertyId;
    // alert(this.propertyaddress.propertyId + 'PROPERTY ID')
    for (let file of event.files) {
      this.uploadFiles.push(file);
    }
    for (let i = 0; i < this.uploadFiles.length; i++) {
      this.img.image = this.uploadFiles[i];

      var reader = new FileReader();
      reader.readAsDataURL(this.uploadFiles[i]);   // read file as data url
      reader.onload = (ev: any) => {                 // called once readAsDataURL is completed
        this.img.image = ev.target.result;

        this.img.image = this.img.image.replace('data:image/gif;base64,', '')
        this.img.image = this.img.image.replace('data:image/jpeg;base64,', '')
        this.img.image = this.img.image.replace('data:image/png;base64,', '')

        this.service.addImages(this.img).subscribe((data) => {


        })
      }
    }
    alert('uploaded')

  }


  onUploading(a: any) {
    var a1 = (a.split("/"))
    a1 = a1.reverse()
    alert(a1[0])
    this.editimg.path = a1[0]
    this.editimg.image = a
    this.service.deleteImages(a1[0], this.propertyId).subscribe((data) => {

      // alert(JSON.stringify(data))
      // this.ngOnInit()
    })

  }

  ngOnInit() {
    this.propertyId = this.acr.snapshot.params.propertyid;



    this.service.getcurrency().subscribe((data) => {
      this.optionCurrency = data
        //  alert(JSON.stringify(this.optionCurrency ));
        // for( let i=0;i<=data.length;i++){
        //   this.options = data.length
        // }
        ;
    });
    this.service.getUnits().subscribe((data) => {
      this.optionsdimensionsunits = data;


    });
    this.service.getPropertyType().subscribe((data) => {
      this.optionPropertyType = data;
    });

    this.service.getcurrency().subscribe((data) => {
      this.optionCurrency = data
        //  alert(JSON.stringify(this.optionCurrency ));
        // for( let i=0;i<=data.length;i++){
        //   this.options = data.length
        // }
        ;
    });

    this.service.getPropertyDetailsForUpdate(this.propertyId).subscribe((data) => {
      this.property = data[0];
      this.propertyDetailsforUpdate.property_name = data[0].property_name;
      this.propertyDetailsforUpdate.price = data[0].price;
      this.propertyDetailsforUpdate.description = data[0].description;
      this.propertyDetailsforUpdate.units_id = data[0].units_id;
      this.propertyDetailsforUpdate.propertyArea = data[0].propertyarea;
      this.propertyDetailsforUpdate.landmarks = data[0].landmarks;
      this.propertyDetailsforUpdate.construction_status = data[0].construction_status;
      this.propertyDetailsforUpdate.security_deposit = data[0].security_deposit;
      this.propertyDetailsforUpdate.monthly_maintainance = data[0].monthly_maintainance;
      this.propertyDetailsforUpdate.rental_period = data[0].rental_period;

      var facilityid = this.property.facilities_id;
      var facilityName = this.property.facilities;



      if (facilityid != '') {

        this.array = this.property.facilities_id
        for (var i = 0; i < facilityid.length; i++) {
          console.log(facilityid[i]);
          for (var j = i; j <= i; j++) {
            console.log("enterd")
            console.log(facilityid[i] + '/' + facilityName[j]);
            this.facilitiesArray.push({ "fid": facilityid[i], 'fname': facilityName[i], "fimg": "http://localhost:4500/" + facilityName[i] + '.png' })
          }
        }

      }






      var amenityid = this.property.amenities_id;
      var amenityName = this.property.amenities;
      var amenityValue = this.property.amenities_value;
      var amenitiesValue = this.property.amenities_value;

      this.service.getFacilitiesUserNotSelect(this.propertyId).subscribe((data) => {


        data.forEach(element => {
          let obj: any = { "fid": element.facility_id, "fname": element.facility_name, "fimg": "http://localhost:4500/" + element.facility_name + '.png' }
          this.facilitiesGet3.push(obj);
        });
        console.log("Faiclities with images: " + JSON.stringify(this.facilitiesGet3))
      })



      this.service.GetImages(this.propertyId).subscribe((data) => {
        this.dispalayimages = []
        data.forEach(file => {
          this.dispalayimages.push({ source: file, alt: 'Description for Image 1', title: '' })
        });
        console.log("images:" + JSON.stringify(this.dispalayimages))
      });


      this.service.getAmenitiesUserNotSelect(this.propertyId).subscribe((data) => {

        this.amenitiesUserNotSelected = data;

      });
      if (amenityid != null) {
        for (var i = 0; i < amenityid.length; i++) {
          console.log(amenityid[i]);
          for (var j = i; j <= i; j++) {
            console.log(amenityid[i] + '/' + amenityName[j] + '/' + amenityValue[i]);
            let amObj: Aminity;
            amObj = new Aminity();
            amObj.id = amenityid[i];
            amObj.amName = amenitiesValue[i];

            this.amArray.push(amObj)

            this.count = 0
            this.amArray.forEach(element => {
              if (element.id == amenityid[i]) {
                this.count = this.count + 1;
                if (this.count == 2) {
                  this.amArray.forEach(element2 => {
                    if (element2.id == amenityid[i]) {
                      let index = this.amArray.indexOf(element2)
                      console.log(element)
                      this.amArray.splice(index, 1);
                    }
                  })
                  this.amArray.push(amObj)
                  this.count = 0;
                }
              }
            });



            this.amenitiesArrayGet.push({ "aid": amenityid[i], 'avalue': amenitiesValue[i], 'aname': amenityName[i] })


          }
        }
      }

























      this.service.getAmenties(data[0].property_type_id).subscribe((data) => {
        this.amenitiesGet = data
        console.log(this.amenitiesGet)




          ;
      });



    })




  }

}

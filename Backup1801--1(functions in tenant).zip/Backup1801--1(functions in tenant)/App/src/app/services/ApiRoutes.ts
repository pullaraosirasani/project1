export class ApiRoutes {
    nearlukurl: string;
    tenanturl: string;
    propertyurl: string;
    agenturl: string;
    ownerurl: string;
    adminurl: string;
    otpUrl: string;
    otpVerifyUrl: string;
    constructor() {
        this.nearlukurl = "http://localhost:4500/nearluk";
        this.tenanturl = "http://localhost:4500/tenant";
        this.propertyurl = "http://localhost:4500/property";
        this.agenturl = "http://localhost:4500/agent";
        this.ownerurl = "http://localhost:4500/owner";
        this.adminurl = "http://localhost:4500/admin";
        this.otpUrl = "http://localhost:4500/otp"
        this.otpVerifyUrl = "http://localhost:4500/verify"
    }
}
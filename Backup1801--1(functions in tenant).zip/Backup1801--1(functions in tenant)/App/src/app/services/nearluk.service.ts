import { gmaillogin } from './../models/gmailPost';
import { owneraddagent } from './../models/owneraddagent';
import { rating } from './../models/rating';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { register } from '../models/register';
import { postproperty } from '../models/property';
import { propertyAddress } from '../models/propertyAddress';
import { propertylocation } from '../models/propertymap';
import { Enquiry_Form } from '../models/enquiryform';
import { images, Profile } from '../models/images';
import { forum, Reply } from '../models/forum';
import { Bidding } from '../models/tbidding';
import { Trending } from '../models/trending';
import { community } from '../models/gatedcommunity';
import { contactus } from '../models/contactus';
import { videos } from '../models/videos';
import { ApiRoutes } from '../../app/services/ApiRoutes'
@Injectable({
  providedIn: 'root'
})
export class NearlukService {
  [x: string]: any;

  apiroutes: ApiRoutes;
  // nearlukurl: string = "http://localhost:4500/nearluk";
  // tenanturl: string = "http://localhost:4500/tenant";
  // propertyurl: string = "http://localhost:4500/property";
  // agenturl: string = "http://localhost:4500/agent";
  // ownerurl: string = "http://localhost:4500/owner";
  // adminurl: string = "http://localhost:4500/admin";
  // otpUrl: string = "http://localhost:4500/otp"
  // otpVerifyUrl: string = "http://localhost:4500/verify"


  constructor(private htc: HttpClient) {
    this.apiroutes = new ApiRoutes();
  }


  getByUserName(uid: any): Observable<any> {  // Login Check
    return this.htc.get(this.apiroutes.nearlukurl + '/getByUsername/' + uid, { responseType: 'json' });
  }
  getByUsernameWithImage(uname: any): Observable<any> {  // Login Check
    return this.htc.get(this.apiroutes.nearlukurl + '/getByUsernameWithImage/' + uname, { responseType: 'json' });
  }
  getByMobile(mobile: any): Observable<any> {  // Login Check
    return this.htc.get(this.apiroutes.nearlukurl + '/getByMobile/' + mobile, { responseType: 'json' });
  }

  RegisterPost(reg: register): Observable<any> { // Posting Registration Page
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.nearlukurl + '/signup', JSON.stringify(reg), httpOptions)
  }

  GetDropDownisds(country: any): Observable<any> {  // ISD Dropdown for register page
    return this.htc.get(this.apiroutes.nearlukurl + '/getAllIsdNumbers/' + country, { responseType: 'json' })
  }

  GetHomeDetails(page: any): Observable<any> {  // Home Cards get
    return this.htc.get(this.apiroutes.tenanturl + '/homeget/' + page, { responseType: 'json' });
  }

  getPropertyType(): Observable<any> {
    return this.htc.get(this.apiroutes.propertyurl + "/getPropertyTypes", { responseType: 'json' })
  }

  getgatedcommunity(): Observable<any> {
    return this.htc.get(this.apiroutes.propertyurl + "/getcommunity", { responseType: 'json' })
  }

  getStatesByCountry(countryId: any) {
    return this.htc.get(this.apiroutes.nearlukurl + "/state/" + countryId, { responseType: 'json' })
  }

  getCitysByStateId(stateId: any) {
    return this.htc.get(this.apiroutes.nearlukurl + "/city/" + stateId, { responseType: 'json' })
  }


  // getAreasByCityId(cityId: any) {
  //   return this.htc.get(this.apiroutes.nearlukurl + "/area/" + cityId, { responseType: 'json' })

  // }

  getAreasByCityname(cityName: any, districtName: any, state: any) {
    return this.htc.get(this.apiroutes.nearlukurl + "/areaByName/" + cityName + '/' + districtName + '/' + state, { responseType: 'json' })

  }



  getCountries(): Observable<any> {
    return this.htc.get(this.apiroutes.nearlukurl + "/getAllCountries", { responseType: 'json' })
  }
  getAmenties(propertyTypeId: any): Observable<any> {

    return this.htc.get(this.apiroutes.propertyurl + "/getPropertyAmenitiesByPropertyTypeId/" + propertyTypeId, { responseType: 'json' })
  }
  getFacilities(propertyTypeId: any): Observable<any> {

    return this.htc.get(this.apiroutes.propertyurl + "/getPropertyFacilitiesByPropertyTypeId/" + propertyTypeId, { responseType: 'json' })
  }


  getcurrency(): Observable<any> {  //Get 

    return this.htc.get(this.apiroutes.nearlukurl + "/getAllCurrency", { responseType: 'json' })
  };
  getUnits(): Observable<any> {

    return this.htc.get(this.apiroutes.nearlukurl + "/getAllUnits", { responseType: 'json' })
  };



  addProperty(property: postproperty): Observable<any> { //  Post property
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/postProperty', JSON.stringify(property), httpOptions)
  }
  addImages(images: images): Observable<any> {
    // alert(JSON.stringify(images))
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/postImages/', JSON.stringify(images), httpOptions)
  }


  addFacilities(facilities: any, propertyId: any): Observable<any> {  // Facilities Post
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/facilitiesPost/' + propertyId + '/' + facilities, httpOptions)
  }


  addAmenities(propertyId: any, amenityId: any, amenityValue): Observable<any> { //Aminities Post
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/amenitiesPost/' + propertyId + '/' + amenityId + '/' + amenityValue, httpOptions)
  }






  addPropertyAddress(propertyAddress: propertyAddress): Observable<any> { //  Property address post

    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/postPropertyAddress', JSON.stringify(propertyAddress), httpOptions)
  }


  addPropertylocationMap(propertylocation: propertylocation): Observable<any> {  //Property Location map post
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/propertyLocationMapPost', JSON.stringify(propertylocation), httpOptions)
  }

  getCountry(): Observable<any> {

    return this.htc.get(this.apiroutes.nearlukurl + '/getAllCountries/', { responseType: 'json' })
  }
  getAllStates(): Observable<any> {

    return this.htc.get(this.apiroutes.nearlukurl + "/getAllStates", { responseType: 'json' })
  }
  getAllCities(): Observable<any> {

    return this.htc.get(this.apiroutes.nearlukurl + "/getAllCities", { responseType: 'json' })
  }

  updateProfile(regObj: register): Observable<any> {   // Update Profile

    // alert(regObj.username)
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.nearlukurl + "/updateProfile/" + regObj.username, JSON.stringify(regObj), httpOptions);
  }

  updatePassword(reg: register): Observable<any> { //Update Password
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.nearlukurl + '/updatePassword/' + reg.username, JSON.stringify(reg), httpOptions)
  }
  // Enquiry form
  EnquiryFormAdd(enqFrm: Enquiry_Form): Observable<any> { //Enquiry form add
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.tenanturl, JSON.stringify(enqFrm), httpOptions)
  }
  EnquiryFormUpdate(Enq: Enquiry_Form) {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.tenanturl + '/username/' + Enq.username, JSON.stringify(Enq), httpOptions)
  }
  CheckinEnquiryForm_user(name: any) {
    return this.htc.get(this.apiroutes.tenanturl + '/getDataInEnquiryForm/' + name, { responseType: 'json' })
  }

  getexampledropdownarea(id: Enquiry_Form): Observable<any> {
    return this.htc.get(this.apiroutes.nearlukurl + "/area/" + id, { responseType: 'json' })
  }

  getAreaByCityId(cid: any): Observable<any> {
    return this.htc.get(this.apiroutes.nearlukurl + "/areaByCityId/" + cid, { responseType: 'json' })
  }

  GetPropertyRecommendations(i: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/getDataInEnquiryForm/' + i, { responseType: 'json' })

  }

  SearchInOwnerPrpertyByEnquiryForm(Enquiry: Enquiry_Form): Observable<any> {
    let obj: any = { "property_type_id": Enquiry.property_type_id, "country": Enquiry.country, "state": Enquiry.state, "city": Enquiry.city, "min_price": Enquiry.min_price, "max_price": Enquiry.max_price }
    return this.htc.get(this.apiroutes.tenanturl + '/getRecommendationsData1/' + JSON.stringify(obj), { responseType: 'json' })
  }

  getDataForNotification(property_id: any, username: any): Observable<any> {
    return this.htc.get(this.apiroutes.agenturl + '/getDataForNotification/' + property_id + '/' + username, { responseType: 'json' })
  }

  dataForAgentNotification(property_id: any, username: any, type: string): Observable<any> {
    return this.htc.get(this.apiroutes.agenturl + '/getDataForAgentNotification/' + property_id + '/' + username + '/' + type, { responseType: 'json' })
  }

  //More dretails and forum
  Property_Moredetails(property_id: any) {
    return this.htc.get(this.apiroutes.propertyurl + "/getPropertyDetailsforUpdate/" + property_id, { responseType: 'json' })
  }

  getComments(property_id: any): Observable<any> {

    return this.htc.get(this.apiroutes.propertyurl + '/forum/' + property_id, { responseType: 'json' })
  }
  commentSend(forum: forum): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/forum', JSON.stringify(forum), httpOptions)
  }

  GetCommentsReplys(comment_id: any): Observable<any> {
    return this.htc.get(this.apiroutes.propertyurl + '/getCommentReply/' + comment_id, { responseType: 'json' })
  }
  replays(reply: Reply): Observable<any> {
    // alert(JSON.stringify(reply))
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/reply', JSON.stringify(reply), httpOptions)
  }

  likeSend(property_id: any, username: any, Like: any): Observable<any> {  //Property Location map post
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.tenanturl + '/LikePost/like/post/' + property_id + '/' + username + '/' + Like, httpOptions)
  }



  dislike(property_id: any, username: any, Like: any): Observable<any> { //Update Password
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.tenanturl + '/updateLike/' + property_id + '/' + username + '/' + Like, httpOptions)
  }

  getlikesDislikes(property_id: any, likesstatus: any): Observable<any> {

    return this.htc.get(this.apiroutes.tenanturl + "/getLikes" + '/' + property_id + '/' + likesstatus, { responseType: 'json' })
  }

  getlikes(property_id: any, username: any): Observable<any> {

    return this.htc.get(this.apiroutes.tenanturl + "/getLikeStatus" + '/' + property_id + '/' + username, { responseType: 'json' })
  }

  addFavourite(property_id: any, username: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.tenanturl + '/addFavouritePost/' + property_id + '/' + username, httpOptions)

  }

  favouriteDetails(username: any, propertyId: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/favouriteDetails/' + username + '/' + propertyId, { responseType: 'json' })
  }

  Deletefromfav(pid: any, user: any): Observable<any> {
    return this.htc.delete(this.apiroutes.tenanturl + '/deleteFromFav/' + pid + '/' + user, { responseType: 'json' })
  }


  getFavouriteDetails(username: any, page: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/getFavourites/' + username + '/' + page, { responseType: 'json' })
  }


  deleteFromFav(username: any, property_id: any): Observable<any> {
    // alert(username + property_id)
    return this.htc.delete(this.apiroutes.tenanturl + '/deleteFavourites/del/' + property_id + '/' + username, { responseType: 'json' })
  }

  getMoreDetails(property_id: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/getFavourites/moredetails/' + property_id, { responseType: 'json' })
  }
  GetPropertyDetails(username: any, page: any): Observable<any> {  // Login Check
    return this.htc.get(this.apiroutes.tenanturl + '/getpropertydetails/' + username + '/' + page, { responseType: 'json' });
  }
  GetAllAgents(city: any, page: any): Observable<any> {  // Login Check
    return this.htc.get(this.apiroutes.agenturl + '/ListOfAgents/' + city + '/' + page, { responseType: 'json' });
  }
  // GetMYAgents(username: any): Observable<any> {  // Login Check
  //   return this.htc.get(this.apiroutes.agenturl + '/MyAgents/' + username, { responseType: 'json' });
  // }
  GetMYAgent(id: any, uname: any): Observable<any> { // based on pid get agents
    return this.htc.get(this.apiroutes.agenturl + '/MyAgent/' + id + '/' + uname, { responseType: 'json' });
  }

  GetMYAgents(username: any): Observable<any> { // based on pid get agents
    return this.htc.get(this.apiroutes.agenturl + '/MyAgents/' + username, { responseType: 'json' });
  }
  // postagentdetails(property_id: any, username: any): Observable<any> { // Posting agentdetails Page
  //   const httpOptions = {
  //     headers: new HttpHeaders({ 'content-type': 'application/json' })
  //   }
  //   return this.htc.post(this.apiroutes.ownerurl + '/insertOwnerAddAgent' + '/' + property_id + '/' + username, httpOptions)
  // }
  postAgentDetails(property_id: any, username: any): Observable<any> { // Posting agentdetails Page
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.ownerurl + '/OwnerAddAgentInsert/' + property_id + '/' + username, httpOptions)
  }

  getSearch(j: any): Observable<any> {

    return this.htc.get(this.apiroutes.tenanturl + '/search/all/' + j, { responseType: 'json' })
  }


  //**Bidding *rakesh/

  getBidding(property_id: any): Observable<any> {

    return this.htc.get(this.apiroutes.tenanturl + '/Bidding/' + property_id, { responseType: 'json' })
  }

  detailsforbiding(username: string): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/username/' + username, { responseType: 'json' })
  }

  priceSend(Bidd: Bidding): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.tenanturl + '/Bidding', JSON.stringify(Bidd), httpOptions)
  }
  // Update property by shiva
  updateProperty(property: postproperty): Observable<any> {


    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.propertyurl + '/updateProperty/' + property.property_id, JSON.stringify(property), httpOptions)
  }


  deleteFacilitiesAndAmnities(property_id: any): Observable<any> {
    return this.htc.delete(this.apiroutes.propertyurl + '/deleteFacilitiesAndAmnities/' + property_id, { responseType: 'json' })
  }

  getPropertyDetailsForUpdate(property_id: any): Observable<any> {


    return this.htc.get(this.apiroutes.propertyurl + '/getPropertyDetailsforUpdate/' + property_id, { responseType: 'json' })
  }




  getFacilitiesUserNotSelect(propertyId: any): Observable<any> {


    return this.htc.get(this.apiroutes.propertyurl + "/getPropertyFacilitiesByPropertyIdUsernotselected/" + propertyId, { responseType: 'json' })
  }

  getAmenitiesUserNotSelect(propertyId: any): Observable<any> {


    return this.htc.get(this.apiroutes.propertyurl + "/getPropertyAmenitiesByPropertyIdUsernotselected/" + propertyId, { responseType: 'json' })
  }


  // Update property by shiva End


  getTrendingId(id: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + "/getTrendingId/" + id, { responseType: 'json' })
  }

  insertTrendingCount(Trending: Trending): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.tenanturl + '/postTrendingId', JSON.stringify(Trending), httpOptions)
  }
  updateTrendingCount(id: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.tenanturl + '/updateTrendingId/' + id, httpOptions)
  }

  getTrendingFiltersId(filter: any, city: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + "/getTrendingFiltersId/" + filter + '/' + city, { responseType: 'json' })
  }

  sendRating(rating: rating): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    // alert(rating.property_id + rating.username)
    return this.htc.post(this.apiroutes.tenanturl + '/postRating', JSON.stringify(rating), httpOptions)
  }
  getRating(id: any, uname: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + "/getRating/" + id + '/' + uname, { responseType: 'json' })
  }
  updateRating(rating: rating): Observable<any> {


    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.tenanturl + '/updateRating/' + rating.property_id + '/' + rating.username, JSON.stringify(rating), httpOptions)
  }

  nearU(lat: any, long: any, page: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + "/getLatLng/" + lat + '/' + long + '/' + page, { responseType: 'json' })
  }

  //Owner INfo
  getOwnersInfo(propertyId): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + "/ownersInfo/" + propertyId, { responseType: 'json' });
  }

  getAgentInfo(propertyId: any): Observable<any> {
    return this.htc.get(this.apiroutes.agenturl + "/Agentsbasedonpid/" + propertyId, { responseType: 'json' });
  }

  GetImages(id: any): Observable<any> {

    return this.htc.get('http://localhost:4500/tenant/images' + '/' + id, { responseType: 'json' })
  }

  //Notifications
  getnotification(username): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/notification/' + username, { responseType: 'json' })
  }
  updateNotification(notification): Observable<any> {
    const head = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.tenanturl + '/notificationseen', notification, head);
  }
  allnotifications(username): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/allnotifications/' + username, { responseType: 'json' })
  }
  insertowneragent(addagent: owneraddagent): Observable<any> {
    alert(JSON.stringify(addagent))
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }

    return this.htc.post(this.apiroutes.agenturl + '/insertOwnerAddAgent/', JSON.stringify(addagent), httpOptions)
  }
  updateagentrequest(notification_id, status): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.ownerurl + '/notificationstatus/' + notification_id + '/' + status, {}, httpOptions)
  }


  //comapre
  GetCompare(propertyId: any): Observable<any> { //compare properties
    return this.htc.get(this.apiroutes.tenanturl + "/getCompare/" + propertyId, { responseType: 'json' })
  }

  getMyOwners(agent: any): Observable<any> {    //get owners that agent has been added
    return this.htc.get(this.apiroutes.agenturl + '/getMyOwners/' + agent, { responseType: 'json' })
  }

  sendNotification(pid: any, agent: any, owner: any): Observable<any> { //send notification
    // alert(pid + '|' + agent + '|' + owner)
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.agenturl + '/sendNotification/' + pid + '/' + agent + '/' + owner, httpOptions)
  }

  getFacilities1(propertyTypeid: any): Observable<any> {

    return this.htc.get(this.apiroutes.propertyurl + '/getPropertyFacilitiesByPropertyTypeId/' + propertyTypeid, { responseType: 'json' })
  }

  addagentnotifications(notification): Observable<any> {
    // alert('1')
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.ownerurl + '/agentnotify', JSON.stringify(notification), httpOptions)
  }

  PropertyNearBy(nearby: propertyAddress): Observable<any> {
    // alert("servc7usdc")
    // console.log("serviceeeeeeeeeeeeeeeeeee"+nearby)
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.ownerurl + '/nearby', JSON.stringify(nearby), httpOptions)
  }


  putProfileImages(images: Profile): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.nearlukurl + '/putProfileImages/', JSON.stringify(images), httpOptions)
  }

  cityAutoComplete(value: any): Observable<any> {

    return this.htc.get(this.apiroutes.tenanturl + '/cityAutoComplete/' + value, { responseType: 'json' })
  }

  getfilters(propertyType: any, facing: any, cityName: any, minprice: any, maxprice: any, verify: any, rating: any, page: any): Observable<any> {

    return this.htc.get(this.apiroutes.tenanturl + '/filterssearch/' + propertyType + '/' + facing + '/' + cityName + '/' + minprice + '/' + maxprice + '/' + verify + '/' + rating + '/' + page, { responseType: 'json' })


    // this.http.get("/api/test", {body: JSON.stringify{foo: "bar"}})

    // return this.htc.get(this.apiroutes.tenanturl+'/cityAutoComplete/', { responseType: 'json' })
  }

  getReviewsCount(property_id: any): Observable<any> {

    return this.htc.get(this.apiroutes.propertyurl + '/forum/count/' + property_id, { responseType: 'json' })
  }

  verified(property_id: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.adminurl + '/verification/' + property_id, {}, httpOptions)
  }
  Inactive(property_id: any, status: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.adminurl + '/Inactive/' + property_id + '/' + status, {}, httpOptions)
  }
  edituserbyadmin(username: any, mobile: number, email: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.adminurl + '/edituser/' + username + '/' + mobile + '/' + email, {}, httpOptions)
  }

  GetAdminHomeDetails(): Observable<any> {  // Home Cards get
    return this.htc.get(this.apiroutes.adminurl + '/', { responseType: 'json' });
  }



  getAllUsers(): Observable<any> {  // Home Cards get
    return this.htc.get(this.apiroutes.nearlukurl + '/getAllUsers', { responseType: 'json' });
  }

  adminnotification(notify): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.adminurl + '/adminnotification', JSON.stringify(notify), httpOptions)
  }


  GetNofication(countryId: any): Observable<any> {
    // alert(countryId)
    return this.htc.get(this.apiroutes.adminurl + '/GetNotifications/' + countryId, { responseType: 'json' })
  }

  GetAllAdminNotifications(): Observable<any> {

    return this.htc.get(this.apiroutes.adminurl + '/' + 'GetAllAdminNotifications', { responseType: 'json' })
  }

  statusDelete(id: any, status: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.adminurl + '/AdminNotification/' + id + '/' + status, httpOptions)
  }

  GetSorting(sorting: any): Observable<any> {
    return this.htc.get(this.apiroutes.adminurl + '/' + 'verified/' + sorting, { responseType: 'json' })
  }

  GetSortingActive(sorting: any): Observable<any> {
    return this.htc.get(this.apiroutes.adminurl + '/' + 'GetSortingActive/' + sorting, { responseType: 'json' })
  }

  gated_community(reg: community): Observable<any> { // Posting Registration Page
    //alert(reg.community_description)
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.propertyurl + '/gatedpost/community', JSON.stringify(reg), httpOptions)
  }
  homeMap(pid: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/map/' + pid, { responseType: 'json' })
  }

  addim(im): Observable<any> {
    const headop = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    alert(JSON.stringify(im));
    return this.htc.post(this.apiroutes.ownerurl + "/videoUpload", JSON.stringify(im), headop)
  }
  setPropertyAsActive(id: any): Observable<any> {
    alert(id + "PROPERTY ID")
    const headop = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.ownerurl + "/setPropertyAsActive/" + id, headop)
  }
  checkgmail(username: any): Observable<any> {

    alert(username + "shiva")

    return this.htc.get(this.apiroutes.tenanturl + '/checkgmailuser/' + username, this.httpOptions);
  }
  Insertgmail(gmail: gmaillogin): Observable<any> {

    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    // alert(JSON.stringify(athObj))
    return this.htc.post(this.apiroutes.tenanturl + "/gmailpost/", JSON.stringify(gmail), httpOptions)
  }
  loginen(username: any, Password: any): Observable<any> {
    return this.htc.get(this.apiroutes.nearlukurl + '/loginenc/' + username + '/' + Password, { responseType: 'json' });

  }
  sendotp(i: any): Observable<any> {
    return this.htc.get(this.apiroutes.otpUrl + '/' + i, { responseType: 'json' })
  }

  verify(a: any, b: any): Observable<any> {
    return this.htc.get(this.apiroutes.otpVerifyUrl + '/' + a + '/' + b, { responseType: 'json' })
  }
  deleteProperty(pid: any): Observable<any> {
    return this.htc.put(this.apiroutes.tenanturl + '/deleteMyProperty/' + pid, { responseType: 'json' })
  }
  deleteMyAgent(pid: any, agent: any): Observable<any> {
    return this.htc.delete(this.apiroutes.agenturl + '/deleteMyAgent/' + pid + '/' + agent, { responseType: 'json' })
  }
  // getidbycountry(country): Observable<any> {
  //   return this.htc.get(this.apiroutes.tenanturl + '/cityid/' + country, { responseType: 'json' })
  // }
  getidbycountry(city): Observable<any> {

    alert(JSON.stringify(city))

    return this.htc.get(this.apiroutes.tenanturl + '/cityid/' + JSON.stringify(city), { responseType: 'json' })
  }
  SendContact(contact: contactus): Observable<any> {

    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    // alert(JSON.stringify(athObj))
    return this.htc.post(this.apiroutes.adminurl + "/Contactpost/", JSON.stringify(contact), httpOptions)
  }
  getContact(): Observable<any> {
    return this.htc.get(this.apiroutes.adminurl + '/Contacts/', { responseType: 'json' });

  }
  updateStatus(ct_id: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.adminurl + '/AdminContact/' + ct_id, httpOptions)
  }
  biddingEnable(property_id: any, status: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.tenanturl + '/enableBidding/' + property_id + '/' + status, httpOptions)
  }
  getaveragebyarea(propertyType, area): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/averagebyarea/' + propertyType + '/' + area, { responseType: 'json' })
  }
  dataToSendNotification(property_id: any, username: any): Observable<any> {
    return this.htc.get(this.apiroutes.agenturl + '/dataToSendNotification/' + property_id + '/' + username, { responseType: 'json' })
  }
  biddingnotifications(notification): Observable<any> {
    // alert('1')
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.ownerurl + '/biddingnotify', JSON.stringify(notification), httpOptions)
  }
  getcurrencyBasedOnCountry(country: any): Observable<any> {
    return this.htc.get(this.apiroutes.nearlukurl + '/currencyBasedOnCountry/' + country, { responseType: 'json' })
  }
  properetyupdateProperty(property: postproperty): Observable<any> { //  Post property
    alert(property.property_id + "property_id")
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.propertyurl + '/updatepostProperty' + '/' + property.property_id, JSON.stringify(property), httpOptions)
  }
  Insert_property_views(propertId: any, username: any): Observable<any> {

    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    // alert(JSON.stringify(athObj))
    return this.htc.post(this.apiroutes.propertyurl + "/propertyviews/" + propertId + '/' + username, httpOptions)
  }
  property_view_for_owner(propertyId: any): Observable<any> {
    return this.htc.get(this.apiroutes.ownerurl + '/propertyViewsForOwner/' + propertyId, { responseType: 'json' })
  }
  getBiddingPropertyDetails(username: any, page: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/BiddingGetByusername/' + username + '/' + page, { responseType: 'json' })
  }
  getpropertybyareaorcity(city: any, area: any): Observable<any> {

    return this.htc.get(this.apiroutes.tenanturl + '/getpropertybyareaorcity/' + area + '/' + city, { responseType: 'json' });
  }
  getproertytypebylatlng(lat: any, lng: any, propertytype: any, city: any): Observable<any> {
    return this.htc.get(this.apiroutes.tenanturl + '/propertydetailsbyarea/' + lat + '/' + lng + '/' + propertytype + '/' + city, { responseType: 'json' }
    )
  }
  propertystatus(property_id: any, status: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.put(this.apiroutes.propertyurl + '/propertystatus/' + property_id + '/' + status, httpOptions)
  }

  addvideos(video: videos): Observable<any> {
    alert(JSON.stringify(video))
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.apiroutes.tenanturl + '/video', JSON.stringify(video), httpOptions)
  }
  deleteImages(image: any, property_id: any): Observable<any> {
    alert(property_id)
    return this.htc.delete(this.apiroutes.propertyurl + '/deleteImage/' + image + '/' + property_id, { responseType: 'json' })
  }
}

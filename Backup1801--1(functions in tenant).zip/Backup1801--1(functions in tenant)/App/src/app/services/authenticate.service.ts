import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService implements CanActivate {

  constructor(public router: Router) { }
  public isAuthenticated(): any {
    let uname = sessionStorage.getItem('uname')
    return uname
  }
  canActivate(): boolean {
    // alert("Auth user is : " + this.isAuthenticated())
    if (this.isAuthenticated()) {
      return true;
    }
    else {
      this.router.navigate(['home']);
    }
  }
}


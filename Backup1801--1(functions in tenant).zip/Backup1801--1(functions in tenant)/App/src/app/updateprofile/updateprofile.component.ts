import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { register } from '../models/register';
import { NearlukService } from '../services/nearluk.service';
import { Profile } from '../models/images';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {

  reg: register;
  profile: Profile;
  options: any;
  optionscity: any;
  optionsstate: any;
  username: any;


  constructor(private router: Router, private nls: NearlukService) {
    this.reg = new register();
    this.profile = new Profile();
  }

  onUpload(event) { //upload Images
    this.profile.username = this.username;
    alert(this.profile.username)
    alert(event.files[0])
    var reader = new FileReader();
    reader.readAsDataURL(event.files[0]); // read file as data url
    reader.onload = (ev: any) => { // called once readAsDataURL is completed
      this.profile.image = ev.target.result;
      this.profile.image = this.profile.image.replace('data:image/gif;base64,', '');
      this.profile.image = this.profile.image.replace('data:image/jpeg;base64,', '');
      this.profile.image = this.profile.image.replace('data:image/png;base64,', '');
      alert(this.profile.image)
      this.nls.putProfileImages(this.profile).subscribe((data) => {
      });
    }
  }

  getStates(id: any) {
    this.nls.getStatesByCountry(id.value).subscribe((data) => {
      this.optionsstate = data;
    });
  }
  getCities(id: any) {
    this.nls.getCitysByStateId(id.value).subscribe((data) => {
      this.optionscity = data;
    });
  }


  update(form: any) {
    if ((form.value.country == undefined) || (form.value.state == undefined) || (form.value.city == undefined)) {

    }
    else {
      this.nls.updateProfile(this.reg).subscribe((data) => {
        this.router.navigate(['profile']);
      });
    }
  }


  ngOnInit() {
    this.username = sessionStorage.getItem('uname');
    this.nls.getByUserName(this.username).subscribe((data) => {
      // alert(JSON.stringify(data))
      this.reg.username = this.username;
      this.reg.name = data[0].name;
      this.reg.mobile = data[0].mobile;
      this.reg.address = data[0].address;
      this.reg.gender = data[0].gender;
      this.reg.occupation = data[0].occupation;
      this.reg.email = data[0].email;
      this.reg.dob = data[0].dob;
      this.reg.user_type = data[0].user_type;
      this.reg.country = data[0].country_id;
      this.reg.state = data[0].state_id;
      this.reg.city = data[0].city_id;


      this.nls.getCountry().subscribe((data) => {
        this.options = data;
      });

      this.nls.getStatesByCountry(this.reg.country).subscribe((data) => {
        this.optionsstate = data;
      });

      this.nls.getCitysByStateId(this.reg.state).subscribe((data) => {
        this.optionscity = data;
      });
    });

  }
}
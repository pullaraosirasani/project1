import { Component, OnInit } from '@angular/core';
import { owneraddagent } from '../models/owneraddagent';
import { NearlukService } from '../services/nearluk.service';
import { ActivatedRoute, Router } from '@angular/router';
import { tenantnotifications } from '../models/tenantnotifications';
import { postproperty } from '../models/property';
import swal from 'sweetalert2';


@Component({
  selector: 'app-myproperties',
  templateUrl: './myproperties.component.html',
  styleUrls: ['./myproperties.component.css']
})
export class MypropertiesComponent implements OnInit {

  propertyList: any[]; // my property Cards Get
  username: any;
  a: any
  addagent: owneraddagent
  myagent: any;
  owner: string
  uname: any;
  agentUsername;
  tenantnotify: tenantnotifications;
  showPopup: boolean = false;
  pid1: any;
  property: postproperty;
  enable_bidding: boolean = true;
  notificationSent: boolean;

  p: number;
  event: number = 1;

  pagecount: any;
  userType: string;
  constructor(private nls: NearlukService, private acr: ActivatedRoute, private router: Router) {
    this.addagent = new owneraddagent()
    this.tenantnotify = new tenantnotifications();
    this.property = new postproperty();

  }
  closeEventHandler(res: boolean) {
    this.showPopup = false;
  }
  postProperty() {
    this.router.navigate(['postproperty']);
  }


  page($event) {
    this.event = $event;
    this.ngOnInit();
  }

  propertyStatusChange(event, property_id: any) {

    if (event.checked == true) {

      this.nls.propertystatus(property_id, 'Active').subscribe((data) => {
        // this.ngOnInit()
      })


      // alert(event.value)
    }
    else {
      this.nls.propertystatus(property_id, 'Inactive').subscribe((data) => {
        // this.ngOnInit()
      })
    }

  }

  pagepage() {


    this.owner = sessionStorage.getItem("uname");
    this.event = this.event + 1;
    this.nls.GetPropertyDetails(this.owner, this.event).subscribe((data) => { // my property Cards Get
      this.propertyList = data;
      // alert(JSON.stringify(this.propertyList))

    })
    this.username = this.acr.snapshot.params.username;
    this.userType = sessionStorage.getItem("user_type");
    alert(this.userType)

  }

  MoreDetails(property_id: any) {
    alert("val of showpoopup :" + this.showPopup);

    this.pid1 = property_id;

    alert("Property Id is  : " + this.pid1)
    this.showPopup = true;
  }

  addAgent(property_id: any) {


    this.agentUsername = this.acr.snapshot.params.username;

    alert(this.username)
    this.nls.GetMYAgent(property_id, this.agentUsername).subscribe((data) => { // my AGENTS Get
      //   this.myagent = data;

      alert(JSON.stringify(data))
      if (data.length > 0) {
        alert('already added')
      }
      else {
        // this.nls.postAgentDetails(property_id, this.agentUsername).subscribe((data) => {
        // alert('posted')
        this.tenantnotify.from_username = sessionStorage.getItem('uname');
        this.tenantnotify.notification_type = 'request';
        this.tenantnotify.property_id = property_id;
        this.tenantnotify.to_username = this.acr.snapshot.params.username;
        this.tenantnotify.status = 'unseen';
        this.tenantnotify.notifydate = new Date();
        alert(JSON.stringify(this.tenantnotify))
        this.nls.addagentnotifications(this.tenantnotify).subscribe(data => {
          this.notificationSent = true;
        })
        // })
      }
    })

  }



  update(property_id: any) {

    this.router.navigate(['updateproperty/' + property_id])
  }

  deleteProperty(pid: any) {

    swal({
      title: 'Are you sure to delete?',
      text: "You won't be able to revert this!!!",
      type: "warning",
      width: '400px',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.nls.deleteProperty(pid).subscribe((data) => {

          if (data.message == "Deleted") {

            this.propertyList.length = 0;
            this.nls.GetPropertyDetails(this.owner, this.event).subscribe((data) => { // my property Cards Get
              this.propertyList = data;
            })
            swal(
              'Deleted!',
              'Your file has been deleted.',
              'success'
            )
          }
          else {
            alert('Invalid Opr...')
          }

        })

      }
    })

  }


  handleChange(event, property_id: any) {

    if (event.checked == true) {
      this.nls.biddingEnable(property_id, 'true').subscribe((data) => {
        // this.ngOnInit()
      })
    }
    else {
      this.nls.biddingEnable(property_id, 'false').subscribe((data) => {
        // this.ngOnInit()
      })
    }

  }

  contactAgent(property_id: any) {
    this.router.navigate(['contactagent/' + property_id]);
  }
  ngOnInit() {

    this.pagepage();
  }
}




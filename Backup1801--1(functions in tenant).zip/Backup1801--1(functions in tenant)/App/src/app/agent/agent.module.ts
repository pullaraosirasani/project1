import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AgentRoutingModule } from './agent-routing.module';
import { MyOwnersComponent } from './my-owners/my-owners.component';
import { AgenthomeComponent } from './agenthome/agenthome.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { PropertydetailsToAgentComponent } from './propertydetails-to-agent/propertydetails-to-agent.component';
import { DialogModule } from 'primeng/dialog';
import { MatStepperModule } from '@angular/material/stepper';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { GalleriaModule } from 'primeng/galleria';
import { RatingModule } from 'primeng/rating';
import { AgmCoreModule } from '@agm/core';


@NgModule({
  declarations: [MyOwnersComponent, AgenthomeComponent, PropertydetailsToAgentComponent],
  imports: [
    CommonModule,
    AgentRoutingModule,
    NgxPaginationModule,
    DialogModule,
    MatStepperModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    GalleriaModule,
    RatingModule,
    AgmCoreModule
  ],
  exports: [MyOwnersComponent, AgenthomeComponent]
})
export class AgentModule { }

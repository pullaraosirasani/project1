import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { tenantnotifications } from 'src/app/models/tenantnotifications';
import { propertylocation } from 'src/app/models/map';
import { rating } from 'src/app/models/rating';
import { FormGroup, FormBuilder, NgForm, Validators } from '@angular/forms';
import { forum, Reply } from 'src/app/models/forum';
import { Bidding } from 'src/app/models/tbidding';
import { register } from 'src/app/models/register';
import { NearlukService } from 'src/app/services/nearluk.service';
import { Router } from '@angular/router';
import swal from 'sweetalert2';

class Aminity {
  id: number;
  amName: string;
}

@Component({
  selector: 'app-propertydetails-to-agent',
  templateUrl: './propertydetails-to-agent.component.html',
  styleUrls: ['./propertydetails-to-agent.component.css']
})
export class PropertydetailsToAgentComponent implements OnInit {

  @Input() pid: any;
  @Output() showpopEvent = new EventEmitter();

  propertylocation: propertylocation;
  rating: rating;
  Rating: any;
  property: any;
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  array: any = [];
  facilitiesArray: any[] = [];
  display: boolean = false;
  PropertysList: any;
  fourm: forum;
  Reply: Reply;
  hide: string;
  user: any
  reply: boolean = false;
  comment: any;
  Comments: any

  show: any;
  likesCount: any;
  dislikesCount: any;
  showreply: boolean = false;
  showreviews: boolean = true;
  showbidding: boolean;

  replies: any;
  bid_price: any;
  Bidd: Bidding;
  count: any;
  amArray: any[] = [];
  ownersinfo: any[] = [];
  agentinfo: any[] = [];
  visibleowner = "";
  disablebtn = "visible";

  amenitiesArrayGet: any[] = [];
  dispalayimages: any[];
  details: any;
  userdetailsbidding: boolean;
  username: string;
  register: register;
  userType: string;
  ownerUsername: any;
  noReviews: any;
  favourites: boolean = false;
  tenantnotification: tenantnotifications;
  ownername: string;
  Baseprice: number;
  agentVisible: boolean;
  baseprice: any;
  bidding_price: any;
  LikeStatus: any;
  ReviewsCount: any;
  notification: boolean;
  compare1: any;
  compare2: any;
  compare3: any;
  video: boolean = false;
  videoDisplay: string;
  agentAdded: boolean;
  bidding_enable: any;
  agents: any;
  propertyViewdUsers: any;
  viewedusers: boolean;
  noViews: boolean;

  constructor(private nls: NearlukService, private router: Router, private _formBuilder: FormBuilder) {
    this.fourm = new forum();
    this.Reply = new Reply();
    this.Bidd = new Bidding();
    this.rating = new rating();
    this.propertylocation = new propertylocation();
    this.register = new register();
    this.tenantnotification = new tenantnotifications();
  }

  checkedd(property_id: any, chk: any) {


    var v1 = 0
    var v2 = 0
    var v3 = 0


    if (sessionStorage.getItem('compare1') == property_id) {
      // sessionStorage.removeItem('compare1');
      v1 = 1
      v2 = 1
      v3 = 1

    }
    else if (sessionStorage.getItem('compare2') == property_id && v2 == 0) {
      // sessionStorage.removeItem('compare2');
      v1 = 1
      v2 = 1
      v3 = 1
    }
    else if (sessionStorage.getItem('compare3') == property_id && v3 == 0) {

      // sessionStorage.removeItem('compare3');
      v1 = 1
      v2 = 1
      v3 = 1
    }


    if (sessionStorage.getItem('compare1') == null && v1 == 0) {


      sessionStorage.setItem('compare1', property_id);


    }
    else if (sessionStorage.getItem('compare2') == null && v2 == 0) {
      sessionStorage.setItem('compare2', property_id);

      v2 = 1

    }
    else if (sessionStorage.getItem('compare3') == null && v3 == 0) {
      sessionStorage.setItem('compare3', property_id);
      v3 = 1
    }





    else if (sessionStorage.getItem('compare3') != null && sessionStorage.getItem('compare3') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare3');
    }
    else if (sessionStorage.getItem('compare1') != null && sessionStorage.getItem('compare1') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare1');
    }
    else if (sessionStorage.getItem('compare2') != null && sessionStorage.getItem('compare2') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare2');
    }



    else {

      chk.checked = false;
      alert("Excedd the limit ...")
    }


  }

  VideoPopup() {
    this.video = true;
  }

  AddToFavourite(i: any) {


    let z = sessionStorage.getItem('uname')
    if (!z) {

      this.router.navigate(['login'])
    }
    else {


      if (z) {
        let Tenant_Registeration: any;
        Tenant_Registeration = z;
        this.nls.addFavourite(i, Tenant_Registeration).subscribe((data) => {
          this.favourites = true;
          this.facilitiesArray = [];
          alert('added to favourite..')
          this.amenitiesArrayGet = [];
          this.ngOnInit();
        })


      }
    }

  }

  removeFavourite(property_id: any) {
    let username = sessionStorage.getItem("uname");
    this.nls.Deletefromfav(property_id, username).subscribe((data) => {
      this.favourites = false;
      this.facilitiesArray = [];
      alert('removed from favourite..')
      this.amenitiesArrayGet = [];
      this.ngOnInit();

    })


  }
  propertyviewsdetails() {

    this.viewedusers = true;


    this.nls.property_view_for_owner(this.pid).subscribe((data) => {


      this.propertyViewdUsers = data;


      // this.details = data;
      // this.userdetailsbidding = true;
      console.log(data);
    })


  }
  RatingSend(event, property_id: any) {
    this.rating.property_id = property_id;
    let uname = sessionStorage.getItem('uname')
    this.rating.username = uname;
    this.rating.rating = event.value;

    this.nls.getRating(property_id, uname).subscribe((data) => {

      if (data.length > 0) {
        if (!uname) {
          this.router.navigate(['login']);
        }
        else {
          this.nls.updateRating(this.rating).subscribe((data) => {

          })
        }
      }

      else {
        if (!uname) {
          this.router.navigate(['login']);
        }
        else {
          this.nls.sendRating(this.rating).subscribe((data) => {
            alert("insert")
          })
        }

      }
    })

  }

  GetComments() {
    this.showbidding = false;
    this.showreviews = true;
    let property_id = this.pid
    this.nls.getComments(property_id).subscribe((data) => {
      if (data.length > 0) {
        this.Comments = data;
      }
      else {
        this.noReviews = true;
      }
    })
  }
  // cncl(){

  //   this.router.navigate(['home'])
  // }

  closeClick() {

    // this.display = false;
    this.showpopEvent.emit("false");
    //this.ref.destroy();
    // this.router.navigateByUrl("https://www.google.com");
  }


  //OwnersINfo
  ownerinfo() {
    var uname = sessionStorage.getItem('uname');
    if (!uname) {
      this.router.navigate(['login']);
    }
    else {
      var property_id = this.pid;
      console.log(property_id + 'nh')
      this.nls.getOwnersInfo(property_id).subscribe(data => {
        this.ownerinfo = data[0];
        this.visibleowner = "visible";
        this.disablebtn = "";
        console.log(this.ownerinfo)
      })
    }

  }

  Agentinfo() {
    var uname = sessionStorage.getItem('uname');
    if (!uname) {
      this.router.navigate(['login']);
    }
    else {
      let property_id1 = this.pid;
      this.nls.getAgentInfo(property_id1).subscribe(data => {
        this.agentinfo = data;
        this.disablebtn = "";

      })
    }
  }


  // onNavigate(){
  //   //this.router.navigateByUrl("https://www.google.com");
  //   window.location.href="https://www.google.com";
  // }



  Like(property_id) {
    let username = sessionStorage.getItem('uname')
    this.nls.getlikes(property_id, username).subscribe((data) => {

      if (data.length >= 1) {
        if (data[0].likesstatus == 1) {
          let likes = 0;
          this.nls.dislike(property_id, username, likes).subscribe((data) => {
            this.facilitiesArray = [];

            this.amenitiesArrayGet = [];
            this.ngOnInit();
          })

        }
        else if (data[0].likesstatus == 0 || 2) {
          let likes = 1;
          this.nls.dislike(property_id, username, likes).subscribe((data) => {
            this.facilitiesArray = [];

            this.amenitiesArrayGet = [];
            this.ngOnInit();
          })
        }


      }
      else {
        if (!sessionStorage.getItem("uname")) {
          this.router.navigate(['login']);
        }
        else {
          let likes = 1
          this.nls.likeSend(property_id, username, likes).subscribe((data) => { // Like Post
            this.facilitiesArray = [];

            this.amenitiesArrayGet = [];
            this.ngOnInit();
          })
        }

      }
    })
  }


  disLike(property_id) {
    let username = sessionStorage.getItem('uname')
    this.nls.getlikes(property_id, username).subscribe((data) => {

      if (data.length >= 1) {
        if (data[0].likesstatus == 1 || data[0].likesstatus == 0) {
          let likes = 2;
          this.nls.dislike(property_id, username, likes).subscribe((data) => {
            this.facilitiesArray = [];

            this.amenitiesArrayGet = [];
            this.ngOnInit();
          })
        }
        else if (data[0].likesstatus == 2) {
          let likes = 0;
          this.nls.dislike(property_id, username, likes).subscribe((data) => {
            this.facilitiesArray = [];

            this.amenitiesArrayGet = [];
            this.ngOnInit();
          })
        }
      }
      else {
        if (!sessionStorage.getItem("uname")) {
          this.router.navigate(['login']);
        }
        else {
          let likes = 2
          this.nls.likeSend(property_id, username, likes).subscribe((data) => { // Like Post
            this.facilitiesArray = [];

            this.amenitiesArrayGet = [];
            this.ngOnInit();
          })
        }

      }
    })
  }


  RemoveFavourite(property_id: any, username: any) {
    swal({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      //alert(result.value)
      if (result.value) {
        this.nls.Deletefromfav(this.user, property_id).subscribe((data) => {

          //  this.toastr.success('Removed From Favourites!', 'Notification!');
          //  this.router.navigateByUrl('/addfav1', {skipLocationChange: true}).then(()=>
          //   this.router.navigate(["addfav"]));
          // swal(
          //   'Deleted!',
          //   'Your file has been deleted.',
          //   'success'

          // )
          this.ngOnInit();

        })

      }
    })
  }
  getBidding() {

    this.showbidding = true;
    this.showreviews = false;
    let property_id = this.pid;
    this.nls.getBidding(property_id).subscribe((data) => {
      this.bid_price = data;
    })
  }

  showreplay(comment_id) {
    this.show = comment_id;
    // alert(comment_id)
    this.nls.GetCommentsReplys(comment_id).subscribe((data) => {
      this.replies = data;
      alert(JSON.stringify(data))
    })
    this.showreply = true;
  }

  GetUserDetails(name: any) {

    this.nls.detailsforbiding(name).subscribe((data) => {
      this.details = data;
      this.userdetailsbidding = true;
      // alert(JSON.stringify(data))
      console.log(data);
    })
  }

  addProperty(owner: any) {

    let agent = sessionStorage.getItem("uname");
    let property_id = this.pid;
    this.nls.sendNotification(property_id, agent, this.ownerUsername).subscribe((data) => {
      alert('sent...')
      this.notification = true;
    })
  }



  ngOnInit() {

    this.compare1 = sessionStorage.getItem('compare1')
    this.compare2 = sessionStorage.getItem('compare2')
    this.compare3 = sessionStorage.getItem('compare3')
    this.userType = sessionStorage.getItem("user_type");

    this.username = sessionStorage.getItem('uname')
    this.firstFormGroup = this._formBuilder.group({   //For Stepper
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({  // For Stepper
      secondCtrl: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({ // For Stepper
      thirdCtrl: ['', Validators.required]
    });

    this.display = true; //for popup primeNg
    let property_id = this.pid;

    this.nls.getOwnersInfo(this.pid).subscribe(data => {
      this.ownername = data[0].user_name;
      this.Baseprice = data[0].pprice;

    })
    this.videoDisplay = 'http://localhost:4500/' + this.pid + '.mp4';


    this.nls.getDataForNotification(property_id, this.username).subscribe((data) => {
      alert(JSON.stringify(data))
      if (data.length > 0) {
        this.agentAdded = true;
      }
      else {
        this.agentAdded = false;
      }
    })

    this.nls.dataForAgentNotification(property_id, this.username, 'request').subscribe((data) => {
      if (data.length > 0) {
        this.notification = true;
      }
      else {
        this.notification = false;
      }
    })

    this.nls.getlikes(property_id, this.username).subscribe((data) => {
      if (data.length > 0) {
        this.LikeStatus = data[0].likesstatus;
      }
    })

    this.nls.getAgentInfo(property_id).subscribe((data) => {
      if (data.length > 0) {
        this.agents = data;
        this.agentVisible = true;
      }
      else {
        this.agentVisible = false;
      }
    })

    let user = sessionStorage.getItem("uname");

    let propertyId = this.pid

    this.nls.favouriteDetails(user, propertyId).subscribe((data) => {
      if (data.length > 0) {
        this.favourites = true;
      }
      else {
        this.favourites = false;
      }
    })

    this.nls.property_view_for_owner(property_id).subscribe((data) => {

      if (data.length > 0) {
        this.noViews = true;
      }
      else {
        this.noViews = false;
      }
    })


    this.nls.Property_Moredetails(property_id).subscribe((data) => {
      this.PropertysList = data;
      this.property = data[0];
      this.ownerUsername = data[0].username;
      this.baseprice = data[0].price;
      this.bidding_price = data[0].bidding_price;
      this.bidding_enable = data[0].bidding;

      this.propertylocation.latitude = parseFloat(data[0].latitude);
      this.propertylocation.longitude = parseFloat(data[0].longitude);


      var amenityid = this.property.amenities_id;
      var amenityName = this.property.amenities;
      var amenityValue = this.property.amenities_value;
      var amenitiesValue = this.property.amenities_value;


      if (amenityid != null) {
        for (var i = 0; i < amenityid.length; i++) {
          // console.log(amenityid[i]);
          for (var j = i; j <= i; j++) {
            console.log(amenityid[i] + '/' + amenityName[j] + '/' + amenityValue[i]);
            let amObj: Aminity;
            amObj = new Aminity();
            amObj.id = amenityid[i];
            amObj.amName = amenitiesValue[i];

            this.amArray.push(amObj)

            this.count = 0
            this.amArray.forEach(element => {
              if (element.id == amenityid[i]) {
                this.count = this.count + 1;
                if (this.count == 2) {
                  this.amArray.forEach(element2 => {
                    if (element2.id == amenityid[i]) {
                      let index = this.amArray.indexOf(element2)
                      console.log(element)
                      this.amArray.splice(index, 1);
                    }
                  })
                  this.amArray.push(amObj)
                  this.count = 0;
                }
              }
            });



            this.amenitiesArrayGet.push({ "aid": amenityid[i], 'avalue': amenitiesValue[i], 'aname': amenityName[i] })


          }
        }
      }




      var facilityid = this.property.facilities_id;
      var facilityName = this.property.facilities;



      if (facilityid != '') {

        this.array = this.property.facilities_id
        for (var i = 0; i < facilityid.length; i++) {
          console.log(facilityid[i]);
          for (var j = i; j <= i; j++) {
            console.log("enterd")
            console.log(facilityid[i] + '/' + facilityName[j]);
            this.facilitiesArray.push({ "fid": facilityid[i], 'fname': facilityName[i], "fimg": "http://localhost:4500/" + facilityName[i] + '.png' })
          }
        }

      }


    })

    this.nls.getRating(property_id, this.username).subscribe((data) => {
      this.rating.rating = data[0].rating
    })

    this.nls.getlikesDislikes(property_id, '1').subscribe((data) => {
      this.likesCount = data[0].likes_count;
      // alert(this.likesCount);
    })

    this.nls.getlikesDislikes(property_id, '2').subscribe((data) => {
      this.dislikesCount = data[0].likes_count;
      // alert(this.dislikesCount);

    })

    this.nls.getReviewsCount(property_id).subscribe((data) => {
      this.ReviewsCount = data;
      // alert(JSON.stringify(data));

    })


    this.nls.GetImages(property_id).subscribe((data) => {
      this.dispalayimages = []
      data.forEach(file => {
        //   let a = 'http://localhost:4500/NL18111616116146/Images/' + file
        this.dispalayimages.push({ source: file, alt: 'Description for Image 1', title: '' })
      });
      console.log(this.dispalayimages)
    });


  }


  btncomments(property_id: any, Comments: any) {
    if (!sessionStorage.getItem("uname")) {
      this.router.navigate(['login']);
    }
    else {
      this.fourm.property_id = property_id
      this.fourm.comments = Comments
      var dt = new Date()
      let month = dt.getMonth() + 1;
      this.fourm.date = dt.getFullYear() + '/' + month + '/' + dt.getDate();
      this.fourm.username = sessionStorage.getItem('uname')
      this.nls.commentSend(this.fourm).subscribe((data) => {
        this.GetComments();
      })
    }
  }
  onSubmit(myFrm: NgForm) {
    myFrm.resetForm();
  }
  btnprice(property_id: any, basePrice: any, bidding_price: any) {

    this.Bidd.property_id = property_id;
    this.Bidd.bidding_price = bidding_price.value;
    this.Bidd.username = sessionStorage.getItem('uname');

    if (this.ownerUsername == this.Bidd.username) {
      alert('YOU CANNOT BID YOUR OWN PROPERTY')
    }
    else {
      if (parseInt(basePrice) >= parseInt(bidding_price.value)) {
        alert("Bid price should be greater than base price..!")
      }
      else {
        if (!sessionStorage.getItem("uname")) {
          this.router.navigate(["login"]);
        }
        else {
          console.log(JSON.stringify(this.agentinfo))
          this.tenantnotification.property_id = property_id;
          this.tenantnotification.from_username = sessionStorage.getItem('uname');

          if (this.agentVisible == true) {
            alert('here')
            console.log(this.agents)
            console.log('agentsss')
            this.agents.push({ 'agent_username': this.ownername });
            console.log(this.agents);
            this.tenantnotification.to_username = (this.agents);
          }
          else {
            alert('not')
            this.tenantnotification.to_username = [{ 'agent_username': this.ownername }]
          }

          this.tenantnotification.notification_type = 'biding';
          this.tenantnotification.status = 'unseen';
          this.tenantnotification.notifydate = new Date();
          this.tenantnotification.message = bidding_price.value;

          this.nls.biddingnotifications(this.tenantnotification).subscribe(data => {
            console.log(data)
          })
          this.nls.priceSend(this.Bidd).subscribe((data) => {
            this.getBidding();

          })
        }
      }
    }
  }

  replay(comment: any) {
    this.reply = true
    this.comment = comment;
  }
  reSend(commnet_id: any, replycomment: any) {
    if (!sessionStorage.getItem("uname")) {
      this.router.navigate(['login']);
    }
    else {

      this.Reply.comment_id = commnet_id;
      this.Reply.reply = replycomment.value;


      this.Reply.username = sessionStorage.getItem('uname')


      this.nls.replays(this.Reply).subscribe((data) => {
        console.log(data)
        this.ngOnInit();
      })
    }

  }

}


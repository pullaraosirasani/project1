import { Component, OnInit } from '@angular/core';
import { NearlukService } from 'src/app/services/nearluk.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-owners',
  templateUrl: './my-owners.component.html',
  styleUrls: ['./my-owners.component.css']
})
export class MyOwnersComponent implements OnInit {

  owners: any;
  noOwners = false;
  constructor(private nls: NearlukService, private acr: Router) { }

  deleteOwners(pid: any) {
    let agent = sessionStorage.getItem("uname");

    this.nls.deleteMyAgent(pid, agent).subscribe((data) => {
      alert("deleted")
      this.ngOnInit();
    })
  }

  ngOnInit() {
    let agent = sessionStorage.getItem("uname");
    this.nls.getMyOwners(agent).subscribe((data) => {
      alert(JSON.stringify(data))
      this.owners = data;

    })
  }

}

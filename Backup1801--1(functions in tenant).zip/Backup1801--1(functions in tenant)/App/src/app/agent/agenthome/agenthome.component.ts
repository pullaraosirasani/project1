import { Component, OnInit, Input, DoCheck } from '@angular/core';
import { NearlukService } from 'src/app/services/nearluk.service';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-agenthome',
  templateUrl: './agenthome.component.html',
  styleUrls: ['./agenthome.component.css']
})
export class AgenthomeComponent implements OnInit, DoCheck {

  propertyList: any;
  showPopup: boolean = false;
  @Input()
  pid: any;
  pid1: any;
  p: number;
  event: number = 1;

  pagecount: any;
  ccount1: any = 0;
  ccount2: any = 0;
  ccount3: any = 0;
  comparecount: any;
  logstatus: any;
  constructor(private nls: NearlukService) { }

  page($event) {
    this.event = $event;
    this.ngOnInit();
  }



  pagepage() {

    this.event = this.event + 1;
    // alert(this.event)
    this.nls.GetHomeDetails(this.event).subscribe((data) => { // Home Cards Get
      this.propertyList = data;
    })

  }
  MoreDetails(property_id: any) {
    // window.open("moredetails" + '/' + property_id);
    // alert("val of showpoopup :" + this.showPopup);
    this.pid1 = property_id;
    alert("Property Id is  : " + this.pid1)
    this.showPopup = true;
  }

  closeEventHandler(res: boolean) {
    this.showPopup = false;
  }

  checkedd(property_id: any, chk: any) {


    var v1 = 0
    var v2 = 0
    var v3 = 0
    alert(property_id)


    if (sessionStorage.getItem('compare1') == property_id) {
      // sessionStorage.removeItem('compare1');
      v1 = 1
      v2 = 1
      v3 = 1

    }
    else if (sessionStorage.getItem('compare2') == property_id && v2 == 0) {
      // sessionStorage.removeItem('compare2');
      v1 = 1
      v2 = 1
      v3 = 1
    }
    else if (sessionStorage.getItem('compare3') == property_id && v3 == 0) {

      // sessionStorage.removeItem('compare3');
      v1 = 1
      v2 = 1
      v3 = 1
    }


    if (sessionStorage.getItem('compare1') == null && v1 == 0) {

      // alert("shiva")
      sessionStorage.setItem('compare1', property_id);


    }
    else if (sessionStorage.getItem('compare2') == null && v2 == 0) {
      sessionStorage.setItem('compare2', property_id);

      v2 = 1

    }
    else if (sessionStorage.getItem('compare3') == null && v3 == 0) {
      sessionStorage.setItem('compare3', property_id);
      v3 = 1
    }


    // if(this.comparecount>2){
    //     chk.checked = false;
    //       alert("Excedd the limit ...")
    // }


    else if (sessionStorage.getItem('compare3') != null && sessionStorage.getItem('compare3') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare3');
    }
    else if (sessionStorage.getItem('compare1') != null && sessionStorage.getItem('compare1') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare1');
    }
    else if (sessionStorage.getItem('compare2') != null && sessionStorage.getItem('compare2') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare2');
    }



    else {

      chk.checked = false;
      alert("Excedd the limit ...")
    }

  }

  CheckLocalStore(): Observable<any> {
    return of(sessionStorage.getItem("uname"));
  }

  ngDoCheck() {
    this.CheckLocalStore().subscribe((data) => { this.logstatus = data })

    if (sessionStorage.getItem('compare1') != null) { this.ccount1 = 1 }
    if (sessionStorage.getItem('compare2') != null) { this.ccount2 = 1 }
    if (sessionStorage.getItem('compare3') != null) { this.ccount3 = 1 }
    if (sessionStorage.getItem('remove') == 'remo') {
      this.ngOnInit();

      sessionStorage.removeItem('remove')

    }

    this.comparecount = this.ccount1 + this.ccount2 + this.ccount3
    // console.log(this.comparecount)

  }

  ngOnInit() {
    // this.myapp.ngOnInit();
    this.pagepage();

  }

}

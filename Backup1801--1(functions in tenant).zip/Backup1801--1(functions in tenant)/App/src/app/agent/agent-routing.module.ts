import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgenthomeComponent } from './agenthome/agenthome.component';
import { MyOwnersComponent } from './my-owners/my-owners.component';

const routes: Routes = [
  {path:'agent', component: AgenthomeComponent},
  {path:'myowners', component:MyOwnersComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgentRoutingModule { }

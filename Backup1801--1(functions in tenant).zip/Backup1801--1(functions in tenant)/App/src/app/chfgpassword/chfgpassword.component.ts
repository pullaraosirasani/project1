import { Component, OnInit } from '@angular/core';
import { register } from '../models/register';
import { ActivatedRoute, Router } from '@angular/router';
import { NearlukService } from '../services/nearluk.service';

@Component({
  selector: 'app-chfgpassword',
  templateUrl: './chfgpassword.component.html',
  styleUrls: ['./chfgpassword.component.css']
})
export class ChfgpasswordComponent implements OnInit {

  lgs: any;
  username: any;
  ch: register;
  visibleOTP: boolean;
  otp: any;
  status: any;
  mobile: any;
  invalidCredential: boolean;
  invalidMobile: boolean;
  invalidUsername: boolean;
  invalidPassword: boolean;
  constructor(private acr: ActivatedRoute, private nls: NearlukService, private router: Router) {
    this.ch = new register();
  }

  submitForChangePswd(password: any) {
    if ((password.value == '') || (password.value == null)) {
      this.invalidPassword = true;
    }
    let username = this.acr.snapshot.params.username;
    this.nls.loginen(username, password.value).subscribe((data) => {
      if (data.length > 0) {
        this.lgs = true;
      }
      else {
        // alert('please enter valid password')
        this.invalidPassword = true;
      }
    })
  }

  makeEventFalse() {
    this.invalidCredential = false;
    this.invalidMobile = false;
    this.invalidUsername = false;
    this.invalidPassword = false;
  }

  submitForForgotPswd(username: any, mobile: any) {
    if (username.value == null || username.value == '' || mobile.value == null || mobile.value == '') {
      // alert('please enter username and mobile number')
      this.invalidCredential = true;
    }
    else {
      this.nls.getByUserName(username.value).subscribe((data) => {
        // alert(JSON.stringify(data))
        if (data.length > 0) {
          if (mobile.value == data[0].mobile) {
            sessionStorage.setItem("fp", username.value);
            this.nls.sendotp(mobile.value).subscribe((data) => {
              this.otp = data.Details;
              this.mobile = mobile.value;
            })
            this.visibleOTP = true;

          }
          else {
            // alert('invalid mobile')
            this.invalidMobile = true;
          }
        }
        else {
          // alert('invalid username')
          this.invalidUsername = true;

        }
      })





    }
  }

  resendOtp() {
    this.nls.sendotp(this.mobile).subscribe((data) => {
      this.otp = data.Details;
      alert('OTP sent succesfully')
    })
  }
  submitOTP(otp: any) {
    this.nls.verify(this.otp, otp.value).subscribe((data) => {
      this.status = data.Status

      if (data.Status == "Success") {
        this.visibleOTP = false;
        this.lgs = true;
      }
      else {
        alert('invalid OTP')
      }
    })
  }

  updatePassword(pswd: any, cpswd: any) {
    if (sessionStorage.getItem("fp")) {
      this.ch.username = sessionStorage.getItem("fp");
    }
    else {
      this.ch.username = sessionStorage.getItem("uname");
    }
    if (pswd.value != cpswd.value) {
      alert('password do not match')
    }
    else {
      this.nls.updatePassword(this.ch).subscribe((data) => {
        alert('updated succesfully...')
        this.username = this.acr.snapshot.params.username;
        if (this.username) {
          this.router.navigate(['home']);
        }
        else {
          sessionStorage.removeItem("fp");
          this.router.navigate(['login']);
        }
      })
    }
  }

  ngOnInit() {
    this.username = this.acr.snapshot.params.username;
  }

}

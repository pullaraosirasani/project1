import { Component, OnInit } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';

@Component({
  selector: 'app-bidding',
  templateUrl: './bidding.component.html',
  styleUrls: ['./bidding.component.css']
})
export class BiddingComponent implements OnInit {

  BiddingPropertys: any;
  showPopup: boolean = false;
  pid1: any;
  p: number;
  event: number = 1;

  pagecount: any;

  constructor(private srvc: NearlukService) { }



  page($event) {
    this.event = $event;
    this.ngOnInit();
  }



  
  pagepage() {

    let uname = sessionStorage.getItem('uname');
    this.event = this.event + 1;
    this.srvc.getBiddingPropertyDetails(uname,this.event).subscribe((data) => {
      // alert(JSON.stringify(data))
      this.BiddingPropertys = data;
      // console.log(data)
    })

      }


  Owner_Property_details(property_id: string) {
    alert(property_id)
    // alert("val of showpoopup :" + this.showPopup);
    this.pid1 = property_id;
    // alert("Property Id is  : " + this.pid1)
    this.showPopup = true;
  }


  closeEventHandler(res: boolean) {
    this.showPopup = false;
  }

  ngOnInit() {
this.pagepage();


  }

}


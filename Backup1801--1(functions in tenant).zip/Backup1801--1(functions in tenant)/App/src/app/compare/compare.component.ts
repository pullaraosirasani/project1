
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NearlukService } from '../services/nearluk.service';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-compare',
  templateUrl: './compare.component.html',
  styleUrls: ['./compare.component.css']
})
export class CompareComponent implements OnInit {
  i: any
  propertyList: any
  array: any[] = [];


  comparecount: any = 0;
  one: number = 0;
  two: number = 0;
  three: number = 0;
  logstatus: any;
  showowner: string = "";
  ownerinfo: any;
  noData: boolean;
  count: any;
  constructor(private router: Router, private act: ActivatedRoute, private actt: ActivatedRoute, private nls: NearlukService, private acttt: ActivatedRoute) { }
  CheckLocalStore(): Observable<any> {
    return of(sessionStorage.getItem("uname"));

  }

  removeallCompare() {

    sessionStorage.removeItem("compare1")
    sessionStorage.removeItem("compare2")
    sessionStorage.removeItem("compare3")


    sessionStorage.setItem('remove', 'remo')

    let user_type = sessionStorage.getItem("user_type");
    if (user_type == 'Owner/Tenant' || user_type == null) {
      this.router.navigate(['home']);
    }
    else if (user_type == 'Agent') {
      this.router.navigate(['agent']);
    }

  }

  removecompare(pid) {


    if (sessionStorage.getItem("compare1") === pid) {

      sessionStorage.removeItem("compare1");

      // this.router.navigateByUrl('home', { skipLocationChange: true }).then(() =>
      //   this.router.navigate(['compare']));
      this.ngOnInit();
    }
    else if (sessionStorage.getItem("compare2") === pid) {

      sessionStorage.removeItem("compare2");

      // this.router.navigateByUrl('home', { skipLocationChange: true }).then(() =>
      //   this.router.navigate(['compare']));
      this.ngOnInit();
    }
    else if (sessionStorage.getItem("compare3") == pid) {
      sessionStorage.removeItem("compare3");

      // this.router.navigateByUrl('home', { skipLocationChange: true }).then(() =>
      //   this.router.navigate(['compare']));
      this.ngOnInit();
    }
    if (sessionStorage.getItem("compare1") == null && sessionStorage.getItem("compare2") == null && sessionStorage.getItem("compare3") == null) { this.router.navigate(['home']) }
  }

  ownerinfos(pid) {
    if (!sessionStorage.getItem("uname")) {
      this.router.navigate(['login']);
    }
    else {
      this.showowner = pid;
      this.nls.getOwnersInfo(pid).subscribe(data => {
        this.ownerinfo = data[0];
        pid = "";

      })
    }
  }

  ngOnInit() {
    let property_id = []
    property_id[0] = sessionStorage.getItem('compare1');
    property_id[1] = sessionStorage.getItem('compare2');
    property_id[2] = sessionStorage.getItem('compare3')

    if ((sessionStorage.getItem('compare1') != null)) {

      this.one = 1;
    }
    if ((sessionStorage.getItem('compare2') != null)) {

      this.two = 1;
    }
    if ((sessionStorage.getItem('compare3') != null)) {

      this.three = 1;
    }
    
    this.count = this.one + this.two + this.three;
    alert(this.count)
    if (this.count == 0) {
      this.noData = false
    }
    else {
      this.noData = true;
    }

    this.nls.GetCompare(property_id).subscribe((data) => {
      this.propertyList = data;
    });

  }
}

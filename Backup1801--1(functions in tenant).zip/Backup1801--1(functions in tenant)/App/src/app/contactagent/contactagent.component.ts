import { Component, OnInit } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';
import { Router, ActivatedRoute } from '@angular/router';
import { tenantnotifications } from '../models/tenantnotifications';


@Component({
  selector: 'app-contactagent',
  templateUrl: './contactagent.component.html',
  styleUrls: ['./contactagent.component.css']
})
export class ContactagentComponent implements OnInit {

  agents: any
  holder: any;
  property_id: any;
  tenantnotify: tenantnotifications;
  notificationSent: boolean;
  notificationData: any;
  noData: any;
  display = "";
  dummy = [];
  count: number;
  agentData: any;
  agentMoreDetails: boolean;
  alreadyAdded: boolean;
  p: number;
  event: number = 1;

  pagecount: any;
  constructor(private agent: NearlukService, private acr: ActivatedRoute) {
    this.tenantnotify = new tenantnotifications();
  }


  page($event) {
    this.event = $event;
    this.ngOnInit();
  }

  pagepage(){

    let cty = sessionStorage.getItem('city');
    let city = cty.trim();
    alert(city)
    this.event = this.event + 1;
    this.agent.GetAllAgents(city,this.event).subscribe((data) => {
      this.agents = data;
      this.property_id = this.acr.snapshot.params.property_id;

    })


  }

  agentDetails(username: any) {
    this.agent.getByUsernameWithImage(username).subscribe((data) => {
      this.agentData = data;
      this.agentMoreDetails = true;
      this.sendNotification(this.property_id, username);
    })
  }

  sendNotification(property_id: any, username: any) {
    this.agent.dataToSendNotification(property_id, username).subscribe((data) => {
      // alert(JSON.stringify(data))
      if (data.length > 0) {
        if (data[0].notification_type === 'rejected') {
          this.noData = false;
        }
        else if (data[0].notification_type === 'accepted') {
          this.alreadyAdded = true;
        }
        else if (data[0].notification_type === 'request') {
          this.noData = true;
        }
      }
      else {
        this.noData = false;
      }
    })

  }

  addAgent(username: any) {
    // this.agent.sendNotificationToAgent(this.property_id,)
    alert(username)
    this.tenantnotify.from_username = sessionStorage.getItem('uname');
    this.tenantnotify.notification_type = 'request';
    this.tenantnotify.property_id = this.property_id
    this.tenantnotify.to_username = username;
    this.tenantnotify.status = 'unseen';
    this.tenantnotify.notifydate = new Date();
    alert(JSON.stringify(this.tenantnotify))
    this.agent.addagentnotifications(this.tenantnotify).subscribe(data => {
      this.noData = true;
    })

  }

  cncl() {   //for cancel button
    this.alreadyAdded = false;
    this.noData = false;

  }

  ngOnInit() {
    this.pagepage();
  }

}




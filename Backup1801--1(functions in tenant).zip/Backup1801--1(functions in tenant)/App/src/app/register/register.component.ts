import { register } from './../models/register';
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { NearlukService } from '../services/nearluk.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit, AfterViewInit {
  display: boolean = false;

  reg: register //Register model
  options: any;  //ISD Code
  location: any
  isd: any;
  con: any;
  isd_code: any;
  otp: any;
  status: any;
  displayOtp: boolean;
  mobile: any = true;
  userExist: boolean;
  mobileExist: boolean;

  constructor(private nls: NearlukService, private router: Router) {
    this.reg = new register()
  }

  cncl() {  //for cancel button
    this.display = false;
    this.router.navigate(['home'])

  }


  signUpClick(myFrm: any, cp: any) {  //Register Click
    if ((myFrm.value.Name == undefined) || (myFrm.value.Id == undefined) || (myFrm.value.password == undefined) || (myFrm.value.isd == undefined) || (myFrm.value.mobile == undefined)) {
    }
    if (myFrm.value.password != cp.value) {
      alert('password do not match')
    }
    else {
      this.nls.getByUserName(this.reg.username).subscribe((data) => {
        if (data.length > 0) {
          this.userExist = true;
        }
        else {
          this.mobileclick()
        }
      })
    }
  }
  makeUserFalse() {
    this.userExist = false;
  }
  makeMobileFalse() {
    this.mobileExist = false;
  }
  mobileclick() {
    this.nls.getByMobile(this.reg.mobile).subscribe((data) => {
      if (data.length > 0) {
        this.mobileExist = true;
      }
      else {
        // this.nls.RegisterPost(this.reg).subscribe((data) => {
        //   alert("posted successfully....")
        //   this.router.navigate(['login'])
        // })
        this.mobile = this.reg.mobile;
        this.displayOtp = true;
        this.nls.sendotp(this.reg.mobile).subscribe((data) => {
          this.otp = data.Details;

        })
      }
    })
  }

  resentOtp(mobile: any) {
    alert(mobile)
    this.nls.sendotp(mobile).subscribe((data) => {
      this.otp = data.Details;

    })
  }
  verifyOtp(otp: any) {

    this.nls.verify(this.otp, otp.value).subscribe((data) => {
      this.status = data.Status
      alert(data.Status)
      if (data.Status == "Success") {
        this.nls.RegisterPost(this.reg).subscribe((data) => {
          alert("posted successfully....")
          this.router.navigate(['login'])
        })
      }
      else {
        alert('INVALID OTP')
      }
    })

  }
  ngAfterViewInit() {
    this.display = true;
  }



  ngOnInit() {

    // for popup primeng
    // this.location = sessionStorage.getItem('country')
    // this.con = this.location.trim()


    // this.nls.GetDropDownisds(this.con).subscribe((data) => {

    //   this.reg.isd = data[0].country_code;

    //   this.reg.isd_code = data[0].country_isd;



    //   // alert(JSON.stringify(this.id))
    // })
  }

}

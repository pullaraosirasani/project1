import { Component, OnInit, Input } from '@angular/core';
import { NearlukService } from '../services/nearluk.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from './../app.component';
import { Trending } from '../models/trending';
import { Observable, of } from 'rxjs';
import { Bidding } from '../models/tbidding';
import { city } from '../models/cityname';
import { tenantnotifications } from '../models/tenantnotifications';
import { GMapsService } from '../services/gmaps.service';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @Input() showdata: any;
  filtermessage: string;
  nofilter: boolean = false;
  pid: any;
  pid1: any;
  display: boolean;
  propertyList: any; // Home Cards Get
  latt: any;
  lngg: any;
  Trending: Trending;
  city: any;
  array: any[] = []
  count: number = 0;

  compare1: any;
  compare2: any;
  compare3: any;

  ccount1: any = 0;
  ccount2: any = 0;
  ccount3: any = 0;
  comparecount: any;
  logstatus: any;
  mapDil: any;
  id1: any;
  id2: any;
  showbidding: boolean;
  bid_price: any;
  details: any;
  ownername: string;
  Baseprice: number;
  userdetailsbidding: boolean;
  Bidd: Bidding;
  ownerUsername: any;
  property_id: any;
  baseprice: any;
  prop: any;
  bidding: boolean;
  city_id: any;
  showPopup: boolean = false;
  Bidding_price: any;
  username: any;
  city1: city;
  averagebyarea: any;
  displayaverage: any;
  tenantnotification: tenantnotifications;
  agents: any = [];
  p: number;
  uname: string;
  propertybyareaorcity: any = [];
  showPropertiesByArea: boolean;

  event: number = 1;

  pagecount: any;

  constructor(private nls: NearlukService, private router: Router, public myapp: AppComponent, private gMapsService: GMapsService, private acr: ActivatedRoute) {
    this.Trending = new Trending();
    this.Bidd = new Bidding();
    this.city1 = new city();
    this.tenantnotification = new tenantnotifications();

  }

  closeEventHandler(res: boolean) {
    this.showPopup = false;
  }

  checkedd(property_id: any, chk: any) {


    var v1 = 0
    var v2 = 0
    var v3 = 0
    alert(property_id)


    if (sessionStorage.getItem('compare1') == property_id) {
      // sessionStorage.removeItem('compare1');
      v1 = 1
      v2 = 1
      v3 = 1

    }
    else if (sessionStorage.getItem('compare2') == property_id && v2 == 0) {
      // sessionStorage.removeItem('compare2');
      v1 = 1
      v2 = 1
      v3 = 1
    }
    else if (sessionStorage.getItem('compare3') == property_id && v3 == 0) {

      // sessionStorage.removeItem('compare3');
      v1 = 1
      v2 = 1
      v3 = 1
    }


    if (sessionStorage.getItem('compare1') == null && v1 == 0) {

      // alert("shiva")
      sessionStorage.setItem('compare1', property_id);


    }
    else if (sessionStorage.getItem('compare2') == null && v2 == 0) {
      sessionStorage.setItem('compare2', property_id);

      v2 = 1

    }
    else if (sessionStorage.getItem('compare3') == null && v3 == 0) {
      sessionStorage.setItem('compare3', property_id);
      v3 = 1
    }


    // if(this.comparecount>2){
    //     chk.checked = false;
    //       alert("Excedd the limit ...")
    // }


    else if (sessionStorage.getItem('compare3') != null && sessionStorage.getItem('compare3') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare3');
    }
    else if (sessionStorage.getItem('compare1') != null && sessionStorage.getItem('compare1') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare1');
    }
    else if (sessionStorage.getItem('compare2') != null && sessionStorage.getItem('compare2') == property_id) {

      chk.checked = false;
      sessionStorage.removeItem('compare2');
    }



    else {

      chk.checked = false;
      alert("Excedd the limit ...")
    }

  }

  btnCompare() {

    this.router.navigate(['compare/' + this.array[0] + '/' + this.array[1] + '/' + this.array[2]])
  }


  // NearU() {
  //   this.nls.nearU(this.latt, this.lngg).subscribe((data) => {
  //     this.propertyList = data;
  //   })
  // }
  

  // MoreDetails(property_id: any) {
  //   // alert(property_id)


  //   this.router.navigate(['moredetails' + '/' + property_id])
  // }
  MoreDetails(property_id: any, ownername: any) {

    var username = sessionStorage.getItem('uname');

    if (username != null && ownername != username) {

      this.nls.Insert_property_views(property_id, username).subscribe((data) => {

      })
    }

    this.pid1 = property_id;

    alert("Property Id is  : " + this.pid1)
    this.showPopup = true;
  }
  CheckLocalStore(): Observable<any> {
    return of(sessionStorage.getItem("uname"));
  }
  ngDoCheck() {
    this.CheckLocalStore().subscribe((data) => { this.logstatus = data })

    if (sessionStorage.getItem('compare1') != null) { this.ccount1 = 1 }
    if (sessionStorage.getItem('compare2') != null) { this.ccount2 = 1 }
    if (sessionStorage.getItem('compare3') != null) { this.ccount3 = 1 }
    if (sessionStorage.getItem('remove') == 'remo') {
      this.ngOnInit();

      sessionStorage.removeItem('remove')

    }

    this.comparecount = this.ccount1 + this.ccount2 + this.ccount3
    // console.log(this.comparecount)

  }

  trendings(type, id) {   //insert and update trending when clicked on card
    var dt = new Date()
    let h = dt.getMonth() + 1;
    this.Trending.date = dt.getFullYear() + '_' + h + '_' + dt.getDate();

    this.Trending.property_type = type;
    this.Trending.property_id = id;

    this.nls.getTrendingId(id).subscribe((data) => {
      if (data.length < 1) {
        this.nls.insertTrendingCount(this.Trending).subscribe((data) => {
        })
      }
      else {
        this.nls.updateTrendingCount(id).subscribe((data) => {
        })
      }
    })


  }

  trendingFilter(filter) {    //
    // alert(filter.value)
    this.city = sessionStorage.getItem('city').toString().trim()

    console.log(this.city)
    // this.city = 'vijayawada'

    this.nls.getTrendingFiltersId(filter.value, this.city).subscribe((data) => {
      // alert(JSON.stringify(data))
      this.propertyList = data;
    })
  }

  getBidding(property_id: any) {
    let uname = sessionStorage.getItem("uname")

    alert(property_id)
    //this.showbidding = true;
    this.bidding = true;
    this.prop = property_id
    if (!uname) {
      this.router.navigate(['login'])
    }
    else {
      this.nls.getOwnersInfo(property_id).subscribe(data => {
        this.ownername = data[0].user_name;
        this.baseprice = data[0].pprice;

      })
      // alert(property_id);
      this.nls.getBidding(property_id).subscribe((data) => {
        this.bid_price = data;
        console.log(data)
      })
    }
  }

  GetUserDetails(name: any) {

    this.nls.detailsforbiding(name).subscribe((data) => {
      this.details = data;
      this.userdetailsbidding = true;
      // alert(JSON.stringify(data))
      console.log(data);
    })
  }


  btnprice(biddingprice: any, prpty_id: any, baseprice: any) {
    if ((biddingprice.value == null) || (biddingprice.value == '')) {

    }
    else {
      this.Bidd.property_id = prpty_id;
      this.Bidd.bidding_price = biddingprice.value;

      this.Bidd.username = sessionStorage.getItem('uname');

      if (this.ownername == this.Bidd.username) {
        alert('YOU CANNOT BID YOUR OWN PROPERTY')
      }
      else {
        if (parseInt(baseprice) >= parseInt(biddingprice.value)) {
          alert("Bid price should be greater than base price..!")
        }
        else {

          this.nls.getAgentInfo(prpty_id).subscribe((data) => {
            if (data.length > 0) {
              this.agents = data;
              this.agents.push({ 'agent_username': this.ownername });
              this.tenantnotification.to_username = (this.agents);
              this.tenantnotification.property_id = prpty_id;
              this.tenantnotification.from_username = sessionStorage.getItem('uname');

              this.tenantnotification.notification_type = 'biding';
              this.tenantnotification.status = 'unseen';
              this.tenantnotification.notifydate = new Date();
              this.tenantnotification.message = biddingprice.value;

              this.nls.biddingnotifications(this.tenantnotification).subscribe(data => {
                console.log(data)
              })

            }
            else {
              this.tenantnotification.to_username = [{ 'agent_username': this.ownername }]
              this.tenantnotification.property_id = prpty_id;
              this.tenantnotification.from_username = sessionStorage.getItem('uname');

              this.tenantnotification.notification_type = 'biding';
              this.tenantnotification.status = 'unseen';
              this.tenantnotification.notifydate = new Date();
              this.tenantnotification.message = biddingprice.value;

              this.nls.biddingnotifications(this.tenantnotification).subscribe(data => {
                console.log(data)
              })
            }
          })




          this.nls.priceSend(this.Bidd).subscribe((data) => {
            this.getBidding(prpty_id);
            biddingprice.value = '';

          })
        }
      }
    }
  }

  onSubmit(myFrm: NgForm) {
    myFrm.resetForm();
  }

  getaverage(ptype, pid: any, area) {
    this.nls.getaveragebyarea(ptype, area).subscribe(data => {
      this.displayaverage = pid;
      this.averagebyarea = data;
      console.log(this.averagebyarea);
      this.averagebyarea.average = Math.floor(this.averagebyarea.average)

    })
  }

  getpropertybyarea(ptype) {
    this.router.navigateByUrl('/getpropertybyareaome', { skipLocationChange: true }).then(() =>
      this.router.navigate(['getpropertybyarea' + '/' + ptype]));
    // this.router.navigate(['getpropertybyarea/'+ptype])
  }

  page($event) {
    this.event = $event;
    this.ngOnInit();
  }

  pagepage() {

    // alert(this.event)
    // this.event = 2
    this.event = this.event + 1;

    this.compare1 = sessionStorage.getItem('compare1')
    this.compare2 = sessionStorage.getItem('compare2')
    this.compare3 = sessionStorage.getItem('compare3')

    let enablepropertybyarea = sessionStorage.getItem('getpropertybyarea');

    this.a = (sessionStorage.getItem('filterss'))
    let j = this.acr.snapshot.params.value;

    if (j) {
      if (this.a.facing != "undefined") {
        this.a = JSON.parse(sessionStorage.getItem('filterss'))
      }
      this.city1.city = this.a.cityname;
      this.city1.city = this.city1.city.replace('/', '*');
      this.city1.city = this.city1.city.replace('/', '*');
      this.nls.getidbycountry(this.city1).subscribe(data => {

        this.city_id = data[0].cityid;
        alert(this.city_id + 'shiva');
        this.nls.getfilters(this.a.propertytypeid, JSON.parse(this.a.facing), this.city_id, this.a.minprice, this.a.maxprice, this.a.verification, this.a.ratings, this.event).subscribe(data => {

          if (data.length > 0) {
            this.propertyList = data;
            alert(data.length);
          }
          else {
            alert('not');
            this.nofilter = true;
            this.filtermessage = "No Records Found";
          }

        })
      })
    }
    else if (enablepropertybyarea) {
      this.propertyList = this.showdata;
      console.log(this.showdata);

      sessionStorage.removeItem('getpropertybyarea');
    }
    else {
      this.nls.GetHomeDetails(this.event).subscribe((data) => { // Home Cards Get
        this.propertyList = data;
        this.username = sessionStorage.getItem('uname');
        console.log(data);
        var area = sessionStorage.getItem('area');
        var city = sessionStorage.getItem('city');
        this.nls.getpropertybyareaorcity(city.trim(), area.trim()).subscribe(data => {
          this.showPropertiesByArea = true;
          this.propertybyareaorcity = data;
          console.log(data);

        })
      })

    }


    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latt = position.coords.latitude;
        this.lngg = position.coords.longitude;
        this.gMapsService.getLatLan(this.latt, this.lngg).subscribe(result => {

        }, error =>
            console.log(error),

          () => console.log('Geocoding completed!')
        );


      });
    }
    else {
      alert("Geolocation is not supported by this browser.");
    }
    this.getDirection()
  }


  a: any;
  ngOnInit() {
    this.pagepage();
  }


  public origin: {}
  public destination: {}




  getDirection() {
    navigator.geolocation.getCurrentPosition((position) => {
      this.origin = { lat: position.coords.latitude, lng: position.coords.longitude }
      // this.destination = { lat: 17.401810, lng: 78.560188 }
    });

  }




  close() {
    console.log('calling on close');
  }

  dialogBox(a) {

    this.id1 = a;
    this.nls.homeMap(a).subscribe(data => {

      // this.id2=data[0].property_id;
      // this.display = !this.display
      if (data) {
        alert(JSON.stringify(data[0]))
        this.mapDil = data[0].destination;
        this.display = !this.display
        a = "";
      }
    })
  }

}

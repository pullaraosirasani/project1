import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AdminModule } from '../app/admin/admin.module'
import { AdminRoutingModule } from '../app/admin/admin-routing.module'
import { AgentModule } from '../app/agent/agent.module'
import { AgentRoutingModule } from '../app/agent/agent-routing.module'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ChfgpasswordComponent } from './chfgpassword/chfgpassword.component';
import { CompareComponent } from './compare/compare.component';
import { ContactagentComponent } from './contactagent/contactagent.component';
import { ContactusComponent } from './contactus/contactus.component';
import { EnquiryFormComponent } from './enquiry-form/enquiry-form.component';
import { FaqsComponent } from './faqs/faqs.component';
import { FavouritesComponent } from './favourites/favourites.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MoredetailsComponent } from './moredetails/moredetails.component';
import { MyagentComponent } from './myagent/myagent.component';
import { MypropertiesComponent } from './myproperties/myproperties.component';
import { NearuComponent } from './nearu/nearu.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PostPropertyComponent } from './post-property/post-property.component';
import { ProfileComponent } from './profile/profile.component';
import { RecommendationComponent } from './recommendation/recommendation.component';
import { RegisterComponent } from './register/register.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { UpdatepropertyComponent } from './updateproperty/updateproperty.component';
import { ViewallnotificationsComponent } from './viewallnotifications/viewallnotifications.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccordionModule } from 'primeng/accordion';
import { DialogModule } from 'primeng/dialog';
import { NgxPaginationModule } from 'ngx-pagination';
import { AgmCoreModule } from '@agm/core';
import { AgmDirectionModule } from 'agm-direction';
import { InputSwitchModule } from 'primeng/inputswitch';
import { FileUploadModule } from 'primeng/fileupload';
import { MatStepperModule } from '@angular/material/stepper';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { RatingModule } from 'primeng/rating';
import { GalleriaModule } from 'primeng/galleria';
import { NgxPageScrollModule } from 'ngx-page-scroll';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { NearlukService } from './services/nearluk.service';
import { GMapsService } from './services/gmaps.service';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
import { BiddingComponent } from './bidding/bidding.component';
import { KeyFilterModule } from 'primeng/keyfilter';
import { GetPropertyAreaCityComponent } from './get-property-area-city/get-property-area-city.component';
// import { AuthServiceConfig, GoogleLoginProvider, FacebookLoginProvider } from 'angularx-social-login';


// const config = new AuthServiceConfig([
//   {
//     id: GoogleLoginProvider.PROVIDER_ID,
//     provider: new GoogleLoginProvider('624796833023-clhjgupm0pu6vgga7k5i5bsfp6qp6egh.apps.googleusercontent.com')
//   },
//   {
//     id: FacebookLoginProvider.PROVIDER_ID,
//     provider: new FacebookLoginProvider('561602290896109')
//   },

// ]);

// export function provideConfig() {
//   return config;
// }

@NgModule({
  declarations: [
    AppComponent,
    AboutusComponent,
    ChfgpasswordComponent,
    CompareComponent,
    ContactagentComponent,
    ContactusComponent,
    EnquiryFormComponent,
    FaqsComponent,
    FavouritesComponent,
    HomeComponent,
    LoginComponent,
    MoredetailsComponent,
    MyagentComponent,
    MypropertiesComponent,
    NearuComponent,
    PageNotFoundComponent,
    PostPropertyComponent,
    ProfileComponent,
    RecommendationComponent,
    RegisterComponent,
    UpdateprofileComponent,
    UpdatepropertyComponent,
    ViewallnotificationsComponent,
    BiddingComponent,
    GetPropertyAreaCityComponent,

  ],
  imports: [
    BrowserModule,
    GooglePlaceModule,
    FormsModule,
    AccordionModule,
    AppRoutingModule,
    AdminModule,
    AdminRoutingModule,
    AgentModule,
    AgentRoutingModule,
    DialogModule,
    NgxPaginationModule,
    AgmCoreModule,
    AgmDirectionModule,
    InputSwitchModule,
    FileUploadModule,
    MatStepperModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    RatingModule,
    GalleriaModule,
    NgxPageScrollModule,
    DropdownModule,
    MultiSelectModule,
    AutoCompleteModule,
    NgbModule,
    HttpClientModule,
    AngularFontAwesomeModule,
    BrowserAnimationsModule,
    KeyFilterModule,
    AgmCoreModule.forRoot({
      apiKey: '',
      // libraries: ['geometry']
    }),
  ],

  providers: [NearlukService, GMapsService, 
  //   {
  //   provide: AuthServiceConfig,
  //   useFactory: provideConfig
  // }
],

  bootstrap: [AppComponent]
})
export class AppModule { }

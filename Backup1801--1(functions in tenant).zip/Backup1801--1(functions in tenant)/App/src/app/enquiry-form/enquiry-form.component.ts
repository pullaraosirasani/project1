import { Component, OnInit } from '@angular/core';
import { Enquiry_Form } from '../models/enquiryform';
import { NearlukService } from '../services/nearluk.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-enquiry-form',
  templateUrl: './enquiry-form.component.html',
  styleUrls: ['./enquiry-form.component.css']
})
export class EnquiryFormComponent implements OnInit {

  enqform: Enquiry_Form;
  options: any;
  optionscity: any;
  optionsstate: any;
  optionsarea: any;
  optionscurrency: any
  pTypes: any;
  show1: any
  price: any[];
  min: number;
  maxprice: any[] = [];
  max;
  constructor(private nls: NearlukService, private router: Router, private acr: ActivatedRoute) {
    this.enqform = new Enquiry_Form();
    this.price = [
      { opt: 1000 },
      { opt: 5000 },
      { opt: 10000 },
      { opt: 15000 },
      { opt: 20000 },
      { opt: 50000 },
      { opt: 100000 },
      { opt: 1000000 },
      { opt: 2000000 },
    ]
  }


  storemin(minval) {

    this.maxprice = [];
    this.min = minval;
    for (let index = 0; index < this.price.length; index++) {
      if (this.min == this.price[index].opt)
        this.max = index;
    }
    for (let index = this.max + 1; index < this.price.length; index++) {
      this.maxprice.push(this.price[index].opt);

    }
    console.log(this.maxprice)
  }

  homeNavigate() {
    this.router.navigate(['home']);
  }

  optionstate(c: any) {

    this.nls.getStatesByCountry(c.value).subscribe((data) => {
      this.optionsstate = data;


    })
  }


  optioncity(c: any) {
    this.nls.getCitysByStateId(c.value).subscribe((data) => {
      this.optionscity = data;
      // alert(JSON.stringify(data))


    })
  }

  optionarea(c: any) {
    this.nls.getAreaByCityId(c.value).subscribe((data) => {
      this.optionsarea = data
      //   alert(JSON.stringify(data));
    })
  }






  cancel() {

    this.router.navigate(['home'])

  }

  SearchUpdate(myFrm: any) {

    if ((myFrm.value.country == undefined) || (myFrm.value.state == undefined) || (myFrm.value.city == undefined)) {

    }
    else {

      this.nls.EnquiryFormUpdate(this.enqform).subscribe((data) => {
        // alert('update')
        this.router.navigate(['Recommendations'])

      })

    }
  }

  AddEnquiryFormData(myFrm: any) {
    if ((myFrm.value.country == undefined) || (myFrm.value.state == undefined) || (myFrm.value.city == undefined)) {

    }
    else {

      this.nls.EnquiryFormAdd(this.enqform).subscribe((data) => {
        // alert('posted successfully')
        this.router.navigate(['Recommendations'])
      })

    }



  }


  ngOnInit() {

    let username = sessionStorage.getItem('uname');
    this.enqform.username = username;

    this.nls.CheckinEnquiryForm_user(username).subscribe((data) => {
      this.show1 = data;

      if (data == 0) {
        this.show1 = false;
      }
      else {
        this.show1 = true;
      }
    })

    this.nls.getCountries().subscribe((data) => {

      this.options = data
      // alert(JSON.stringify(data))

    })

    this.nls.getcurrency().subscribe((data) => {
      this.optionscurrency = data;
      // alert(JSON.stringify(data))
    })


    this.nls.getPropertyType().subscribe((data) => {
      this.pTypes = data

    })

  }
}

